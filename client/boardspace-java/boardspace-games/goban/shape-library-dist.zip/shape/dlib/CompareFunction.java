package dlib;


/**
 * this interface is useful for sorting. 
 */

public interface CompareFunction
{

	/**
	 * return true of two objects are in order 
	 */

	boolean InOrder (Object a, Object b);
}

