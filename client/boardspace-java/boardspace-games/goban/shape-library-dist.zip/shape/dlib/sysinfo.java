
package dlib;
import java.io.*;

/** utilities for extracting system description, and using them to
alter the behavior of applets 
*/
public class sysinfo 
{ 
/** these properties ought to always be acessable, according to 
    the java security faq http://java.sun.com/sfaq/
*/
static public String universal_properties[] =
			{
				"java.version",				//    Java version number
        "java.vendor",				//    Java vendor-specific string
        "java.vendor.url",		//    Java vendor URL
        "java.class.version",	//    Java class version number
        "os.name",						//    Operating system name
        "os.arch",					  //    Operating system architecture
        "os.version",					//    Operating system version
        "file.separator",			//    File separator (eg, "/")
        "path.separator",			//    Path separator (eg, ":")
        "line.separator"			//   Line separator 
            }  ;              
/** return true if the ventor is microsoft (in other words, Microsoft Internet Explorer */			
 static public boolean isMicrosoft()
 	{
 		String vendor = System.getProperty("java.vendor");
 		return(vendor.startsWith("Microsoft"));
 	}
/** return true if the vendor is netscape (in other words, Netscape Navigator */
 static public boolean isNetscape()
 {	String vendor = System.getProperty("java.vendor");
	  return(vendor.startsWith("Netscape"));
 }
	
/** return true if the java classes are jdk 1.0x (not any later version) */
 static public boolean isJDK1_0()
 	{
 		String version = System.getProperty("java.version");
		return(version.startsWith("1.0"));
 	}
/** return true if the java classes are jdk 1.1 (not any 1.0x or 1.2x) */
 static public boolean isJDK1_1()
 {
 		String version = System.getProperty("java.version");
		return(version.startsWith("1.1"));
 }
/** return true if the java classes are jdk 1.2 (not any previous version). */
 static public boolean isJDK1_2()
 	{
 		String version = System.getProperty("java.version");
		return(version.startsWith("1.2"));
 	}
/** return true if the java classes are greater or equal to the specified major/minor version */
 static public boolean isJDK_GEQ(int majorversion,int minorversion)
 {	String version = System.getProperty("java.version");
	  if(version.length()>=3)
	  	{char ch1 = version.charAt(0);
		  char ch2 = version.charAt(1);
		  char ch3 = version.charAt(2);
		  return(Character.isDigit(ch1)
		  		&& (ch2=='.')
  				&& Character.isDigit(ch3)
  			  && (Character.getNumericValue(ch1)>=majorversion)
  			  && (Character.getNumericValue(ch3)>=minorversion)
  			);
	 }
	 return(false);
 }
/**  return true if the java classes are greater or equal to the specified major/minor/bugfix
version */
 static public boolean isJDK_GEQ(int majorversion,int minorversion, int microversion)
 {

 	if(isJDK_GEQ(majorversion,minorversion))
 		{String version = System.getProperty("java.version");
 		 if(version.length()>=5)
 		 	{ char ch1 = version.charAt(3);
 		 	  char ch2 = version.charAt(4);
 		 	  return((ch1=='.')
 		 	  	     && Character.isDigit(ch2)
 		 	  	     && (Character.getNumericValue(ch2)>=microversion)); 			
 		}	}
 		return(false);
 	
 }
 /** dump all the guaranteed-available properties to a specified printwriter */
 static public void ShowAllProperties(PrintWriter p)
 	{	for(int i=0;i<universal_properties.length;i++)
 		{	String propname = universal_properties[i];
 		  try {
 		  	 String prop = System.getProperty(propname);
  		   p.println("Property " + propname + " is " + prop);
		  	 }
 		  	 catch (SecurityException e)
 		  	 { p.println("Security exception for " + propname + " " + e);
 		  	 }
 		}
}
}
