
package shape;

import java.util.*;
import dlib.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.zip.*;

public class ShapeLibrary 
{	Vector shapedata = null;		//the raw data
	Hashtable keyed_shapes=new Hashtable();
	
	/* constructor */
	public ShapeLibrary(Vector data,PrintWriter console)
	{ shapedata = data;
		if(data!=null) { Build_Hashdata(console); }
	}
	private void read_zipdata(InputStream in,PrintWriter console)
	{
		try {
			ZipInputStream zip = new ZipInputStream(in);
			zip.getNextEntry();
			ObjectInputStream s = new ObjectInputStream(zip);
			shapedata = (Vector)s.readObject();
			s.close();
		} 
		catch (IOException e) { console.println("IO Eror reading library" + e); }
		catch (ClassNotFoundException e) { console.println("Class not found" + e); }
		if(shapedata!=null) { Build_Hashdata(console); }
		
	}
	public ShapeLibrary(String filename,PrintWriter console)
	{
		shapedata=null;
		
		try {
			read_zipdata(new FileInputStream(filename),console);
		}
	    catch (IOException e) { console.println("IO Eror reading library" + e); }
		
	}
	/** load from a serialized java object */
	public ShapeLibrary(URL libname,PrintWriter console)
	{	shapedata=null;
		
		try {read_zipdata(libname.openStream(),console);
		} 
		catch (IOException e) { console.println("IO Eror reading library" + e); }
	}
	
	public void Save_ShapeLibrary(String filename,PrintWriter console)
	{
		try {
			FileOutputStream out = new FileOutputStream(filename);
			ObjectOutputStream s = new ObjectOutputStream(out);
			s.writeObject(shapedata);
			s.flush();	
			s.close();
		} 
		catch (IOException e) { console.println("IO Eror writing library" + e); }
	}
	void RemoveOneShape(OneShape s)
	{
		ShapeNormalizer norm[] = s.ExtendToIsomers();
		for(int i=0;i<norm.length;i++)
		{ ShapeNormalizer n = norm[i];
			Integer code = new Integer(n.hashCode());
			//System.out.println("Remove " + code.intValue()  + " for " + n);
			keyed_shapes.remove(code);
		}
		
	}
	boolean Merge_Shapes(ShapeNormalizer existing,ShapeNormalizer newshape,PrintWriter console)
	{
		/* attempt to merge two shapes.  This is possible if their position coverages
		do not overlap.  This problem arises from drop-in shapes that arise more than
		one way. */
		OneShape s1 = existing.reference_shape;
		OneShape s2 = newshape.reference_shape;
		
		RemoveOneShape(s1);
		RemoveOneShape(s2);	//first clean up the old stuff
		
		OneShape s3 = s1.Combine_With(s2,console);
		if(s3!=null) { BuildOneShape(s3,console); return(true); }
		else { 	return(false); }
	}
	
	/* put all the elements in the hashtable for fast lookup */
	public void BuildOneShape(OneShape s,PrintWriter console)
	{
		ShapeNormalizer norm[] = s.ExtendToIsomers();
		//System.out.println("shape s " + s + " extends to " + norm );
		for(int i=0;i<norm.length;i++)
		{ShapeNormalizer n=norm[i];
			Integer newkey=new Integer(n.hashCode());
			ShapeNormalizer newval = (ShapeNormalizer)keyed_shapes.get(newkey);
			if(newval!=null)
			{ //System.out.println("Conflict with " + newkey.intValue() + " for " + n);
				//System.out.println(".. is " + newval + newval.hashCode());
				if(!Merge_Shapes(newval,n,console))
				{console.println("hask keys must be unique; " );
					console.println( newval + newval.Ascii_Picture() );
					console.println( " conflicts with " + n + n.Ascii_Picture());
				}  
				break;//skip the rest, the merge took care of it if it's possible to do so */
			}else
			{	 keyed_shapes.put(newkey,n);
			}
		}
	}
	public void Build_Hashdata(PrintWriter console)
	{keyed_shapes.clear();
		/* build hash data for the primary elements */
		for(Enumeration e = shapedata.elements();
			e.hasMoreElements(); )
		{
			BuildOneShape((OneShape)e.nextElement(),console);
		}	
	}
	
	public void Build_Vectordata(PrintWriter console)
	{	Vector v = new Vector();
		console.println("Old vector has " + shapedata.size() + " elements");
		for(Enumeration e=keyed_shapes.elements(); e.hasMoreElements(); )
		{ ShapeNormalizer n = (ShapeNormalizer)e.nextElement();
			OneShape s = n.reference_shape;
			if(!v.contains(s)) { v.addElement(s); }
		}
		console.println("New Vector has " + v.size() + " elements ");
		shapedata = v;
		
	}
	
	/** locate a shape in the database, or null.  V is a vector of
	points contained in the shape.  The shape will be recognised
	independant of its position
	*/
	public ShapeProtocol Find_Shape(Vector v)
	{
		Point p = zhash.vectormin(v);
		if(p!=null)
		{
			int hashcode = zhash.hash_black(v,p.x,p.y);
			ShapeProtocol s = (ShapeProtocol)(keyed_shapes.get(new Integer(hashcode)));
			return( ((s!=null) && s.equal(v,p.x,p.y))
				? s 
				: null);
		}
		else
		{return(null);
		}
	}
}
