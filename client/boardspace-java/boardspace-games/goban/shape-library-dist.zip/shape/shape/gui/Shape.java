package shape.gui;

import java.applet.Applet;
import java.awt.*;
import java.net.*;
import dlib.*;
import java.io.*;
/** shape library asa main */
public class Shape {
	public static void printhelp(PrintWriter console)
	{ console.println("java Shape.gui.Shape {-sample filename} { -library filename } {-background filename} { -debug } { -showenv } { -lisp }");
	}
	public static void main(String args[])
	{	PrintWriter console = new Deferred_PrintWriter("Shape Fate (details)");
		runner myrunner=null;
		Thread mythread=null;
		boolean debug=false;
		boolean showenv=false;
		boolean lispformat = false;
		String library = "shape-data.zip";
		String sample_library = "sample-shape-data.zip";
		String background = "board.jpg";
		
		for(int i=0;i<args.length;)
		{String thisarg = args[i++];
			if(thisarg.equals("-library")) { library = args[i++]; }
			else if(thisarg.equals("-sample")) { sample_library = args[i++]; }
			else if(thisarg.equals("-showenv")) { showenv=true; }
			else if(thisarg.equals("-debug")) { debug=true; }
			else if(thisarg.equals("-lisp")) { lispformat = true; }
			else if(thisarg.equals("-h")) { printhelp(console); }
			else if(thisarg.equals("-background")) { background = args[i++]; }
			else { console.println("Argument " + thisarg + " not understood"); 
				printhelp(console);
			}
		}
		
		ShapePanel p = new ShapePanel();
		Frame f= new Frame();
		f.setSize(800,400);
		f.add(p);
		if(showenv)
		{ sysinfo.ShowAllProperties(console); 
		}
		myrunner = new runner(p,library,sample_library,lispformat,console,p.getToolkit().getImage(background));
		myrunner.debugging=debug;
		mythread = new Thread(myrunner);
		f.addWindowListener(myrunner);
		f.setVisible(true);
		mythread.start();
	}
}
