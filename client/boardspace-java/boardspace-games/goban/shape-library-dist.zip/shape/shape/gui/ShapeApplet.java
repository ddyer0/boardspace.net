package shape.gui;

import java.applet.Applet;
import java.awt.*;
import java.net.*;
import dlib.*;
import java.io.*;
import beans.*;

public class ShapeApplet extends Applet {
	runner myrunner=null;
	Thread mythread=null;
	PrintWriter myconsole=null;
	public void init()
	{
		String nameparm=getParameter("library");
		String sample_nameparm=getParameter("sample-library");
		String showenv=getParameter("showenv");
		String lispformat=getParameter("lispformat");
		String background_name = getParameter("background");
		boolean islisp = (lispformat!=null) ? new Boolean(lispformat).booleanValue() : false;
		if(sysinfo.isJDK1_1())
		{ShapePanel p = new ShapePanel();
			Dimension dim = this.getSize();
			p.setSize(dim.width,dim.height);
			setLayout(null);		//get the flow layout manager out of the way
			
			try {
				URL looking = new URL(getCodeBase(),background_name);
				Image background = (background_name!=null) 
					? getImage(looking)
					: null; 
				this.add(p);    
				myconsole = new Deferred_PrintWriter();
				if((showenv!=null) && showenv.equals("true")) { sysinfo.ShowAllProperties(myconsole); }
				
				myrunner = new runner(p,
					nameparm!=null ? new URL(getDocumentBase(),nameparm):null,
					sample_nameparm!=null ? new URL(getDocumentBase(),sample_nameparm):null,
					islisp,myconsole,background);
				mythread = new Thread(myrunner);
				mythread.start();
			}
			catch(MalformedURLException e)
			{
				myconsole.println("Malformed URL " + e);
			}}
		else
		{ TextArea text = new TextArea();
			text.setText("Sorry, this applet requires JDK 1.1 support\n" 
				+ "You must use Netscape 4.0.5 or Explorer 4.0.1 or later");
			this.add(text);
		}
	}
}
