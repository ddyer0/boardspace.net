
package shape;
import java.util.*;
import java.awt.Point;
import beans.*;

public class Simple_Group implements Globals
{	public Vector members=null;		//a vector of the current members of the group
	public GridBoard board=null;	//the board which this group refers too
	int colors;				//a set of colors for this group
	
	/* constructor */
	public Simple_Group(int c,GridBoard b,Point seed) 
	{colors=c; 
		board=b; 
		members = new Vector();
		Find_Members(seed); }
	public void Union(Simple_Group other)
	{ for(Enumeration e=other.members.elements(); e.hasMoreElements();)
		{	Point p = (Point)e.nextElement();
			if(!isMember(p)) { members.addElement(p); }
		}	 
	}
	public void Remove()
	{
		for(Enumeration e=members.elements(); e.hasMoreElements(); )
		{ Point p = (Point)e.nextElement();
			board.RemoveWhiteStone(p);
			board.RemoveBlackStone(p);
		}	
	}
	public void Restore()
	{
		for(Enumeration e=members.elements(); e.hasMoreElements(); )
		{ Point p = (Point)e.nextElement();
			if((colors&WhiteColor)!=0) { board.RemoveBlackStone(p); board.AddWhiteStone(p); }
			else { board.RemoveWhiteStone(p); board.AddBlackStone(p); }
		}	
	}
	private boolean isMemberColor(Point p)
	{ if(((WhiteColor&colors)!=0) && board.ContainsWhiteStone(p))
		{return(true);
		}
		if(((BlackColor&colors)!=0) && board.ContainsBlackStone(p))
		{return(true);
		}
		if(((EmptyColor&colors)!=0) && board.isEmpty(p)) 
		{return(true);
		}
		return(false);
	}
	public boolean isMember(Point seed)
	{
		return(zhash.ContainsPoint(members,seed)!=null)	;
	}
	public int Find_Members(Point seed)
	{ if(isMember(seed)) {return(members.size()); }	//already in
		if(isMemberColor(seed)) 
		{ members.addElement(seed);
	  	  Find_Members(new Point(seed.x+1,seed.y));
	  	  Find_Members(new Point(seed.x-1,seed.y));
	  	  Find_Members(new Point(seed.x,seed.y+1));
	  	  Find_Members(new Point(seed.x,seed.y-1));
		}
		return(members.size());
	}
	
	public Vector Find_Liberties()
	{ Vector v = new Vector();
		for(Enumeration e=members.elements(); e.hasMoreElements(); )
		{ Point p = (Point)e.nextElement();
			{Point lib = new Point(p.x+1,p.y);
				if((zhash.ContainsPoint(v,lib)==null)
					&& board.isEmpty(lib)) { v.addElement(lib); }
			}
			{Point lib = new Point(p.x-1,p.y);
				if((zhash.ContainsPoint(v,lib)==null)
					&& board.isEmpty(lib)) { v.addElement(lib); }
			}
			{Point lib = new Point(p.x,p.y+1);
				if((zhash.ContainsPoint(v,lib)==null)
					&& board.isEmpty(lib)) { v.addElement(lib); }
			}
			{Point lib = new Point(p.x,p.y-1);
				if((zhash.ContainsPoint(v,lib)==null)
					&& board.isEmpty(lib)) { v.addElement(lib); }
			}
		}
	    return(v);
	}
	
	public int N_Liberties()
	{
		return(Find_Liberties().size());	
	}	
	public String toString()
	{ return("#<" + getClass().getName() + " " + Size() + "M " + N_Liberties() + "L >");
	}	
	private void AddGroup(Vector v,Point p,int colormask)
	{
		for(Enumeration e = v.elements(); e.hasMoreElements();)
		{ Simple_Group g=(Simple_Group)e.nextElement();
			if(g.isMember(p)) 
			{ //System.out.println(g + " contains " + p);
				return; }
		}
		{Simple_Group g = new Simple_Group(colormask,board,p);
			//System.out.println("new group at " + p);
			v.addElement(g);
		}	
	}
	public boolean isColor(Point p,int colormask)
	{	if(((colormask&WhiteColor)!=0) && board.ContainsWhiteStone(p)) {return(true);}
		if(((colormask&BlackColor)!=0) && board.ContainsBlackStone(p)) {return(true);}
		if(((colormask&EmptyColor)!=0) && board.isEmpty(p)) {return(true); }
		if(((colormask&BorderColor)!=0)	&& !board.isInside(p))
		{return(true);
		}
		return(false);
	}
	
	public Vector Find_Adjacent_Groups(int colormask)
	{	Vector v = new Vector();
		
		for(Enumeration e=members.elements(); e.hasMoreElements(); )
		{ Point p = (Point)e.nextElement();
			{Point lib = new Point(p.x+1,p.y);
				if(isColor(lib,colormask)) { AddGroup(v,lib,colormask); }
			}
			{Point lib = new Point(p.x-1,p.y);
				if(isColor(lib,colormask)) { AddGroup(v,lib,colormask);}
			}
			{Point lib = new Point(p.x,p.y+1);
				if(isColor(lib,colormask)) { AddGroup(v,lib,colormask); }
			}
			{Point lib = new Point(p.x,p.y-1);
				if(isColor(lib,colormask)) { AddGroup(v,lib,colormask); }
			}
			
		}
		return(v);
		
	}
	public int Size() { return(members.size()); }
	
	public int N_Adjacent_Groups(int colormask)
	{	return(Find_Adjacent_Groups(colormask).size());
	}
	
}
