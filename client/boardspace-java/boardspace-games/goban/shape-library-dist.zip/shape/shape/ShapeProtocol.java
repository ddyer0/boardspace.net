
package shape;

import dlib.*;
import java.awt.Point;
import java.util.*;

public interface ShapeProtocol
{ public String getName();
	public Point[] getPoints();
	public int Width();
	public int Height();
	public int hashCode();
	public boolean ContainsPoint(int x,int y);
	public boolean equal(Vector v,int x,int y);
	public boolean equal(Vector v2);
	public ResultProtocol Fate_Of_Shape(NamedObject move_spec,NamedObject x_pos,NamedObject y_pos,int introns);
	public String Ascii_Picture();
	public SingleResult Exact_Fate_Of_Shape( NamedObject move_spec, NamedObject x_pos, 
		NamedObject y_pos,int introns,int libs);
	public Point Position_To_Play(SingleResult r);
	public Point Position_To_Play(SingleResult r,SingleResult other);
}
