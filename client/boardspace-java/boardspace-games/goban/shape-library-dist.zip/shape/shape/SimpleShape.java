package shape;
import dlib.*;
import java.awt.Point;
import java.util.*;
import java.io.Serializable;

public class SimpleShape extends NamedObject implements Globals,Serializable
{
	public Point points[]=null;						//the normalized list of points in the shape
	
	public Point[] getPoints()
	{return(points); 
	}
	
	public int Width()
	{	return(zhash.vectorwidth(points));
	}
	
	public int Height()
	{ return(zhash.vectorheight(points));
	}
	
	public int hashCode()
	{	return(zhash.hash_black(points));
	}
	public String Ascii_Picture()
	{ return(zhash.Ascii_Picture(points));	
	}
	public boolean ContainsPoint(int x,int y)
	{ return(zhash.hasmember(points,x,y));
	}
	
	/* compare a hash match to be sure its a real match.  In 
	"production" mode this somewhat lengthly check should be
	able to be eliminated
	*/
	public boolean equal(Vector v2,int xmin,int ymin)
	{
		int l1 = points.length;
		int l2 = v2.size();
		if(l1==l2)
    	{ for(int i=0; i<l1; i++)
    		{ Point p1 = points[i];
				if(!zhash.hasmember(v2,p1.x+xmin,p1.y+ymin)) 
				{System.out.println("points differ");
					return(false); /* some point doesn't match */
				}
    		}
    		return(true); /* all points match */
    	}		
    	System.out.println("lengths differ");
		return(false); /* different lengths */
	}
	
	public boolean equal(Vector v2)
	{
		
		Point p = zhash.vectormin(v2);
		return(equal(v2,p.x,p.y));
	}
	/** position to play */
	public final Point Position_To_Play(SingleResult r)
	{
		int ord = r.Ordinal_Place_to_Play();
		if((ord>0) && (ord<=points.length))
		{ return(points[ord-1]);
		}
		else 
		{return(null); 
		}	
	}
	/** do some meta analysis based on the combined results for moving first and
	moving second.  If the results are the same, and the result is either strictly
	alive or strictly dead, then there is no need to move, even as a ko threat */
	public final Point Position_To_Play(SingleResult r,SingleResult other)
	{
		if(other!=null)
		{ NamedObject r_fate = r.Fate();
  		  NamedObject other_fate = other.Fate();
  		  if((r_fate==other_fate) 
  		  	&& (//(r_fate==Fate_Alive)	|| (r_fate==Fate_Alive_With_Eye)||
					(r_fate==Fate_Dead) || (r_fate==Fate_Dead_With_Eye)))
			{ return(null); /* no move is necessary */
			}
		}
		return(Position_To_Play(r));
	}
	
}
