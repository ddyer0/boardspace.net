
package shape;
import dlib.*;

public interface Globals
{	public boolean CheckDuplicates=true;
	public static final int shape_database_generation = 7;		//shapes up to this size are in the db
	public static final int max_board_size = 19;							//maximum go board size
	
	/* globals used in the shape fate engine to describe the potision of the shape
	on the board, and who is to move first */
	public static final NamedObject Move_First = new NamedObject("Move_First");
	public static final NamedObject Move_Second = new NamedObject("Move_Second");
	public static final NamedObject At_Left = new NamedObject("At left");
	public static final NamedObject At_Center = new NamedObject("At Center");
	public static final NamedObject At_Right = new NamedObject("At Right");
	public static final NamedObject At_Top = new NamedObject("At Top");
	public static final NamedObject At_Bottom = new NamedObject("At Bottom");
	
	public static final NamedObject move_orders[] = { Move_First, Move_Second };
	public static final NamedObject move_x_positions[] = { At_Left, At_Center, At_Right };
	public static final NamedObject move_y_positions[] = { At_Top, At_Center, At_Bottom };
	
	/* decodes of integer values for fate */
	public static final NamedObject Fate_Alive = new NamedObject("Alive");
	public static final NamedObject Fate_Alive_In_Ko = new NamedObject("Alive-in-Ko");
	public static final NamedObject Fate_Seki = new NamedObject("Seki");
	public static final NamedObject Fate_Dead = new NamedObject("Dead");
	public static final NamedObject Fate_Dead_In_Ko = new NamedObject("Dead-in-Ko");
	public static final NamedObject Fate_Repetition = new NamedObject("Repetition");
	public static final NamedObject Fate_Indeterminate = new NamedObject("Indeterminate");
	public static final NamedObject Fate_No_Eyes = new NamedObject("No-Eyes");
	public static final NamedObject Fate_Alive_With_Eye = new NamedObject("Alive-with-Eye");
	public static final NamedObject Fate_Dead_With_Eye = new NamedObject("Dead-with-Eye");
	public static final NamedObject Fate_Unknown = new NamedObject("Unknown");
	public static final NamedObject Fate_Impossible = new NamedObject("Impossible");
	
	public static final NamedObject Fates_Index[] =
	{	Fate_Alive, Fate_Alive_In_Ko, Fate_Seki,						  //0,1,2
		Fate_Dead, Fate_Dead_In_Ko,												  	//3,4
			Fate_Repetition, Fate_Indeterminate, Fate_No_Eyes,	  //5,6,7
			Fate_Alive_With_Eye, Fate_Dead_With_Eye, Fate_Unknown,//8,9,10
			Fate_Impossible, Fate_Impossible, Fate_Impossible,		//11,12,13
			Fate_Impossible, Fate_Impossible};											//14,15
	
	public static final NamedObject Fate_Aux_Null = new NamedObject("");
	public static final NamedObject Fate_Aux_Ko = new NamedObject("Ko");
	public static final NamedObject Fate_Aux_NoMoves = new NamedObject("No Legal Moves");
	public static final NamedObject Fate_Aux_Outnumber = new NamedObject("Outnumbered");
	public static final NamedObject Fate_Aux_Super = new NamedObject("Numerical Superiority");
	public static final NamedObject Fate_Aux_Benson = new NamedObject("Absolutely safe");
	public static final NamedObject Fate_Aux_Error = new NamedObject("** Undefined **");
	public static final NamedObject Fates_Aux_Index[] =
	{Fate_Aux_Null,
		Fate_Aux_Ko,
			Fate_Aux_NoMoves,
			Fate_Aux_Outnumber,
			Fate_Aux_Super,
			Fate_Aux_Benson,
			Fate_Aux_Error,
			Fate_Aux_Error   };
	
	public static final String Ordinal_Move_String[]=
	{ "@0", "@1","@2","@3","@4","@5","@6", 											    //these should occur
		" db error @7", "db error @8", "db error @9", 								  //these should not occur
			" db error @10", "db error@11", "db error@12", "db error @13",	//these should not occur
			" pass",		//special code, 14=pass
			" outside" //special code 15=play outside liberty
		};
	public static final int ordinal_move_pass = 14;		//position of "pass" above
	public static final int ordinal_move_outside = 15;//position of "outside" above
	
	/* color codes, defined to they can be used as a bitmask */
	public static final int WhiteColor=1;	//white stone
	public static final int BlackColor=2;	//black stone
	public static final int EmptyColor=4;	//neither color
	public static final int BorderColor=8;//off the board
	
}
