package shape;
/** online entertainment while the shape library is loading */
public interface LoadProgress
{	public void LoadNotify(ShapeProtocol shape);
}
