package shape;

import dlib.*;
import java.awt.Point;
import java.util.*;
/*
// header - edit "Data/yourJavaHeader" to customize
// contents - edit "EventHandlers/Java file/onCreate" to customize
//
*/
public class ShapeNormalizer extends SimpleShape implements ShapeProtocol
{
	OneShape	reference_shape;
	int permutation_code;
	
	/* constructor */
	ShapeNormalizer(OneShape shape,Point pts[],int code)
	{
		reference_shape = shape;
		name = shape.name + " p" + code;
		points = pts;
		permutation_code = code;
	}
	
	/* return the result code array for a particular position, permuting it approprately */
	private ResultCode resultsarray(NamedObject move_spec,NamedObject x_pos,NamedObject y_pos)
	{ //System.out.println("location " + x_pos + " " + y_pos);
		
		
		if((x_pos==At_Center) || (y_pos==At_Center))
		{/* at an edge */
			int side = (y_pos == At_Top) ? 0 
				: (y_pos==At_Bottom) ? 2 
				: (x_pos==At_Right) ? 1 : 3;
			side -= permutation_code&3;	//rotate back however many steps
			switch(side&3)
			{
			case 0: y_pos=At_Top; x_pos=At_Center; break;
			case 1: x_pos=At_Right; y_pos=At_Center; break;
			case 2: y_pos=At_Bottom; x_pos = At_Center; break;
			case 3:	x_pos=At_Left; y_pos=At_Center; break;
			}
		}else
		{/* at a corner */
			int corner = (x_pos == At_Left) //encode the starting corner
				? ((y_pos==At_Top) ? 0 : 3)
				: (y_pos==At_Top) ? 1 : 2;
			corner -= (permutation_code&3);	//rotate back some number of steps
			switch(corner&3)
			{case 0: x_pos = At_Left; y_pos = At_Top; break;
			case 1: x_pos = At_Right; y_pos = At_Top; break;
			case 2: x_pos = At_Right; y_pos=At_Bottom; break;
			case 3: x_pos = At_Left; y_pos = At_Bottom; break;
			}
		}
		
		if((permutation_code&4)!=0)
		{
			if(y_pos==At_Top) { y_pos=At_Bottom; }
			else if (y_pos==At_Bottom) { y_pos=At_Top; }
		}
		
		// System.out.println("  becomes " + x_pos + " " + y_pos);
		return(reference_shape.Fate_Of_Shape_Results(move_spec,x_pos,y_pos));
	}
	
	private ResultProtocol Fate_Of_Shape_Internal(NamedObject move_spec,NamedObject x_pos,NamedObject y_pos,int introns)
	{	ResultCode r=resultsarray(move_spec,x_pos,y_pos);
		return(r!=null? r.results[introns] : null);
	}
	public ResultProtocol Fate_Of_Shape(NamedObject move_spec,NamedObject x_pos,NamedObject y_pos,int introns)
	{
		return(Fate_Of_Shape_Internal(move_spec,x_pos,y_pos,introns));
	}
	public SingleResult Exact_Fate_Of_Shape( NamedObject move_spec, NamedObject x_pos, 
		NamedObject y_pos,int introns,int libs)
	{	
		ResultProtocol	r = Fate_Of_Shape(move_spec,x_pos,y_pos,introns);
		return((r!=null) ? r.Fate_for_N_Liberties(libs) : null);
	}
	
	public OneShape NormalizedCopy()
	{	Hashtable v=new Hashtable();
		for(int moving=0; moving<move_orders.length; moving++)
		{NamedObject mv = move_orders[moving];
			for(int move_x=0;move_x<move_x_positions.length;move_x++)
			{ NamedObject mx = move_x_positions[move_x];
				for(int move_y = 0; move_y<move_y_positions.length; move_y++)
				{ NamedObject my = move_y_positions[move_y];
					ResultCode results = resultsarray(mv,mx,my);
					if(results!=null) 
					{ int geocode = zhash.Encode_Move_Geometry(mv,mx,my);
						ResultCode old = (ResultCode)(v.get(results));
						if(old!=null) { old.positions |= geocode; }
						else { old = new ResultCode(geocode,results.results);
							v.put(results,old);
						}
					}
				}
			}}
		{ int i=0 ;
			ResultCode res[] = new ResultCode[v.size()];
			for(Enumeration e = v.elements(); e.hasMoreElements(); i++)
			{ ResultCode r = (ResultCode)e.nextElement();
				res[i] = r;
			}
			return(new OneShape(this.name +" ncopy",points,res));
		}
	}
}
