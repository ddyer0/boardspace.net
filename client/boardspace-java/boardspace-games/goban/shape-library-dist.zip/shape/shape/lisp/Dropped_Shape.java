package shape.lisp;
import shape.*;
import dlib.*;
import java.util.*;
import java.awt.Point;
import java.io.*;
import java.net.*;

/** this is an extension of OneShape to handle cases where adding a white stone
creates multiple eye shapes without connecting the entire group. These "drop-in shapes"
used to be handled by some elaborate special cases in the search logic, but are now
rolled into the standard mechanism.

The old lisp-based library contains dropped shapes associated with their parent
shapes.  
*/
public class Dropped_Shape extends OneShape implements Globals,ShapeProtocol
{	static Vector All_Dropped_Shapes=new Vector();
	int play_at;
	int dropped_position;
	ShapeProtocol parent_shape;
	
	/** constructor */
	public Dropped_Shape(Point p[],ResultCode res[],int play,int positions,ShapeProtocol parent)
	{ super(parent.getName(),p,res);
		play_at = play;
		dropped_position = positions;
		name= name + "@ " + play_at + ResultCode.decode_position_bit(dropped_position);
		parent_shape = parent;	
	}
	
	/* constructor for URLs */
	static public ShapeLibrary Read_ShapeLibrary(URL filename,PrintWriter console)
	{	 return(ProcessShapeData(reader.ReadURL(filename,console),console));	
	}
	/* constructor for files */
	static public ShapeLibrary Read_ShapeLibrary(String filename,PrintWriter console)
	{	 return(ProcessShapeData(reader.ReadFile(filename,console),console));
	}
	static ShapeLibrary ProcessShapeData(Vector shapedata,PrintWriter console)
	{
		if(shapedata!=null) 
		{ ShapeLibrary lib = new ShapeLibrary(shapedata,console);
			Dropped_Shape.Add_Dropped_Shapes(lib,console);
			lib.Build_Vectordata(console);
			lib.Save_ShapeLibrary("shapelib.job",console);
			return(lib);
		}
		return(null);
	}
	
	/** called from OneShape constructor. */
	static public void Make_Dropped_Shapes(ShapeProtocol par,LList c)
	{	int len = LList.LList_Length(c);
		for(int i=0;i<len;i++) 
		{ LList dshape = (LList)c.Contents();
			c=c.Next();
			int rv=new Integer((String)(dshape.Contents())).intValue();
			dshape=dshape.Next();
			int rp=new Integer((String)(dshape.Contents())).intValue();
			dshape=dshape.Next();
			{OneShape dropped_shape = Make_Lisp_DB_Shape(new LList("MODIFY-SHAPE",(LList)dshape.Contents()));
				/* important point here, the introns for the dropped shapes in this 
				database are stored with respect to the parent shape, not the actual
				shape.  So to make an viable, independant shape, we have to drop
				that bit out of the results */
				//System.out.println("Cleanup for " + name);
				for(int idx=0;idx<dropped_shape.results.length;idx++)
				{ dropped_shape.results[idx].RemoveBit(rv);
				}
				All_Dropped_Shapes.addElement(new Dropped_Shape(
					dropped_shape.points,dropped_shape.results,rv,rp,par));
				
				//System.out.println(" + " + len + " dropped shapes" + s);
			}}
	}
	
	public static OneShape Make_Lisp_DB_Shape(LList rspec)
	{
		/* this ugliness creates a OneShape structure from the linked list/vector
		structure derived from the old lisp database 
		*/
		OneShape sh = new OneShape();	
		while(rspec!=null)
		{ String key = (String)rspec.Contents();
			rspec=rspec.Next();
			Object contents = rspec.Contents();
			rspec = rspec.Next();
			if(key.equals("MODIFY-SHAPE"))
			{ sh.picture = (String)contents;
				sh.points = zhash.Make_Point_Array(sh.picture);
				//System.out.println(picture + " points " + points + " code " + hashcode);
			}
			else if(key.equals(":NAME"))
			{ sh.name = (String)(contents);
			}
			else if(key.equals(":KEY-POINTS"))
	    	{sh.key_points = (LList)contents;
	    	}
			else if(key.equals(":FATE-COMMENT"))
	    	{sh.fate_comment = (String)contents;
	    	}
			else if(key.equals(":DROPPED-SHAPES"))
	    	{ LList c = (LList)contents;
				Dropped_Shape.Make_Dropped_Shapes(sh,c);	//for side effect only, dropped shapes are remembered elsewhere
	    	}
			else if(key.equals(":FATE"))
			{ LList res = (LList)contents;
				int len = LList.LList_Length(res);
				ResultCode r[] = new ResultCode[len];	 
				sh.results=r;
				for(int i=0; i<len; i++) 
				{ LList oneres = (LList)res.Contents();			  
					res=res.Next();
					int poscode = (new Integer((String)(oneres.Contents()))).intValue();
					oneres = oneres.Next();
					r[i] = new ResultCode(poscode,(Vector)(oneres.Contents()));
				}
			}
			else
			{/* unknown key */
				System.out.println("Key " + key + " not handled in shape "+sh);
			}
			
		}
		return(sh);
	}
	static public void Add_Dropped_Shapes(ShapeLibrary lib,PrintWriter console)
	{
		/* build the dropped-shape elements cautiously, because they're not all
		in one place, initially.  for example the "knights move" shape arises
		in two ways, derived from bent for and also from crooked four"
		*/  
		console.println("Adding " + All_Dropped_Shapes.size() + " dropped shapes");  
		for(Enumeration e = All_Dropped_Shapes.elements();
			e.hasMoreElements(); )
		{Dropped_Shape s=(Dropped_Shape)e.nextElement();
	   	 lib.BuildOneShape(s,console);
		}
	}
}
