/*
*
* reader
*
*/
package shape.lisp; 
import shape.*;
import dlib.*;
import java.io.*;
import java.net.*;
import java.util.*;

/** this reader reads the go shape database in it's original "Lispm" form
and produces the java compatible internal form based on the
ShapeLibrary class */
public class reader {
	
	Reader stream;
	int line_number=1;
	String saved_token=null;
	
	private char readch() throws IOException
	{
		int c = stream.read();
		if(c==-1) { throw new IOException();}
		if(c=='\n')line_number++;
		return((char)c);
	}
	/** singletons are characters which constitute a complete token, for example [ and ]
	*/
	private boolean is_singleton(String str)
	{	return(str!=null
		&& (str.length()==1)
			&& (is_singleton_char(str.charAt(0))));
	}
	private boolean is_singleton_char(char ch)
	{	switch(ch)
		{ case '(': case ')': case '|': case '\"': case '#':
			return(true);
		}
		return(false);
	}
	private void reread_token(String str) { saved_token = str; }
	
	private String parse_token()
	{	if(saved_token==null)
		{
			StringBuffer s = new StringBuffer();
			int nchars = 0;
			boolean done=false;
			
			try
			{do 
				{ char ch = readch();
					if (Character.isWhitespace(ch)) 
					{
						if(nchars>0) done=true; 
					}
					else if (is_singleton_char(ch))
					{ reread_token(new Character(ch).toString());
						done=true;
					}
					else { s.append(ch); nchars++; }
				} while(!done);
			} 
			catch (IOException err) {};
			
			if(nchars>0) 
			{ String val = new String(s); 
				//errors.println("Token: " + val);
				return(val);
			}
		}
		
		{String v =saved_token;
			//errors.println("Token: " + v);
			saved_token=null;
			return(v);
		}}
	
	/* constructor */
	reader(Reader r) 
	{ stream=r;
	}
	
	
	Vector Make_Vector(LList l2)
	{ Vector v = new Vector();
		while(l2!=null)
        { v.addElement(l2.Contents());
			l2 = l2.Next();
        }
		return(v);
	}
	
	Object readlist()
	{	LList listsofar=null;
		LList listhead =null;
		Object token=null;
		do {
			token = readtoken();
			boolean isstring = (token instanceof String);
			
			if(isstring && token.equals("."))
			{ /* make dotted lists into normal lists */
				token = readtoken();
				isstring = (token instanceof String);
			}
			
			if(isstring && token.equals(")"))
			{ return(listhead);
			}else 
			if(token!=null)
			{
				LList more = new LList(token,null);
				if(listsofar==null)
				{ listsofar = more;
					listhead = more;
				}else
				{ listsofar.Set_Next(more);
					listsofar = more;
				}
				
			};
		} while(token!=null);
		return(listhead);
	}
	
	String parse_quoted_string(char terminal)
	{ int nchars = 0;
		boolean quote=false;
		StringBuffer s = new StringBuffer();
		try
		{boolean done=false;
			do {char ch = readch();
				if(ch=='\\') { quote=true; } 
				else
				{
					/* cr+lf logic */
					if(ch=='\r')
					{ch=readch();
						if(ch=='\n') 
						{//cr + lf, emit lf only
						}else
						{nchars++;s.append('\n');
						}
					}			
					if(!quote && ch==terminal)
					{ done=true; 
					} else 
					{
						nchars++;
						s.append(ch);
					}
					quote=false;
				}} while (!done);
			return(new String(s));
		}
		catch (IOException err) {};
		return(null);
	} 
	
	Object readtoken()
	{ String val= parse_token();
		Object rval = val;
		if(val==null) {}
		else if(val.equals("\""))
		{ rval=parse_quoted_string('\"');
			
		}
		else if (val.equals("|"))
		{ rval=parse_quoted_string('|');		
		}
		else if (val.equals("("))
		{
			rval=readlist();
		}
		else if (val.equals("#"))
		{rval=Make_Vector((LList)readtoken());
		}
		
		//	System.out.println("Line " + line_number + " token " + rval);
		return(rval);
	}
	/** call readstream to read from an opened stream of some sort */
	static Vector ReadStream(InputStream is)
	{ Vector result=null;
		reader s = new reader(new InputStreamReader(is));
	    Object v = null;
	    do { v = s.readtoken();
			if(result==null) { result=new Vector(); }
			if(v!=null)
			{OneShape sh = Dropped_Shape.Make_Lisp_DB_Shape((LList)v);
				//System.out.println("read: " + sh);
				result.addElement(sh); 
			}
		} while (v!=null);
		
		return(result);
		
	}
	
	static Vector ReadURL(URL f,PrintWriter w)
	{	Vector result=null;
		try 
		{result=ReadStream(f.openStream());
		}
		catch (IOException e)
		{ w.println("IO exception for " + f + " " + e); 
		}
		return(result);
	}
	
	/** call ReadFile to absorb the file and return a vector of OneShape objects */
	static Vector ReadFile(String f,PrintWriter w)
	{Vector result=null;
		try 
		{result=ReadStream(new FileInputStream(f));
			
		}
		catch(IOException e) 
		{ w.println("IO Exception " + f + e); 
		}
		return(result);
	}
	
	public static void main(String args[])
	{
		if(args.length>=1) 
		{Vector v = ReadFile(args[0],new Deferred_PrintWriter());
			System.out.println("Read " + v);
		}
	}
	
}
