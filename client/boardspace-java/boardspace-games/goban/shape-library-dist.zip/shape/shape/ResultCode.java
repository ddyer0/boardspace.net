package shape;

import java.util.*;
import dlib.*;
import java.io.StringWriter;
import java.io.PrintWriter;
import java.io.Serializable;
import java.awt.Point;

/** hold the result data for one shape in one position.  If the shape has N stones,
the size of the results array will be 2^N.  Since most positions for most shapes
have the same result, we store a mask indicating which positions on the board
these results apply to.
*/
public class ResultCode implements Serializable
{	int positions;			//a bit set of position codes. 
	ResultProtocol results[];
	
	static int log2(int b)
	{ int i;
		for(i = 0; ((1<<(i+1))-1)<b; i++) ;
		return(i);
	}
	static String posnames[]=
	{ "lt", "ct", "rt",		//left top, center top, right top
		"lc", "cc", "rc",		//left center, center, right center
			"lb", "cb", "rb"};	//left bottom, center bottom,right bottom
    
	public static String decode_position_bit(int b)
	{
		int bitn = log2(b);
		String first = ((bitn&1)!=0)?"F":"S";	//odd positions are "Move First" even are "Move Second"
		return(first+posnames[(bitn>>1)]);
	}
	
	public String toString()
	{ StringWriter codes=new StringWriter();
		int code = positions;
		while(code!=0)
		{ int bit = code&(-code);
			code=code-bit;
			codes.write(decode_position_bit(bit));
		}
		return("#<" + getClass().getName() + " " + codes.toString() + " >");
	}	  
	/* constructor */
	public ResultCode(int pos,ResultProtocol pr[])
	{ positions = pos;
		results = pr;
	}	
	/* constructor for "lisp" database */
	public ResultCode(int pos,Vector rspec)
	{	int size = rspec.size();
		positions = pos;
		results=new ResultProtocol[size];
		for(int i=0;i<size;i++)
		{ Object o = rspec.elementAt(i); 
			if(o instanceof String) { results[i]=SingleResult.Make_SingleResult((String)o); }
			else if(o instanceof LList) {results[i]=MultiResult.Make_MultiResult((LList)o); }
			else {G.Assert(false,"Result " + o + " unexpected type");}
		}
	}
	
	/** compare two ResultCodes and summarize the differences */
	int CompareWith(ResultCode other,PrintWriter w)
	{ int difs=0;
		if(w!=null) { w.println("Compare " + this + " " + other); }
		for(int i=0;i<results.length;i++)
		{  
			if(results[i]!=other.results[i]) /* hashed, so EQ test is appropriate */
			{  if(w!=null) { w.println(i + " " + results[i] + " " + other.results[i]);}
				difs++;
			}
		}
		return(difs);
	}
	/** remove the results corresponding to a bit (that is, exacltly half of them).
	This is a repair step in the process of converting old dropped shapes into the form
	in which we now use them.
	*/
	public void RemoveBit(int bitvalues)
	{//	System.out.println("remove from " + bitvalues);
		while(bitvalues!=0)
		{int len = results.length;
			int logbit = log2(bitvalues)+1;
			int bitval = (1<<(logbit-1));
			bitvalues = bitvalues-bitval;
			//	System.out.println("Remove " + bitval + " " + logbit + " rem " + bitvalues);
			ResultProtocol newres[] = new ResultProtocol[len/2];
			for(int i=0,j=0;i<len;i++) 
			{ if ((i&bitval)==0) 
				{ ResultProtocol rr = results[i]; 
					/* the ordinals are also stored with the parent shape's structure in mind */
					newres[j++] = rr.LowerOrdinals(logbit);
					//System.out.println(i + " " + results[i] + "  -> " + (j-1) + " " + newres[j-1]);
				}
			}
			results=newres;
		}}
	/** create a reordered result list, based on the same set of points appearing in a different
	order.  This requires two changes; first the results themselves must be changed so their
	"ordinal" numbers refer to the new ordinals, then the order in which they appear in the
	"intron" array have to be permuted to reflect the new point list.
	*/
	ResultCode ReOrder(Point old_points[],Point new_points[])
	{	int len = old_points.length;
		int explen = 1<<len;
		int point_reorder[] = new int[len];
		ResultProtocol result[]=new ResultProtocol[explen];
		Point OldMin = zhash.vectormin(old_points);
		Point NewMin = zhash.vectormin(new_points);
		int dx = NewMin.x-OldMin.x;
		int dy = NewMin.y=OldMin.y;
		//System.out.println("Reorder " + this);
		//for(int i=0;i<old_points.length; i++)	{System.out.println(old_points[i] + " " + new_points[i]);}
		
		//for(int i=0;i<results.length;i++) { System.out.println(i + " " + results[i]);}
		
		for(int i=0;i<len;i++) 
		{ Point testpt = old_points[i];
	  	  int old = zhash.IndexOf(new_points,new Point(testpt.x+dx,testpt.y+dy));
	  	  G.Assert(old>=0,"point not found");
	  	  point_reorder[i]=old; 
		}
		for(int i=0;i<explen;i++) 
		{	int new_index=0;
			for(int j=0;j<len;j++) 
			{ int ppos = point_reorder[j];	//bit j becomes bit ppos
				if(((1<<j)&i)!=0) 
				{new_index|=(1<<ppos); 
				}
			}
			result[new_index]=results[i].ReOrder(point_reorder);
		} 		
		for(int i=0;i<explen;i++) {G.Assert(result[i]!=null,"Missed copying a result");}
		//System.out.println("To " );
		//for(int i=0;i<result.length;i++) { System.out.println(i + " " + result[i]);}
		
		return(new ResultCode(positions,result));
	}
	//public static void main(String arg[])
	//{for(int i=0;i<18;i++) 
	//	{System.out.println(i + " " + decode_position_bit(1<<i));	}
	//}
}
