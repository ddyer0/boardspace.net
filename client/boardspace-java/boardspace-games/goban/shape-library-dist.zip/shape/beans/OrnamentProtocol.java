
package beans;

import java.awt.*;

public interface OrnamentProtocol
{
		public Point Location();
		public void Draw(Graphics g,GridBoard b);
}
