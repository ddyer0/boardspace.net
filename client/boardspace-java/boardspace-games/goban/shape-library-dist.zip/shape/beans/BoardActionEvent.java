
package beans;
import java.util.*;
import java.awt.Point;
/** this event is fired when the user clicks ona square of the board.
 The event.object will be the board, and the event.Mouse_At will be the
 board coordinates of the click */
public class BoardActionEvent extends EventObject
{	public Point Mouse_At;

	BoardActionEvent(Object source,int code,String s,Point p)
	{super(source);
	 Mouse_At=p;
}}