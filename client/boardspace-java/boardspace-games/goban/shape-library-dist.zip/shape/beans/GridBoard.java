package beans;
import java.awt.*;
import java.awt.event.*;
import java.awt.*;
import java.beans.*;
import java.io.Serializable;
import java.util.*;

public class GridBoard extends Canvas
                            implements Serializable,
                            MouseListener, MouseMotionListener 
{/* bean properties */

/** the selected zone.  Zones are numbered left-right top-bottom, as though the entire board
    was displayed.  Zones are usually the same size as squares.
 */
 private Point Selected_At=null;
 public Point Mouse_At=null;
 public void setSelected_At(Point p)
 {
 	Selected_At = p;
 	repaint();
 }
 public Point getSelected_At() { return(Selected_At); }
 
 public Vector BlackStones = new Vector();
 public Vector WhiteStones = new Vector();
 public Vector Ornaments = new Vector();

 private Image active_image=null;
 private Dimension active_dim=null;
 
/* the nuber of horizontal zones */
 private int zones_per_row = 19;
 public int getzones_per_row() { return(zones_per_row); };
 public void setzones_per_row(int val) { zones_per_row = val; };
 
/** the number of vertical zones */
 private int zones_per_column = 19;
 public int getzones_per_column() { return(zones_per_column); };
 public void setzones_per_column(int val) { zones_per_column = val; };

 /** the number of horizontal rows to display */
 public int getVisible_Columns() 
 	{ return(grid_visible_columns=(display_x_max-display_x_min+1)); 
 	};

/** the number of vertical rows to display */
 public int getVisible_Rows()
 	 { return(grid_visible_rows=(display_y_max-display_y_min+1)); 
 	 };


/** the last column to be displayed */
 private int board_size_x = 19;
 public int getboard_size_x() { return(board_size_x); };
 public void setboard_size_x(int val) { board_size_x = val; };

/** the full board vertical size (in squares) */
 private int board_size_y = 19;
 public int getboard_size_y() { return(board_size_y); };
 public void setboard_size_y(int val) { board_size_y = val; };


/** the first column to be displayed */
 private int display_x_min = 0;
 public int getdisplay_x_min() { return(display_x_min); };
 public void setdisplay_x_min(int val) { display_x_min = val; };

/** the last column to be displayed */
 private int display_x_max = 18;
 public int getdisplay_x_max() { return(display_x_max); };
 public void setdisplay_x_max(int val) { display_x_max = val; };

/** the first row to be displayed */
 private int display_y_min = 0;
 public int getdisplay_y_min() { return(display_y_min); };
 public void setdisplay_y_min(int val) { display_y_min = val; };

/** the first row to be displayed */
 private int display_y_max = 18;
 public int getdisplay_y_max() { return(display_y_max); };
 public void setdisplay_y_max(int val) { display_y_max = val; };

/** the horizontal size of the whole board, including margins */
 private int size_x = 100;
 public int getsize_x() { return(size_x); };
 public void setsize_x(int val) { size_x = val; };

/** the vertical size of the whole board, including margins */
 private int size_y = 100;
 public int getsize_y() { return(size_y); };
 public void setsize_y(int val) { size_y = val; };


 private Color SelectedColor = new Color((float)0.6,(float)0.4,(float)0.4);
 public Color getSelectedColor() { return(SelectedColor); };
 public void setSelectedColor(Color val) { SelectedColor = val; };

 private Color MouseColor = new Color((float)0.6,(float)0.6,(float)0.6);
 public Color getMouseColor() { return(MouseColor); };
 public void setMouseColor(Color val) { MouseColor = val; };

 private Color ForegroundColor = Color.black;
 public Color getForegroundColor() { return(ForegroundColor); };
 public void setForegroundColor(Color val) { ForegroundColor = val; };

 private Color BackgroundColor = new Color((float)0.4,(float)0.2,(float)0.2);
 public Color getBackgroundColor() { return(BackgroundColor); };
 public void setBackgroundColor(Color val) { BackgroundColor = val; };
 
 public Image Background_Image=null;
 
 private String Background_Image_Name = null;
 public String getBackground_Image_Name() { return(Background_Image_Name); }
 public void setBackGround_Image_Name(String val) { Background_Image_Name = val; }
 
 // truely private data
  int grid_origin_x = 0;
  int grid_origin_y = 0;
  int grid_step_x = 1;
  int grid_step_y = 1;
  int grid_visible_rows = 1;
  int grid_visible_columns = 1;

 public void SeeWholeBoard()
 {	setdisplay_x_min(0);
 	  setdisplay_y_min(0);
 	  setdisplay_x_max(getboard_size_x()-1);
 	  setdisplay_y_max(getboard_size_y()-1);
 		setzones_per_column(getVisible_Columns());
 		setzones_per_row(getVisible_Rows());
 }
  public void SeePartBoard(int xfrom,int yfrom, int xto,int yto)
 {	setdisplay_x_min(Math.max(0,xfrom));
 	  setdisplay_y_min(Math.max(0,yfrom));
 	  setdisplay_x_max(Math.min(xto,getboard_size_x()-1));
 	  setdisplay_y_max(Math.min(yto,getboard_size_y()-1));
 		setzones_per_column(getVisible_Columns());
 		setzones_per_row(getVisible_Rows());
 		repaint();
 }

 /* convert an x,y into a zone number, or -1. */
 private Point zone_for_xy(int x,int y)
 {int minx = grid_origin_x-grid_step_x/2;
  int miny = grid_origin_y-grid_step_y/2;
  int maxx = minx+(grid_visible_columns)*grid_step_x;
  int maxy = miny+(grid_visible_rows)*grid_step_y;
 
 	if(x<minx || x>=maxx || y<miny || y>=maxy) 
	 	{return(null); 
	 	}
 	else
	 {int zone_w = (maxx-minx)/zones_per_column;
	 	int zone_h = (maxy-miny)/zones_per_row;
	 	int vis_square_x = ((x-minx)/zone_w);
	 	int vis_square_y = ((y-miny)/zone_h);
		int square_x = vis_square_x + display_x_min;
		int square_y = vis_square_y + display_y_min;
	  return(new Point(square_x,square_y));
	 }
 }
 void SetGridParameters()
 	{
	square_size_x();	//sets grid_step_x grid_size_x
  square_size_y();	//sets grid_step_y grid_size_y

  int line_height = grid_step_y*(grid_visible_rows-1);
  int line_width = grid_step_x*(grid_visible_columns-1);
  
  /* adjust the line origin and lengths if the board is partial instead of full */
   grid_origin_x = (size_x-line_width)/2;
   grid_origin_y = (size_y-line_height)/2;	
 
  if(display_x_min>0) { line_width+= grid_step_x/2; }
  if((display_x_max+1) < board_size_x) { line_width += grid_step_x/2; }
  if(display_y_min>0) { line_height+= grid_step_y/2; }
  if((display_y_max+1) < board_size_y) { line_height += grid_step_y/2; }
 	}
 	
 private void FinishSetup()
 	{
   setSize(size_x,size_y);
   SeeWholeBoard();	//make sure parameters start consistantly
   setBackground(BackgroundColor);
   addMouseListener(this);
	 addMouseMotionListener(this);
 	}	
 		
 			
 //Constructor sets inherited properties
 public GridBoard(){
		FinishSetup();
	}
 public GridBoard(int size)
 	{ this.board_size_x = board_size_y= size;
 	  FinishSetup();
  }





	public void PaintWhiteStone(Graphics g,Point p)
	{
	 g.setColor(Color.white);
	 PaintStone(g,p);
	}
 	public void PaintBlackStone(Graphics g,Point p)
	{
	 g.setColor(Color.black);
	 PaintStone(g,p);
	}	
 public Point Square_Center(Point p)
 {		int x = p.x-getdisplay_x_min();
			int y = p.y-getdisplay_y_min();
	 	return(new Point(x*grid_step_x+grid_origin_x, y*grid_step_y+grid_origin_y));
 }
 public int Square_Width()
 {	return(grid_step_x);
 }
 public int Square_Height()
 {	return(grid_step_y);
 }
 void PaintStone(Graphics g,Point p)
	{
			if(IsVisible(p)) 
    {
		int x = p.x-getdisplay_x_min();
			int y = p.y-getdisplay_y_min();
			g.fillOval( x*grid_step_x+grid_origin_x-grid_step_x/2,
								  y*grid_step_y+grid_origin_y-grid_step_y/2,
								  grid_step_x,
								  grid_step_y);
		}	
}
	private Point ContainsPoint(Vector v,Point p)
	{	for( Enumeration e=v.elements(); e.hasMoreElements(); )
		{ Point el = (Point)e.nextElement();
		  if(el.equals(p)) return(el);
		 }
		 return(null);
	}
	public boolean isInside(Point p)
	{int x=p.x;
	 int y=p.y;
	 return(	(x>=0) && (x<board_size_x) && (y>=0) && (y<board_size_y));
	}
	public boolean isEmpty(Point p)
	{
		return(isInside(p)
			  && !ContainsWhiteStone(p) && !ContainsBlackStone(p));			
	}
	
/** return true if the board contains a white stone at the indicated point */
	public boolean ContainsWhiteStone(Point p)
	{ return((ContainsPoint(WhiteStones,p)!=null)?true:false);
  }


  /** return true if the board contains a black stone at the indicated point
   */
	public boolean ContainsBlackStone(Point p)
	{ return((ContainsPoint(BlackStones,p)!=null)?true:false);
  }

  /** remove a white stone at the indicated point, return true if there
  was one there to be removed.
  */	
  public boolean RemoveWhiteStone(Point np)
  {	Point p=ContainsPoint(WhiteStones,np);
    if(p!=null) 
    	{ WhiteStones.removeElement(p); 
   		  repaint();
   			return(true); 
    	}
    else { return(false); }
  }

  /** remove a Black stone at the indicated point, return true if there
  was one there to be removed.
  */	
  public boolean RemoveBlackStone(Point np)
  {	Point p=ContainsPoint(BlackStones,np);
    if(p!=null) 
    	{ BlackStones.removeElement(p); 
        repaint();
    	  return(true); 
    	  }
    else { return(false); }
  }
  	
  /** add a black stone to the board.  If it is aready there, do nothing.
   Return true if a stone was added, false if the stone was already there
   */
  public boolean AddBlackStone(Point p)
  { if(!ContainsBlackStone(p)) 
  		{ BlackStones.addElement(p); 
   		  repaint();
 		  	return(true);
  		}
  		else { return(false);
  		}
  }
  /** add a white stone to the board.  If it is aready there, do nothing.
   Return true if a stone was added, false if the stone was already there
   */
  public boolean AddWhiteStone(Point p)
  { if(!ContainsWhiteStone(p)) 
  		{ WhiteStones.addElement(p); 
  		  repaint();
  			return(true);
  		}
  		else { return(false);
  		}
  }
  /** make the board empty */
  public void Clear()
  {	BlackStones.setSize(0);
    WhiteStones.setSize(0);
    Ornaments.setSize(0);
  	repaint();
  }
  public void Clear_Ornaments()
  {	int sz=Ornaments.size();
    Ornaments.setSize(0);
    if(sz>0) { repaint();}
  }
  public void Add_Ornament(OrnamentProtocol o)
  	{ Ornaments.addElement(o);
  	  repaint();
  	}
  public OrnamentProtocol OrnamentAt(Point p)
  {
  	for(Enumeration e=Ornaments.elements(); e.hasMoreElements(); )
  		{ OrnamentProtocol orn = (OrnamentProtocol)e.nextElement();
  		  if(orn.Location().equals(p)) {return(orn);}
  			}	
  	return(null);
  }
  public OrnamentProtocol Remove_Ornament(Point p)
  {
  	OrnamentProtocol orn = OrnamentAt(p);
  	if(orn!=null) { Ornaments.removeElement(orn); repaint();}
  	return(orn);	
  }
  /* return true if the indicated point is visible */
 	public boolean IsVisible(Point p)
  {
	  return(p.x>=getdisplay_x_min() 
					&& p.x <= getdisplay_x_max()
					&& p.y >= getdisplay_y_min()
					&& p.y <= getdisplay_y_max());
	}

 public void real_paint(Graphics realg)
 {Dimension d = getSize();
 	if((active_image==null) || (!active_dim.equals(d)))
 		 { 
 		 	 active_dim=d;
 		   active_image = createImage(d.width,d.height);
 		   if((Background_Image==null) && (Background_Image_Name!=null))
 		   	{ Background_Image = getToolkit().getImage(Background_Image_Name);
 		   }
 		 }
 {Graphics g = active_image.getGraphics();
 Rectangle rb=getBounds();
 int height = size_y= rb.height;
 int width = size_x = rb.width;		//set the current w/h for other calculations

 /* fill background */
 g.setColor(BackgroundColor);
 g.fillRect(0,0,width,height);	//do this anyway, in case the image isn't loaded or found
 if(Background_Image!=null)
 	{ int background_width = Background_Image.getWidth(this);
  		  int background_height = Background_Image.getHeight(this);
  		  int size_y = board_size_y-1;
  		  int size_x = board_size_x-1;
  		  int xo = (display_x_min*background_width)/size_x;
  		  int yo = (display_y_min*background_height)/size_y;
  		  int xe = (display_x_max*background_width)/size_x;
  		  int ye = (display_y_max*background_height)/size_y;
  		  g.drawImage(Background_Image,0,0,width,height,xo,yo,xe,ye,this); 
  		  }
 
 paint_background_zones(g);
 paint_lines(g);
 paint_stones(g);
 paint_ornaments(g);
 }
 realg.drawImage(active_image,0,0,this);
 }
 public void paint(Graphics g)
 { real_paint(g);
 }
 public void update(Graphics g)
 {
 	real_paint(g);
 }
 public void paint_ornaments(Graphics g)
 {
 		for(Enumeration e=Ornaments.elements(); e.hasMoreElements(); )
 		{
 			OrnamentProtocol orn = (OrnamentProtocol)e.nextElement();
 			orn.Draw(g,this);	
 		}
 }
 public void paint_stones(Graphics g)
 {
 		for(Enumeration e=WhiteStones.elements(); e.hasMoreElements(); )
		{
			PaintWhiteStone(g,(Point)e.nextElement())	;
		}
		for(Enumeration e=BlackStones.elements(); e.hasMoreElements(); )
		{
			PaintBlackStone(g,(Point)e.nextElement())	;
		}
	
 	
 } 	
/* we have separate x and y size calculations so int the future, the 
 squares can be slightly nonsquare */ 
public int square_size_x()
{
 int Visible_Rows = getVisible_Rows();
 int Visible_Columns = getVisible_Columns();
 int szx = size_x/(Visible_Columns+1);
 int szy = (int)(size_y/(Visible_Rows+1));
 return(grid_step_x = Math.min(szx,szy));
}
public int square_size_y()
{
	return(grid_step_y = square_size_x());
}
/* paint the lines */
private void paint_lines(Graphics g)
 {SetGridParameters();
  int line_initial_x = grid_origin_x;
  int line_initial_y = grid_origin_y;
  int line_height = grid_step_y*(grid_visible_rows-1);
  int line_width = grid_step_x*(grid_visible_columns-1);
  g.setColor(ForegroundColor);

  if(display_x_min>0) { line_initial_x -= grid_step_x/2; line_width+=grid_step_x/2; }
  if((display_x_max+1)<board_size_x) { line_width+=grid_step_x/2; }
  if(display_y_min>0) { line_initial_y -= grid_step_y/2; line_height+=grid_step_y/2; }
  if((display_y_max+1)<board_size_y) { line_height+=grid_step_y/2; }
  
    
  for(int x=grid_origin_x, col=0; 
      col<grid_visible_columns;
      col++,x+=grid_step_x)
     { g.drawLine(x,line_initial_y,x,line_initial_y+line_height); 
     }
     
  for(int y=grid_origin_y, row=0; 
      row<grid_visible_rows;
       row++,y+=grid_step_y)
     { g.drawLine(line_initial_x,y,line_initial_x+line_width,y); 
 		 }
 } 
 /* paint the shaded background for the zone and mouse zone, if any */
 private void paint_background_zones(Graphics g)
 {
 	
 if(zones_per_row>0 && zones_per_column>0)
 {
  /* paint current zone */
 int x_zone_size =(grid_step_x*grid_visible_columns)/zones_per_column;
 int y_zone_size =(grid_step_y*grid_visible_rows)/zones_per_row;
 
 if(Selected_At!=null)
	 {int sel_x_zone = Selected_At.x;
	 int sel_y_zone = Selected_At.y;
	 int x_zone = sel_x_zone-display_x_min;
	 int y_zone = sel_y_zone-display_y_min;
	 g.setColor(SelectedColor);
	 g.fillRect(grid_origin_x+x_zone*x_zone_size-grid_step_x/2,
	 						grid_origin_y+y_zone*y_zone_size-grid_step_y/2,
	 									x_zone_size+1,
	 									y_zone_size+1);
	 }
 
 if(Mouse_At!=null && !Mouse_At.equals(Selected_At))
	 {
	 	int mouse_x_zone = Mouse_At.x;
	 	int mouse_y_zone = Mouse_At.y;
	 	int x_zone = mouse_x_zone - display_x_min;
	 	int y_zone = mouse_y_zone - display_y_min;
	 	g.setColor(MouseColor);
	 	g.fillRect(grid_origin_x+x_zone*x_zone_size-grid_step_x/2, 
	 						grid_origin_y+y_zone*y_zone_size-grid_step_y/2,
	 				     x_zone_size+1,
	 				     y_zone_size+1);
  	}	
  } /* finished painting zones */
 	
 }
 


 // Mouse listener methods.

    public void mouseClicked(MouseEvent evt) 
    {
    	if((Mouse_At!=null) && !Mouse_At.equals(Selected_At))
    		{FireAction(Mouse_At);
      		repaint();
    	  }
    }

   public void mouseMoved(MouseEvent evt)
   	{
   	 int x = evt.getX();
   	 int y = evt.getY();
   	 Point new_zone = zone_for_xy(x,y);
   	 if((new_zone!=null) && !new_zone.equals(Mouse_At))
   	 {
   	 		Mouse_At = new_zone;
   	 		repaint();
   	 }
    }
   public void mousePressed(MouseEvent evt) {
    }
    
    public void mouseReleased(MouseEvent evt) {
    }
    
    public void mouseEntered(MouseEvent evt) {
    }

    public void mouseExited(MouseEvent evt) {
    Mouse_At = null;
    repaint();
    }

    public void mouseDragged(MouseEvent evt) {
		}
	
	
   private Vector pushListeners=new Vector();    
   public synchronized void addBoardActionListener(BoardActionListener l) {
			pushListeners.addElement(l);
    }
    public synchronized void removeBoardActionListener(BoardActionListener l) {
			pushListeners.removeElement(l);
    }
    /** 
     * This method has the same effect as pressing the button.
     * 
     * @see #addActionListener
     */  
  public void FireAction(Point at) {
		Vector targets;
		synchronized (this) {
		    targets = (Vector) pushListeners.clone();
		}
		BoardActionEvent actionEvt = new BoardActionEvent(this, 0, null,at);
		for (int i = 0; i < targets.size(); i++) {
		    BoardActionListener target = (BoardActionListener)targets.elementAt(i);
		    target.boardActionPerformed(actionEvt);
		}

  }
	
	}