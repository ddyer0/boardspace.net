
package beans;
import java.awt.*;

public class LetterOrnament implements OrnamentProtocol
{
		Point where=null;
		public String text="";
		
		public LetterOrnament(Point p,String s)
		{ 	where=p;
				text=s;
		}
		public Point Location()
		{
			return(where);	
		}
		public void Draw(Graphics g,GridBoard b)
		{	Point center = b.Square_Center(where);
		  int w = b.Square_Width();
		  int h = b.Square_Height();
			g.setColor(Color.gray);
			g.fillRect(center.x-w/4,center.y-h/4,w/2,h/2);
			g.setColor(Color.black);
			g.drawString(text,center.x-w/8,center.y+h/8);
		}
}