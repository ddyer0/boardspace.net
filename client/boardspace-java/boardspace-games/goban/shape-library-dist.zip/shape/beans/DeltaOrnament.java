
package beans;
import java.awt.*;

public class DeltaOrnament implements OrnamentProtocol
{
		Point where=null;
		Color mycolor = null;
		boolean isclosed;
		public DeltaOrnament(Point p,Color c,boolean closed)
		{ 	where=p;
			  mycolor=c;
			  isclosed=closed;
		}
		public Point Location()
		{
			return(where);	
		}
		public void Draw(Graphics g,GridBoard b)
		{	Point center = b.Square_Center(where);
		  int w = b.Square_Width();
		  int h = b.Square_Height();
		  Polygon poly = new Polygon();
		  poly.addPoint(center.x,center.y-h/2-1);
		  poly.addPoint(center.x-w/2-1,center.y+h/3);
		  poly.addPoint(center.x+w/2-1,center.y+h/3);
			g.setColor(mycolor);
			if(isclosed) { g.fillPolygon(poly); } else { g.drawPolygon(poly); }
		}
}