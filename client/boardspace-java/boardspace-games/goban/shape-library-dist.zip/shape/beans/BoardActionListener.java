
package beans;
import java.util.*;

public interface BoardActionListener 
{	public void boardActionPerformed(BoardActionEvent v);
}