java -jar ./pf-joi-full.jar
