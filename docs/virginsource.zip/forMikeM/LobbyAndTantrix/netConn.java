import java.io.*;
import java.net.*;

public class netConn extends Thread {

	final int QueueLength = 128;
	final int ShortLoopDelay = 100;
	final int BufferLength = 256;

	int loopDelay = ShortLoopDelay;
	Socket mySocket = null;
	InputStream myInStream = null;
	OutputStream myOutStream = null;
	boolean doneReading;
	int inBufLength, readResult, outBufLength;
	StringBuffer inString;
	String machineName;
	int machinePort;
	int inQueueRead = 0, inQueueWrite = 0;
	byte outBuf[] = new byte[BufferLength];
	char outChars[] = new char[BufferLength];
	byte inBuf[] = new byte[BufferLength];
	String inQueue[] = new String[QueueLength];
	Thread nCThread = null;
	boolean exitFlag = false;

	public void start() {

		if (nCThread == null) {
			nCThread = new Thread(this);
			nCThread.start();
		}
	}

	public void setExitFlag() {

		exitFlag = true;
	}

	public void setMachineName(String inStr) {

	    machineName = (inStr == null) ? null : new String(inStr);
	}

	public void setMachinePort(int inPort) {

		machinePort = inPort;
	}

	public void setReadLoopDelay(int inDelay) {

		loopDelay = inDelay;
	}

	public boolean haveConn() {

		if ((mySocket != null) && (myOutStream != null)) {
			StringBuffer theBuff = new StringBuffer("999");
			outBufLength = theBuff.length();
			theBuff.getChars(0,outBufLength,outChars,0);
			for (int i=0;i<outBufLength;i++) {
				outBuf[i] = (byte)outChars[i];
			}
			outBuf[outBufLength] = 0x00;
			outBuf[outBufLength+1] = 0x0d;
			outBuf[outBufLength+2] = 0x0a;
			outBufLength = outBufLength + 3;
			try {
				myOutStream.write(outBuf,0,outBufLength);
			} catch (IOException e) {
				System.out.println("IOException on output stream write.");
				return(false);
			}
		} else {
			return(false);
		}
//		System.out.println("haveConn succeeded.");
		return(true);
	}

	public boolean makeConn() {

		try {
			mySocket = new Socket(machineName,machinePort);
		} catch (UnknownHostException e1) {
			System.out.println("UnknownHostException on socket creation.");
		} catch (IOException e2) {
			System.out.println("IOException on socket creation.");
			closeConn();
			return(false);
		}
		try {
			myInStream = mySocket.getInputStream();
		} catch (IOException e) {
			System.out.println("IOException on input stream open.");
			closeConn();
			return(false);
		}
		try {
			myOutStream = mySocket.getOutputStream();
		} catch (IOException e) {
			System.out.println("IOException on output stream open.");
			closeConn();
			return(false);
		}
		return(true);
	}

	public void closeConn() {

		System.out.println("Closing connection.");
		if (myInStream != null) {
			try {
				myInStream.close();
			} catch (IOException e) {
				System.out.println("IOException on input stream close.");
			}
			myInStream = null;
		}
		if (myOutStream != null) {
			try {
				myOutStream.close();
			} catch (IOException e) {
				System.out.println("IOException on output stream close.");
			}
			myOutStream = null;
		}
		if (mySocket != null) {
			try {
				mySocket.close();
			} catch (IOException e) {
				System.out.println("IOException on socket close.");
			}
			mySocket = null;
		}
	}

	public String getInputItem() {

		if ((inQueueRead != inQueueWrite) && (inQueue[inQueueRead] != null)) {
			String tempString = new String(inQueue[inQueueRead]);
			inQueueRead += 1;
			if (inQueueRead == QueueLength) {
				inQueueRead = 0;
			}
			return(tempString);
		} else {
			return(null);
		}
	}

	public void putInputItem(String inStr) {

		int newInQueueWrite = inQueueWrite + 1;
		if (newInQueueWrite == QueueLength) {
			newInQueueWrite = 0;
		}
		if (newInQueueWrite != inQueueRead) {
			inQueue[inQueueWrite] = new String(inStr);
			inQueueWrite = newInQueueWrite;
		} else {
			System.out.println("Tried to write to full inQueue.");
		}
	}

	public synchronized boolean sendMessage(StringBuffer theBuff) {

		if ((mySocket != null) && (myOutStream != null)) {
			outBufLength = theBuff.length();
			theBuff.getChars(0,outBufLength,outChars,0);
			for (int i=0;i<outBufLength;i++) {
				outBuf[i] = (byte)outChars[i];
			}
			outBuf[outBufLength] = 0x00;
			outBuf[outBufLength+1] = 0x0d;
			outBuf[outBufLength+2] = 0x0a;
			outBufLength = outBufLength + 3;
			try {
				myOutStream.write(outBuf,0,outBufLength);
			} catch (IOException e) {
				System.out.println("IOException on output stream write.");
				return(false);
			}
		} else {
//			System.out.println("mySocket: "+mySocket+" myOutStream: "+myOutStream);
			return(false);
		}
		return(true);
	}

	public void doDelay(int inDelay) {

		try {
			sleep(inDelay);
		} catch (InterruptedException e) {
			System.out.println("Sleep interrupted.");
		}
	}

	public void run() {

		for (;;) {
			if (exitFlag) {
				myOutStream = null;
				break;
			}
			if ((mySocket != null) && (myInStream != null)) {
				try {
					inBufLength = 0;
					doneReading = false;
					while (!doneReading) {
						readResult = myInStream.read(inBuf,inBufLength,1);
						if (readResult == -1) {
							System.out.println("Read error.");
							doneReading = true;
						} else {
							if (inBuf[inBufLength] == 0x0a) {
								doneReading = true;
							}
							inBufLength = inBufLength + 1;
						}
					}
				} catch (IOException e) {
					System.out.println("IOException on input stream read.");
					closeConn();
					continue;
				}
				inString = new StringBuffer();
				for (int i=0;i<(inBufLength-3);i++) {
					inString.append((char)inBuf[i]);
				}
				putInputItem(inString.toString());
			}
			doDelay(loopDelay);
		}
	}
}