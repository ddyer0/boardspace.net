import java.applet.Applet;
import java.awt.TextField;

public class genRunCode extends Applet {

	public void init() {

		String serverName = getParameter("servername");
		String randStr = "...internetivity";
		String composeStr = "";
		int nextByte, nextNibble;
		for (int cCtr=0;cCtr<16;cCtr++) {
			if (cCtr < serverName.length()) {
				nextByte = serverName.charAt(cCtr);
			} else {
				nextByte = randStr.charAt(cCtr);
			}
			nextNibble = (nextByte >> 4);
			if (nextNibble == 0) {
				composeStr += (char)(80);
			} else {
				composeStr += (char)(nextNibble + 64);
			}
			nextNibble = nextByte - (nextNibble * 16);
			if (nextNibble == 0) {
				composeStr += (char)(80);
			} else {
				composeStr += (char)(nextNibble + 64);
			}
		}
		System.out.println("runcode for "+serverName+" is: '"+composeStr+"'");
		TextField myTF = new TextField(composeStr);
		myTF.setEditable(false);
		add(myTF);
		myTF.reshape(10,10,200,20);
	}
}