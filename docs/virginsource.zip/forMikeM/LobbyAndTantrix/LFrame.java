import java.awt.*;
import java.applet.Applet;
import java.util.StringTokenizer;
import java.util.Date;

public class LFrame extends Frame {

	RootApplet theParent;
	Lobby theLobby;

	public LFrame(String inStr, RootApplet inParent, Lobby inLobby) {

		super(inStr);
		theParent = inParent;
		theLobby = inLobby;
	}

	public boolean handleEvent(Event e) {

		if (e.id == Event.WINDOW_DESTROY) {
			theParent.killFrame(this);
		} else if (e.id == Event.WINDOW_ICONIFY) {
			theLobby.stop();
		} else if (e.id == Event.WINDOW_DEICONIFY) {
			theLobby.start();
		}
		return(super.handleEvent(e));
	}
}
