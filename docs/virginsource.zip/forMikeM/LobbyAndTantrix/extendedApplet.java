import java.applet.Applet;

public abstract class extendedApplet extends Applet {

	public abstract void init(Applet inRoot, int numOpponents, String inRole, String inName, int inSessNum, int inGamePos, String inPW);

	public abstract void kill();

	public abstract void killFrame(ExtFrame inF);

	public abstract void doTouch();
}