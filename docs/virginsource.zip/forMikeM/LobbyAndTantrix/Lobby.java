import java.awt.*;
import java.applet.Applet;
import java.util.StringTokenizer;
import java.util.Date;

public class Lobby extends extendedApplet implements Runnable {

	public boolean loadSucceeded = false;
	public boolean loadFailed = false;
	boolean launchingGame = false;
	loadThread myLT = null;
	boolean loadNeeded = false;
	boolean startFlashFlag = false;
	long startFlashTime;
	int startingSessNum = -1;
	final int FLASHINTERVAL = 500;
	String recordKeeper = null;
	int badNameSoundNumber = -1;
	final int INFODELTAX = 40;
	final int INFODELTAY = 10;
	final int INFOHEIGHT = 30;
	final int INFOWIDTH = 30;

	final long CONNECTIONTIMEOUTINTERVAL = 60000;		/* give up after 1 minute */
	long connectionTimeout;
	int lobbyIdleTimeoutInterval;
	long lobbyIdleTimeout;
	boolean gaveWarning = false;
	final Color lightBlue = new Color(153,153,255);
	final Color rose = new Color(255,204,204);
	final Color lightGreen = new Color(204,255,204);
	final int DEFAULTLOOPDELAY = 200;
	final int REPEATINTERVAL = 250;
	final String DEFAULTFRAMENAME = "Lobby";
	final String DEFAULTSESSIONNAME = "Session";
	final int MAXNUMBEROFSESSIONS = 20;			/* Remember that the lobby will use session #0 */
	final int MAXPLAYERSPERGAME = 4;
	final int GAMEHEIGHT = 250;
	final int MAXNUMBEROFUSERS = 100;
	int numberOfUsers = MAXNUMBEROFUSERS;
	int numOccupants = 0;
	final int USERHEIGHT = 30;
	final int GAMESCROLLWIDTH = 290;
	int gameScrollHeight = 280;
	int userScrollHeight = 280;
	final int SCROLLBARWIDTH = 20;
	final int GAMEIMAGEWIDTH = GAMESCROLLWIDTH - SCROLLBARWIDTH;
	final int USERSCROLLWIDTH = 190;
	final int USERIMAGEWIDTH = USERSCROLLWIDTH - SCROLLBARWIDTH;
	final int PLAYERTITLEYOFFSET = 100;
	final int SPECTATORTITLEXOFFSET = 160;
	final int SPECTATORWIDTH = 40;
	final int POLYHALFHEIGHT = 12;
	final int SPECTATORBUTTONYOFFSET = 30;
	final int MAXNUMBEROFSPECTATORS = 8;
	final int STARTXOFFSET = 65;
	final int STARTYOFFSET = 65;
	int numberOfSpectators = MAXNUMBEROFSPECTATORS;
	final int PolyParams[] = {21,18,6,1,2};
	final int POLYXOFFSETS[] = {PolyParams[1]+6,2*PolyParams[1]+6,PolyParams[1]+6,2*PolyParams[1]+6};
	final int POLYYOFFSETS[] = {PLAYERTITLEYOFFSET + 3 + PolyParams[0] + 1,PLAYERTITLEYOFFSET + 3 + 5*PolyParams[0]/2 + 1,PLAYERTITLEYOFFSET + 3 + 4*PolyParams[0],PLAYERTITLEYOFFSET + 3 + 11*PolyParams[0]/2};
	ExtFrame playFrame[] = new ExtFrame[MAXNUMBEROFSESSIONS+1];
	extendedApplet theGame[] = new extendedApplet[MAXNUMBEROFSESSIONS+1];
	chatApplet lobbyChat = null;
	int sessionNumbers[] = new int[MAXNUMBEROFSESSIONS+1];
	String sessionPasswords[] = new String[MAXNUMBEROFSESSIONS+1];
	int chatHeight = 180;
	int chatWidth = 500;
	netConn myNetConn = null;
	netConnAux myNetConnAux = null;
	Image wholeScene = null;
	Graphics wholeSceneGC = null;
	final int IDLE = 0;
	final int UNCONNECTED = 1;
	final int NOTINLOBBY = 2;
	final int UNNAMED = 3;
	final int ACTIVE = 4;
	int lobbyState = UNCONNECTED, oldLobbyState = -1;
	int userIDs[] = new int[MAXNUMBEROFUSERS];
	String userNames[] = new String[MAXNUMBEROFUSERS];
	boolean markedInLastRefresh[] = new boolean[MAXNUMBEROFUSERS];
	int userSessLocations[] = new int[MAXNUMBEROFUSERS];
	int userPlayLocations[] = new int[MAXNUMBEROFUSERS];
	int movingToSess = -1;
	int movingToPlay = -1;
	int mainLoopDelay;
	final int MAXSTRINGLENGTH = 12;
	Font basicFont,boldBasicFont,bigFont;
	StringBuffer tempSB;
	Button submitButton = null;
	Label nameRequest = null, nameSpec = null;
	TextField nameInput = null;
	final int lobbySessionInt = 0;
	Polygon playPoly, widePoly, narrowPoly, startPoly;
	boolean showChat = false, showGames = false, showUsers = false, refreshGames = true, refreshUsers = true;
	Thread myThread = null;
	boolean messageConsumed = true;
	String tempString = null;
	String serverName = null;						/* parameters from html page */
	String lobbyServerPort = null;
	int serverPortInt;
	String frameName, appletName, documentName, numberOfSessionsStr, usersPerSessionStr;
	String sessionIdleTimeStr, minPlayersForLaunchStr;
	int numberOfSessions = 2, usersPerSession, sessionIdleTime, minPlayersForLaunch = 2;
	String userShapeStr, sessionName;
	final int RECTUSER = 0;
	final int ROUNDRECTUSER = 1;
	final int OVALUSER = 2;
	final int HEXAGONUSER = 3;
	int userShape;
	boolean initialized = false;
	boolean exitFlag = false;
	boolean smallRepeatFlag = false, bigRepeatFlag = false, repeatDirection;
	long repeatWait;
	int scrollingArea;
	boolean draggingMe = false;
	int spectatorOf = -1, launchSpectator = -1;
	boolean highlightPlay = false, highlightMyPlay = false;
	Rectangle ownerRect;
	Point tempPoint, playPoint = new Point(-1,-1);
	long lastRefresh = 0, currentTime;
	final int ACTIVEREFRESHINTERVAL = 20000;	/* 20 seconds */
	final int SLEEPREFRESHINTERVAL = 300000;	/* five minutes */
	int refreshInterval = ACTIVEREFRESHINTERVAL;
	boolean updatePending = false;
	boolean justDidReshape = false;

	String lobbyNames[] = new String[MAXNUMBEROFUSERS];
	final int GAMESESSIONUNKNOWN = 100;
	final int GAMESESSIONIDLE = 101;
	final int GAMESETTINGUP = 102;
	final int GAMEINPROGRESS = 103;
	int gameStates[] = new int[MAXNUMBEROFSESSIONS+1];
	int numPlayers[] = new int[MAXNUMBEROFSESSIONS+1];
	long lastGameRefresh[] = new long[MAXNUMBEROFSESSIONS+1];
	long lastGameRefresh0;
	boolean refreshGamePending[] = new boolean[MAXNUMBEROFSESSIONS+1];
	boolean refreshGamePending0;
	int gamePlayers[][] = new int[MAXNUMBEROFSESSIONS+1][MAXPLAYERSPERGAME];
	String gamePlayerNames[][] = new String[MAXNUMBEROFSESSIONS+1][MAXPLAYERSPERGAME];
	int gameSpectators[][] = new int[MAXNUMBEROFSESSIONS+1][MAXNUMBEROFSPECTATORS];
	String gameSpectatorNames[][] = new String[MAXNUMBEROFSESSIONS+1][MAXNUMBEROFSPECTATORS];
	int oldSizeX = 0, oldSizeY = 0, newSizeX, newSizeY;
	Applet theRootApplet;
	int origX,origY,startX,startY,currentX,currentY;

	public void init(Applet inRoot, int numOpponents, String inRole, String inName, int inSessNum, int inGamePos, String inPW) {

	}

	public void init(Applet inRootApplet) {

		theRootApplet = inRootApplet;

	}

	public void doInit() {

		serverName = theRootApplet.getParameter("servername");
		if (serverName == null) {
			System.out.println("Could not read parameter \"servername\" from .html page.");
			((LFrame)(this.getParent())).dispose();
			kill();
		}

		/* CHECK FOR VALID USAGE */
		String randStr = "...internetivity";
		String composeStr = "";
		int nextByte, nextNibble;
		for (int cCtr=0;cCtr<16;cCtr++) {
			if (cCtr < serverName.length()) {
				nextByte = serverName.charAt(cCtr);
			} else {
				nextByte = randStr.charAt(cCtr);
			}
			nextNibble = (nextByte >> 4);
			if (nextNibble == 0) {
				composeStr += (char)(80);
			} else {
				composeStr += (char)(nextNibble + 64);
			}
			nextNibble = nextByte - (nextNibble * 16);
			if (nextNibble == 0) {
				composeStr += (char)(80);
			} else {
				composeStr += (char)(nextNibble + 64);
			}
		}
		randStr = theRootApplet.getParameter("runcode");
//		if ((randStr == null) || (!(randStr.equals(composeStr)))) {
//			System.out.println("Invalid run code.");
//			((LFrame)(this.getParent())).dispose();
//			kill();
//		}

		lobbyServerPort = theRootApplet.getParameter("lobbyportnumber");
		if (lobbyServerPort == null) {
			System.out.println("Could not read parameter \"lobbyportnumber\" from .html page.");
			((LFrame)(this.getParent())).dispose();
			kill();
		}
		try {
			serverPortInt = (Integer.valueOf(lobbyServerPort)).intValue();
		} catch (Exception e) {
			System.out.println("Error converting port number parameter to integer value.");
			((LFrame)(this.getParent())).dispose();
			kill();
		}
		frameName = theRootApplet.getParameter("framename");
		if (frameName == null) {
			frameName = DEFAULTFRAMENAME;
		}
		frameName += "  www.InterNetivity.com";
		appletName = theRootApplet.getParameter("appletname");
		documentName = theRootApplet.getParameter("documentname");
		numberOfSessionsStr = theRootApplet.getParameter("numberofsessions");
		if (numberOfSessionsStr != null) {
			try {
				numberOfSessions = (Integer.valueOf(numberOfSessionsStr)).intValue();
			} catch (Exception e) {
				System.out.println("Error converting number of sessions parameter to integer value.");
				((LFrame)(this.getParent())).dispose();
				kill();
			}
			if (numberOfSessions < 1) {
				System.out.println("Number of sessions set to minimum: 1.");
				numberOfSessions = 1;
			} else if (numberOfSessions > MAXNUMBEROFSESSIONS) {
				System.out.println("Number of sessions set to maximum: "+MAXNUMBEROFSESSIONS+".");
				numberOfSessions = MAXNUMBEROFSESSIONS;
			}
		}
		usersPerSessionStr = theRootApplet.getParameter("userspersession");
		if (usersPerSessionStr == null) {
			System.out.println("Could not read parameter \"userspersession\" from .html page.");
			((LFrame)(this.getParent())).dispose();
			kill();
		}
		try {
			usersPerSession = (Integer.valueOf(usersPerSessionStr)).intValue();
		} catch (Exception e) {
			System.out.println("Error converting number of users per session parameter to integer value.");
			((LFrame)(this.getParent())).dispose();
			kill();
		}
		if (usersPerSession < 2) {
			System.out.println("Minimum number of users per session is 2.");
			((LFrame)(this.getParent())).dispose();
			kill();
		} else if (usersPerSession > 4) {
			System.out.println("Number of users per session set to the maximum: 4.");
			usersPerSession = 4;
		}
		minPlayersForLaunchStr = theRootApplet.getParameter("minplayersforlaunch");
		if (minPlayersForLaunchStr != null) {
			try {
				minPlayersForLaunch = (Integer.valueOf(minPlayersForLaunchStr)).intValue();
			} catch (Exception e) {
				System.out.println("Error converting min players for launch to integer value.");
				((LFrame)(this.getParent())).dispose();
				kill();
			}
		}
		if (minPlayersForLaunch < 0) {
			minPlayersForLaunch = 0;
		}
		sessionIdleTimeStr = theRootApplet.getParameter("sessionidletime");
		if (sessionIdleTimeStr == null) {
			sessionIdleTimeStr = "3600";
		}
		try {
			sessionIdleTime = (Integer.valueOf(sessionIdleTimeStr)).intValue();
		} catch (Exception e) {
			System.out.println("Error converting session idle time parameter to integer value.");
			((LFrame)(this.getParent())).dispose();
			kill();
		}
		if (sessionIdleTime < 10) {
			System.out.println("Session idle time set to the minimum: 10 seconds.");
			sessionIdleTime = 10;
		} else if (sessionIdleTime > 3600) {
			System.out.println("Session idle time set to the maximum: 3600 seconds (1 hour).");
			sessionIdleTime = 3600;
		}
		lobbyIdleTimeoutInterval = sessionIdleTime * 1000;		/* convert seconds to milliseconds */
		lobbyIdleTimeout = new Date().getTime() + lobbyIdleTimeoutInterval;
		sessionName = theRootApplet.getParameter("sessionname");
		if (sessionName == null) {
			sessionName = DEFAULTSESSIONNAME;
		}
		userShapeStr = theRootApplet.getParameter("usershape");
		if (userShapeStr == null) {
			userShape = RECTUSER;
		} else if (userShapeStr.equals("rectangle")) {
			userShape = RECTUSER;
		} else if (userShapeStr.equals("roundrectangle")) {
			userShape = ROUNDRECTUSER;
		} else if (userShapeStr.equals("oval")) {
			userShape = OVALUSER;
		} else if (userShapeStr.equals("hexagon")) {
			userShape = HEXAGONUSER;
		}
		recordKeeper = theRootApplet.getParameter("recordkeeper");
		badNameSoundNumber = ((RootApplet)theRootApplet).loadASoundClip("bfms/badname.au");
		lastGameRefresh[0] = new Date().getTime();
		refreshGamePending[0] = false;
		lastGameRefresh0 = new Date().getTime();
		refreshGamePending0 = false;
		for (int i=0;i<MAXNUMBEROFSESSIONS;i++) {
			playFrame[i+1] = null;
			sessionNumbers[i+1] = i+1;
			sessionPasswords[i+1] = null;
			gameStates[i+1] = GAMESESSIONUNKNOWN;
			lastGameRefresh[i+1] = 0;
			refreshGamePending[i+1] = false;
			for (int j=0;j<MAXPLAYERSPERGAME;j++) {
				gamePlayers[i+1][j] = -1;
				gamePlayerNames[i+1][j] = null;
			}
			for (int j=0;j<MAXNUMBEROFSPECTATORS;j++) {
				gameSpectators[i+1][j] = -1;
				gameSpectatorNames[i+1][j] = null;
			}
		}
		for (int i=0;i<MAXNUMBEROFUSERS;i++) {
			userIDs[i] = -1;
			userNames[i] = null;
			userSessLocations[i] = 0;
			userPlayLocations[i] = 0;
			lobbyNames[i] = null;
		}
		userNames[0] = theRootApplet.getParameter("username");
		if (userNames[0] != null) {
			userNames[0] = new String(userNames[0]);
		}
		markedInLastRefresh[0] = true;
		wholeScene = createImage(size().width,size().height);
		wholeSceneGC = wholeScene.getGraphics();
		/* test here to see what shape of polygon to create */
		createHexPolygon();
		createWideHexPoly();
		createSpectatePoly();
		createStartPoly();
		setLayout(null);
		setBackground(Color.white);
		basicFont = new Font("helvetica",Font.PLAIN,14);
		boldBasicFont = new Font("helvetica",Font.BOLD,14);
		bigFont = new Font("helvetica",Font.BOLD,24);
		wholeSceneGC.setFont(basicFont);
		initScrollAreas(2);
		scrollAreaImage[0] = createImage(GAMESCROLLWIDTH,gameScrollHeight);
		scrollAreaImageGC[0] = scrollAreaImage[0].getGraphics();
		initScrollArea(0,USERSCROLLWIDTH+30,chatHeight+30,GAMESCROLLWIDTH,gameScrollHeight,SCROLLBARWIDTH,numberOfSessions*GAMEHEIGHT,true);
		scrollImageGC[0].setColor(Color.black);
		scrollImageGC[0].setPaintMode();
		setSmallJumpValue(0,GAMEHEIGHT/5);
		setBigJumpValue(0,GAMEHEIGHT);
		drawGames(scrollImageGC[0]);
		ownerRect = new Rectangle(10+SCROLLBARWIDTH-1,chatHeight+30,USERSCROLLWIDTH-SCROLLBARWIDTH,(USERHEIGHT*5)/2);
		scrollAreaImage[1] = createImage(USERSCROLLWIDTH,userScrollHeight-ownerRect.height);
		scrollAreaImageGC[1] = scrollAreaImage[1].getGraphics();
		initScrollArea(1,10,chatHeight+30+ownerRect.height,USERSCROLLWIDTH,userScrollHeight-ownerRect.height,SCROLLBARWIDTH,(MAXNUMBEROFUSERS-1)*USERHEIGHT+4,false);
		scrollImageGC[1].setFont(basicFont);
		scrollImageGC[1].setColor(Color.gray);
		scrollImageGC[1].setPaintMode();
		setSmallJumpValue(1,USERHEIGHT/5);
		setBigJumpValue(1,USERHEIGHT);
		showUsers = true;
		myNetConn = new netConn();
		myNetConn.setMachineName(serverName);
		myNetConn.setMachinePort(serverPortInt);
		myNetConn.start();
		connectionTimeout = new Date().getTime() + CONNECTIONTIMEOUTINTERVAL;
		myNetConnAux = new netConnAux(myNetConn);
		myNetConnAux.start();
		lobbyChat = new chatApplet();
		lobbyChat.setRoot(theRootApplet);
		lobbyChat.setHideUserCheckboxes(true);
		add(lobbyChat);
		lobbyChat.doReshape(10,-chatHeight,chatWidth,chatHeight);
		lobbyChat.setConn(myNetConn);
		lobbyChat.setUser(0,0,"Lobby");					/* save index 0 for the owner */
		lobbyChat.setUser(998,"Lobby");					/* set user 998 to Lobby */
		lobbyChat.postMessage(0,"chat","Welcome to the InterNetivity Lobby!");
		userIDs[0] = 0;
		drawOtherUsers(scrollImageGC[1]);
		refreshGames = true;
		refreshUsers = true;
		initialized = true;
		repaint();
	}

	public synchronized void reshape(int inX, int inY, int inWidth, int inHeight) {

		doTouch();
		if (inHeight < 200) {
			refreshInterval = SLEEPREFRESHINTERVAL;
		} else {
			refreshInterval = ACTIVEREFRESHINTERVAL;
		}
		if (insets().left == 0) {
			inX = inX + 3;
			inWidth = inWidth - 6;
		} else {
			inX = inX + insets().left;
			inWidth = inWidth - insets().left - insets().right;
		}
		if (insets().top < 20) {
			inY = inY + 20;
			inHeight = inHeight - 40;
		} else {
			inY = inY + insets().top;
			inHeight = inHeight - insets().top - insets().bottom;
		}
		super.reshape(inX,inY,inWidth,inHeight);
		if (initialized) {
			chatHeight = 110;
			if (inHeight > 370) {
				chatHeight = (inHeight - 40)/3;
			}
			gameScrollHeight = 150;
			userScrollHeight = 150;
			if (inHeight > 300) {
				gameScrollHeight = inHeight - 40 - chatHeight;
				userScrollHeight = inHeight - 40 - chatHeight;
			}
			if (userScrollHeight > (numberOfUsers*USERHEIGHT)) {
				userScrollHeight = numberOfUsers*USERHEIGHT - 2;
			}
			if (gameScrollHeight > (numberOfSessions*GAMEHEIGHT)) {
				gameScrollHeight = numberOfSessions*GAMEHEIGHT - 2;
			}
			if (showChat) {
				lobbyChat.doReshape(10,inY,chatWidth,chatHeight);
			} else {
				lobbyChat.doReshape(10,-chatHeight,chatWidth,chatHeight);
			}
			scrollAreaImage[0] = createImage(GAMESCROLLWIDTH,gameScrollHeight);
			scrollAreaImageGC[0] = scrollAreaImage[0].getGraphics();
			initScrollArea(0,USERSCROLLWIDTH+30,chatHeight+30,GAMESCROLLWIDTH,gameScrollHeight,SCROLLBARWIDTH,numberOfSessions*GAMEHEIGHT,true);
			ownerRect = new Rectangle(10+SCROLLBARWIDTH-1,chatHeight+30,USERSCROLLWIDTH-SCROLLBARWIDTH,(USERHEIGHT*5)/2);
			scrollAreaImage[1] = createImage(USERSCROLLWIDTH,userScrollHeight-ownerRect.height);
			scrollAreaImageGC[1] = scrollAreaImage[1].getGraphics();
			initScrollArea(1,10,chatHeight+30+ownerRect.height,USERSCROLLWIDTH,userScrollHeight-ownerRect.height,SCROLLBARWIDTH,(numberOfUsers-1)*USERHEIGHT+4,false);
			drawGames(scrollImageGC[0]);
			setSmallJumpValue(0,GAMEHEIGHT/5);
			setBigJumpValue(0,GAMEHEIGHT);
			refreshGames = true;
			drawOtherUsers(scrollImageGC[1]);
			setSmallJumpValue(1,USERHEIGHT);
			setBigJumpValue(1,5*USERHEIGHT);
			refreshUsers = true;
			wholeScene = createImage(Math.max(10,size().width),Math.max(10,size().height));
			wholeSceneGC = wholeScene.getGraphics();
			wholeSceneGC.setFont(basicFont);
		}
		repaint();
	}

	public void start() {
		if (myThread == null) {
			myThread = new Thread(this);
			myThread.start();
		}
		setLayout(null);
		refreshInterval = ACTIVEREFRESHINTERVAL;
	}

	public void stop() {

		refreshInterval = SLEEPREFRESHINTERVAL;
	}

	public synchronized void drawOwner(Graphics inG) {

		if (draggingMe || (userSessLocations[0] != 0) || (movingToSess != -1)) {
			inG.setColor(lightBlue);
		} else {
			inG.setColor(Color.blue);
		}
		if (lobbyState == IDLE) {
			inG.setColor(Color.gray);
		}
		inG.fillRoundRect(ownerRect.x,ownerRect.y,ownerRect.width,ownerRect.height+20,20,20);
		inG.setColor(Color.white);
		inG.fillRect(ownerRect.x,ownerRect.y+ownerRect.height-20,ownerRect.width,ownerRect.height);
		inG.setColor(Color.black);
		inG.drawRect(ownerRect.x,ownerRect.y+ownerRect.height-20,ownerRect.width,ownerRect.height);
		inG.drawString("Other users",ownerRect.x+6,ownerRect.y+ownerRect.height-4);
		inG.drawRoundRect(ownerRect.x,ownerRect.y,ownerRect.width,ownerRect.height+20,20,20);
		inG.setColor(Color.white);
		inG.setFont(boldBasicFont);
		if (userNames[0] == null) {
			inG.drawString("your name",ownerRect.x+15,ownerRect.y+23);
		} else {
			inG.drawString(userNames[0],ownerRect.x+15,ownerRect.y+23);
		}
		inG.setFont(basicFont);
		FontMetrics myFM = inG.getFontMetrics();
		inG.translate(ownerRect.x + ownerRect.width - PolyParams[1] - 3,ownerRect.y+PolyParams[0]+3);
		if (draggingMe || (userSessLocations[0] != 0) || (movingToSess != -1)) {
			if (highlightMyPlay) {
				inG.setColor(Color.gray);
			} else {
				inG.setColor(Color.white);
			}
		} else {
			inG.setColor(Color.green);
		}
		if (lobbyState == IDLE) {
			inG.setColor(Color.gray);
		}
		inG.fillPolygon(playPoly);
		inG.setColor(Color.black);
		inG.drawPolygon(playPoly);
		if (!draggingMe && (userSessLocations[0] == 0) && (movingToSess == -1)) {
			inG.setColor(Color.blue);
			inG.drawString("Join",-myFM.stringWidth("Join")/2,myFM.getMaxAscent()/2);
		}
		inG.translate(-(ownerRect.x + ownerRect.width - PolyParams[1] - 3),-(ownerRect.y+PolyParams[0]+3));
	}

	public synchronized void drawOtherUsers(Graphics inG) {

		inG.setFont(basicFont);
		FontMetrics myFM = inG.getFontMetrics();
		inG.setColor(Color.lightGray);
		inG.fillRect(0,0,USERSCROLLWIDTH,numberOfUsers*USERHEIGHT);
		for (int lpc=0;lpc<MAXNUMBEROFUSERS;lpc++) {
			lobbyNames[lpc] = null;
		}
		int positionCtr = 0;
		numOccupants = 0;
		for (int uniqI=1;uniqI<numberOfUsers;uniqI++) {
			if ((userIDs[uniqI] != -1) && (userSessLocations[uniqI] == 0)) {
				numOccupants++;
				inG.translate(85,positionCtr*USERHEIGHT+POLYHALFHEIGHT+6);
				if (draggingMe || (userSessLocations[0] != 0) || (movingToSess != -1)) {
					inG.setColor(lightBlue);
				} else {
					inG.setColor(Color.blue);
				}
				if (lobbyState == IDLE) {
					inG.setColor(Color.gray);
				}
				inG.fillPolygon(widePoly);
				inG.setColor(Color.black);
				inG.drawPolygon(widePoly);
				inG.setColor(Color.white);
				if (userNames[uniqI] != null) {
					inG.drawString(userNames[uniqI],-myFM.stringWidth(userNames[uniqI])/2,myFM.getMaxAscent()/2);
					lobbyNames[positionCtr] = userNames[uniqI];
				} else {
					inG.drawString("(unknown)",-myFM.stringWidth("(unknown)")/2,myFM.getMaxAscent()/2);
				}
				inG.translate(-85,-(positionCtr*USERHEIGHT+POLYHALFHEIGHT+6));
				positionCtr++;
			}
		}
		inG.setColor(Color.black);
		for (int uniqI=positionCtr;uniqI<numberOfUsers;uniqI++) {
			inG.drawLine(20,uniqI*USERHEIGHT+POLYHALFHEIGHT+6,ownerRect.width-20,uniqI*USERHEIGHT+POLYHALFHEIGHT+6);
		}
	}

	public synchronized void myDrawPolygon(Graphics inG, int inX, int inY, Polygon inPoly, Color fillColour, Color trimColour, String inText, Color textColour) {
	
		FontMetrics myFM = inG.getFontMetrics();
		inG.translate(inX,inY);
		inG.setColor(fillColour);
		inG.fillPolygon(inPoly);
		inG.setColor(trimColour);
		inG.drawPolygon(inPoly);
		if (inText != null) {
			inG.setColor(textColour);
			inG.drawString(inText,-myFM.stringWidth(inText)/2,myFM.getMaxAscent()/2);
		}
		inG.translate(-inX,-inY);
	}

	public synchronized void centreText(Graphics inG, int inX, int inY, int inWidth, int inHeight, Color inColour, String inStr) {

		if (inG == null) {
			return;
		}
		FontMetrics myFM = inG.getFontMetrics();
		inG.setColor(inColour);
		inG.drawString(inStr,inX + (inWidth - myFM.stringWidth(inStr))/2,inY + (inHeight + myFM.getHeight())/2 - 3);
	}

	public synchronized void drawButton(Graphics inG, int theLeft, int theTop, int theWidth, int theHeight, Color theColour) {

		if (inG == null) {
			return;
		}
		inG.setColor(theColour);
		inG.fillRect(theLeft,theTop,theWidth,theHeight);
		inG.setColor(Color.white);
		inG.drawLine(theLeft+1,theTop+1,theLeft+theWidth-1,theTop+1);
		inG.drawLine(theLeft+2,theTop+2,theLeft+theWidth-2,theTop+2);
		inG.drawLine(theLeft+1,theTop+1,theLeft+1,theTop+theHeight-1);
		inG.drawLine(theLeft+2,theTop+2,theLeft+2,theTop+theHeight-2);
		inG.setColor(Color.gray);
		inG.drawLine(theLeft+1,theTop+theHeight-1,theLeft+theWidth-1,theTop+theHeight-1);
		inG.drawLine(theLeft+2,theTop+theHeight-2,theLeft+theWidth-2,theTop+theHeight-2);
		inG.drawLine(theLeft+theWidth-1,theTop+1,theLeft+theWidth-1,theTop+theHeight-1);
		inG.drawLine(theLeft+theWidth-2,theTop+2,theLeft+theWidth-2,theTop+theHeight-2);
		inG.drawRect(theLeft,theTop,theWidth,theHeight);
	}

	public synchronized void drawGames(Graphics inG) {

		FontMetrics myFM = inG.getFontMetrics();
		int playersInSession;
		boolean imInThisSession;
		for (int i=0;i<numberOfSessions;i++) {
			imInThisSession = false;
			for (int j=0;j<usersPerSession;j++) {
				if ((userIDs[0] != -1) && (gamePlayers[i+1][j] == userIDs[0])) {
					imInThisSession = true;
				}
			}
			if (gameStates[i+1] == GAMESESSIONUNKNOWN) {
				inG.setColor(Color.lightGray);
			} else if (gameStates[i+1] == GAMESESSIONIDLE) {
				if (imInThisSession && (movingToSess == -1)) {
					inG.setColor(Color.red);
				} else {
					inG.setColor(rose);
				}
			} else if (gameStates[i+1] == GAMESETTINGUP) {
				inG.setColor(Color.white);
			} else if (gameStates[i+1] == GAMEINPROGRESS) {
				inG.setColor(lightGreen);
			}
			if (lobbyState == IDLE) {
				inG.setColor(Color.gray);
			}
			inG.fillRoundRect(3,5+i*GAMEHEIGHT,GAMEIMAGEWIDTH-6,GAMEHEIGHT-10,30,30);
			inG.setColor(Color.black);
			inG.drawRoundRect(3,5+i*GAMEHEIGHT,GAMEIMAGEWIDTH-6,GAMEHEIGHT-10,30,30);
			inG.setFont(bigFont);
			inG.drawString(new String(sessionName+" "+(i+1)),15,40+i*GAMEHEIGHT);
			drawButton(inG,GAMEIMAGEWIDTH-INFODELTAX,INFODELTAY+i*GAMEHEIGHT,INFOWIDTH,INFOHEIGHT,Color.yellow);
			centreText(inG,GAMEIMAGEWIDTH-INFODELTAX,INFODELTAY+i*GAMEHEIGHT,INFOWIDTH,INFOHEIGHT-6,Color.black,"?");
			inG.setFont(basicFont);
			inG.drawString("Players",10,PLAYERTITLEYOFFSET+i*GAMEHEIGHT);
			inG.drawLine(10,PLAYERTITLEYOFFSET+i*GAMEHEIGHT,10+myFM.stringWidth("Players"),PLAYERTITLEYOFFSET+i*GAMEHEIGHT);
			inG.setColor(Color.black);
			if (gameStates[i+1] == GAMESESSIONUNKNOWN) {
				inG.drawString("State unknown.",SPECTATORTITLEXOFFSET,PLAYERTITLEYOFFSET+i*GAMEHEIGHT);
			} else if (gameStates[i+1] == GAMESESSIONIDLE) {
				inG.drawString("Idle.",SPECTATORTITLEXOFFSET,PLAYERTITLEYOFFSET+i*GAMEHEIGHT);
			} else if (gameStates[i+1] == GAMESETTINGUP) {
				inG.drawString("Launching...",SPECTATORTITLEXOFFSET,PLAYERTITLEYOFFSET+i*GAMEHEIGHT);
			} else if (gameStates[i+1] == GAMEINPROGRESS) {
				if ((playFrame[i+1] == null) && ((launchSpectator == -1) || (startingSessNum != (i+1)))) {
					inG.translate(SPECTATORTITLEXOFFSET+SPECTATORWIDTH-10,PLAYERTITLEYOFFSET+i*GAMEHEIGHT-SPECTATORBUTTONYOFFSET);
					inG.setColor(Color.green);
					if (lobbyState == IDLE) {
						inG.setColor(Color.gray);
					}
					inG.fillPolygon(narrowPoly);
					inG.setColor(Color.black);
					inG.drawPolygon(narrowPoly);
					inG.drawString("Spectate",-myFM.stringWidth("Spectate")/2,myFM.getMaxAscent()/2);
					inG.translate(-(SPECTATORTITLEXOFFSET+SPECTATORWIDTH-10),-(PLAYERTITLEYOFFSET+i*GAMEHEIGHT-SPECTATORBUTTONYOFFSET));
				}
				inG.drawString("Spectators",SPECTATORTITLEXOFFSET,PLAYERTITLEYOFFSET+i*GAMEHEIGHT);
				inG.drawLine(SPECTATORTITLEXOFFSET,PLAYERTITLEYOFFSET+i*GAMEHEIGHT,SPECTATORTITLEXOFFSET+myFM.stringWidth("Spectators"),PLAYERTITLEYOFFSET+i*GAMEHEIGHT);
				for (int j=0;j<numberOfSpectators;j++) {
					if (gameSpectators[i+1][j] != -1) {
						inG.setColor(Color.black);
						if (gameSpectatorNames[i+1][j] != null) {
							inG.drawString(gameSpectatorNames[i+1][j],SPECTATORTITLEXOFFSET,PLAYERTITLEYOFFSET+1+i*GAMEHEIGHT+(j+1)*16);
						}
					}
				}
			}
			playersInSession = 0;
			for (int j=0;j<usersPerSession;j++) {
				inG.translate(POLYXOFFSETS[j],POLYYOFFSETS[j]+i*GAMEHEIGHT);
				if (gamePlayers[i+1][j] == -1) {
					if (highlightPlay && (playPoint.x == (i+1)) && (playPoint.y == (j))) {
						inG.setColor(Color.gray);
					} else {
						inG.setColor(Color.white);
					}
				} else {
					playersInSession++;
					if ((gamePlayers[i+1][j] == userIDs[0]) && (gameStates[i+1] == GAMESESSIONIDLE)) {
						inG.setColor(Color.green);
					} else {
						inG.setColor(Color.lightGray);
					}
				}
				inG.fillPolygon(playPoly);
				inG.setColor(Color.black);
				inG.drawPolygon(playPoly);
				if ((gamePlayers[i+1][j] == userIDs[0]) && (gameStates[i+1] == GAMESESSIONIDLE)) {
					inG.setColor(Color.red);
					inG.drawString("Join",-myFM.stringWidth("Join")/2,myFM.getMaxAscent()/2);
				}
				inG.setColor(Color.black);
				if (gamePlayers[i+1][j] != -1) {
					if (gamePlayerNames[i+1][j] != null) {
						inG.drawString(gamePlayerNames[i+1][j],PolyParams[1]+3,5);
					} else {
						inG.drawString("(unknown)",PolyParams[1]+3,5);
					}
				} else if (gameStates[i+1] == GAMESESSIONIDLE) {
					inG.drawString("(unoccupied)",PolyParams[1]+3,5);
				}
				inG.translate(-POLYXOFFSETS[j],-(POLYYOFFSETS[j]+i*GAMEHEIGHT));
				if ((gameStates[i+1] == GAMESESSIONIDLE) && (playersInSession >= minPlayersForLaunch) && imInThisSession) {
					myDrawPolygon(inG,STARTXOFFSET,i*GAMEHEIGHT+STARTYOFFSET,startPoly,Color.white,Color.black,"Start",Color.black);
				}
			}
		}
	}

	public int myRound(double inVal) {

		return((int)(100000.5+inVal)-100000);
	}

	public void createWideHexPoly() {

		double cornerXs[] = new double[6];
		double cornerYs[] = new double[6];

		widePoly = new Polygon();
		cornerXs[0] = -50;
		cornerYs[0] = -POLYHALFHEIGHT;
		cornerXs[1] = 50;
		cornerYs[1] = -POLYHALFHEIGHT;
		cornerXs[2] = 59;
		cornerYs[2] = 0;
		cornerXs[3] = 50;
		cornerYs[3] = POLYHALFHEIGHT;
		cornerXs[4] = -50;
		cornerYs[4] = POLYHALFHEIGHT;
		cornerXs[5] = -59;
		cornerYs[5] = 0;
		widePoly.addPoint(myRound(cornerXs[0])-2,myRound(cornerYs[0])+3);
		widePoly.addPoint(myRound(cornerXs[0]),myRound(cornerYs[0])+1);
		widePoly.addPoint(myRound(cornerXs[0])+4,myRound(cornerYs[0]));

		widePoly.addPoint(myRound(cornerXs[1])-4,myRound(cornerYs[1]));
		widePoly.addPoint(myRound(cornerXs[1]),myRound(cornerYs[1])+1);
		widePoly.addPoint(myRound(cornerXs[1])+2,myRound(cornerYs[1])+3);

		widePoly.addPoint(myRound(cornerXs[2])-1,myRound(cornerYs[2])-3);
		widePoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2])-1);
		widePoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2])+1);
		widePoly.addPoint(myRound(cornerXs[2])-1,myRound(cornerYs[2])+3);

		widePoly.addPoint(myRound(cornerXs[3])+2,myRound(cornerYs[3])-3);
		widePoly.addPoint(myRound(cornerXs[3]),myRound(cornerYs[3])-1);
		widePoly.addPoint(myRound(cornerXs[3])-4,myRound(cornerYs[3]));

		widePoly.addPoint(myRound(cornerXs[4])+4,myRound(cornerYs[4]));
		widePoly.addPoint(myRound(cornerXs[4]),myRound(cornerYs[4])-1);
		widePoly.addPoint(myRound(cornerXs[4])-2,myRound(cornerYs[4])-3);

		widePoly.addPoint(myRound(cornerXs[5])+1,myRound(cornerYs[5])+3);
		widePoly.addPoint(myRound(cornerXs[5]),myRound(cornerYs[5])+1);
		widePoly.addPoint(myRound(cornerXs[5]),myRound(cornerYs[5])-1);
		widePoly.addPoint(myRound(cornerXs[5])+1,myRound(cornerYs[5])-3);

		widePoly.addPoint(myRound(cornerXs[0])-2,myRound(cornerYs[0])+3);
	}

	public void createSpectatePoly() {

		narrowPoly = new Polygon();
		narrowPoly.addPoint(-SPECTATORWIDTH,-POLYHALFHEIGHT+9);
		narrowPoly.addPoint(-SPECTATORWIDTH+1,-POLYHALFHEIGHT+5);
		narrowPoly.addPoint(-SPECTATORWIDTH+5,-POLYHALFHEIGHT+1);
		narrowPoly.addPoint(-SPECTATORWIDTH+9,-POLYHALFHEIGHT);
		narrowPoly.addPoint(SPECTATORWIDTH-9,-POLYHALFHEIGHT);
		narrowPoly.addPoint(SPECTATORWIDTH-5,-POLYHALFHEIGHT+1);
		narrowPoly.addPoint(SPECTATORWIDTH-1,-POLYHALFHEIGHT+5);
		narrowPoly.addPoint(SPECTATORWIDTH,-POLYHALFHEIGHT+9);
		narrowPoly.addPoint(SPECTATORWIDTH,POLYHALFHEIGHT-9);
		narrowPoly.addPoint(SPECTATORWIDTH-1,POLYHALFHEIGHT-5);
		narrowPoly.addPoint(SPECTATORWIDTH-5,POLYHALFHEIGHT-1);
		narrowPoly.addPoint(SPECTATORWIDTH-9,POLYHALFHEIGHT);
		narrowPoly.addPoint(-SPECTATORWIDTH+9,POLYHALFHEIGHT);
		narrowPoly.addPoint(-SPECTATORWIDTH+5,POLYHALFHEIGHT-1);
		narrowPoly.addPoint(-SPECTATORWIDTH+1,POLYHALFHEIGHT-5);
		narrowPoly.addPoint(-SPECTATORWIDTH,POLYHALFHEIGHT-9);
		narrowPoly.addPoint(-SPECTATORWIDTH,-POLYHALFHEIGHT+9);
	}

//	public void createNarrowHexPoly() {
//
//		double cornerXs[] = new double[6];
//		double cornerYs[] = new double[6];
//
//		narrowPoly = new Polygon();
//		cornerXs[0] = -SPECTATORWIDTH;
//		cornerYs[0] = -POLYHALFHEIGHT;
//		cornerXs[1] = SPECTATORWIDTH;
//		cornerYs[1] = -POLYHALFHEIGHT;
//		cornerXs[2] = SPECTATORWIDTH+9;
//		cornerYs[2] = 0;
//		cornerXs[3] = SPECTATORWIDTH;
//		cornerYs[3] = POLYHALFHEIGHT;
//		cornerXs[4] = -SPECTATORWIDTH;
//		cornerYs[4] = POLYHALFHEIGHT;
//		cornerXs[5] = -SPECTATORWIDTH-9;
//		cornerYs[5] = 0;
//		narrowPoly.addPoint(myRound(cornerXs[0])-2,myRound(cornerYs[0])+3);
//		narrowPoly.addPoint(myRound(cornerXs[0]),myRound(cornerYs[0])+1);
//		narrowPoly.addPoint(myRound(cornerXs[0])+4,myRound(cornerYs[0]));
//
//		narrowPoly.addPoint(myRound(cornerXs[1])-4,myRound(cornerYs[1]));
//		narrowPoly.addPoint(myRound(cornerXs[1]),myRound(cornerYs[1])+1);
//		narrowPoly.addPoint(myRound(cornerXs[1])+2,myRound(cornerYs[1])+3);
//
//		narrowPoly.addPoint(myRound(cornerXs[2])-1,myRound(cornerYs[2])-3);
//		narrowPoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2])-1);
//		narrowPoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2])+1);
//		narrowPoly.addPoint(myRound(cornerXs[2])-1,myRound(cornerYs[2])+3);
//
//		narrowPoly.addPoint(myRound(cornerXs[3])+2,myRound(cornerYs[3])-3);
//		narrowPoly.addPoint(myRound(cornerXs[3]),myRound(cornerYs[3])-1);
//		narrowPoly.addPoint(myRound(cornerXs[3])-4,myRound(cornerYs[3]));
//
//		narrowPoly.addPoint(myRound(cornerXs[4])+4,myRound(cornerYs[4]));
//		narrowPoly.addPoint(myRound(cornerXs[4]),myRound(cornerYs[4])-1);
//		narrowPoly.addPoint(myRound(cornerXs[4])-2,myRound(cornerYs[4])-3);
//
//		narrowPoly.addPoint(myRound(cornerXs[5])+1,myRound(cornerYs[5])+3);
//		narrowPoly.addPoint(myRound(cornerXs[5]),myRound(cornerYs[5])+1);
//		narrowPoly.addPoint(myRound(cornerXs[5]),myRound(cornerYs[5])-1);
//		narrowPoly.addPoint(myRound(cornerXs[5])+1,myRound(cornerYs[5])-3);
//
//		narrowPoly.addPoint(myRound(cornerXs[0])-2,myRound(cornerYs[0])+3);
//	}

	public void createHexPolygon() {

		double cornerXs[] = new double[6];
		double cornerYs[] = new double[6];

		playPoly = new Polygon();
		cornerXs[0] = 0;
		cornerYs[0] = 2-PolyParams[0];
		cornerXs[1] = PolyParams[1]-1;
		cornerYs[1] = 1-(PolyParams[0]/2.0);
		cornerXs[2] = PolyParams[1]-1;
		cornerYs[2] = PolyParams[0]/2.0-1;
		cornerXs[3] = 0;
		cornerYs[3] = PolyParams[0]-1;
		cornerXs[4] = 1-PolyParams[1];
		cornerYs[4] = PolyParams[0]/2.0-1;
		cornerXs[5] = 1-PolyParams[1];
		cornerYs[5] = 1-(PolyParams[0]/2.0);
		playPoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2])-4);
		playPoly.addPoint(myRound(cornerXs[2])-1,myRound(cornerYs[2]));
		playPoly.addPoint(myRound(cornerXs[2])-3,myRound(cornerYs[2])+2);

		playPoly.addPoint(myRound(cornerXs[3])+3,myRound(cornerYs[3])-1);
		playPoly.addPoint(myRound(cornerXs[3]+1),myRound(cornerYs[3]));
		playPoly.addPoint(myRound(cornerXs[3]-1),myRound(cornerYs[3]));
		playPoly.addPoint(myRound(cornerXs[3])-3,myRound(cornerYs[3])-1);

		playPoly.addPoint(myRound(cornerXs[4])+3,myRound(cornerYs[4])+2);
		playPoly.addPoint(myRound(cornerXs[4])+1,myRound(cornerYs[4]));
		playPoly.addPoint(myRound(cornerXs[4]),myRound(cornerYs[4])-4);

		playPoly.addPoint(myRound(cornerXs[5]),myRound(cornerYs[5])+4);
		playPoly.addPoint(myRound(cornerXs[5])+1,myRound(cornerYs[5]));
		playPoly.addPoint(myRound(cornerXs[5])+3,myRound(cornerYs[5])-2);

		playPoly.addPoint(myRound(cornerXs[0])-3,myRound(cornerYs[0])+1);
		playPoly.addPoint(myRound(cornerXs[0]-1),myRound(cornerYs[0]));
		playPoly.addPoint(myRound(cornerXs[0]+1),myRound(cornerYs[0]));
		playPoly.addPoint(myRound(cornerXs[0])+3,myRound(cornerYs[0])+1);

		playPoly.addPoint(myRound(cornerXs[1])-3,myRound(cornerYs[1])-2);
		playPoly.addPoint(myRound(cornerXs[1])-1,myRound(cornerYs[1]));
		playPoly.addPoint(myRound(cornerXs[1]),myRound(cornerYs[1])+4);

		playPoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2])-4);
	}

	public void createStartPoly() {

		startPoly = new Polygon();
		for (int circleIndex=0;circleIndex<40;circleIndex++) {
			startPoly.addPoint(myRound(50*Math.sin(2*Math.PI*circleIndex/40)),myRound(15*Math.cos(2*Math.PI*circleIndex/40)));
		}
		startPoly.addPoint(0,15);
	}

	public void update(Graphics g) {

		paint(g);
	}

	public synchronized void paint(Graphics g) {

		if (wholeSceneGC == null) {
			return;
		}
		wholeSceneGC.setColor(this.getBackground());
		wholeSceneGC.fillRect(0,0,size().width,size().height);
//		if ((lobbyState == ACTIVE) && !draggingMe) {
//			if ((userSessLocations[0] == 0) && (movingToSess == -1)) {
//				wholeSceneGC.setColor(Color.blue);
//				wholeSceneGC.fillRoundRect(0,0,chatWidth+20,chatHeight+20,20,20);
//				wholeSceneGC.fillRect(ownerRect.x-20,ownerRect.y-20,ownerRect.width+40,60);
//				wholeSceneGC.setColor(this.getBackground());
//				wholeSceneGC.fillRoundRect(0,chatHeight+20,ownerRect.x+10,60,20,20);
//				wholeSceneGC.fillRoundRect(ownerRect.x+ownerRect.width-10,chatHeight+20,40,60,20,20);
//			} else {
//				wholeSceneGC.setColor(Color.red);
//				wholeSceneGC.fillRoundRect(0,0,chatWidth+20,chatHeight+20,20,20);
//				wholeSceneGC.fillRect(scrollRect[0].x-20,scrollRect[0].y-20,scrollRect[0].width+20,60);
//				wholeSceneGC.setColor(this.getBackground());
//				wholeSceneGC.fillRoundRect(scrollRect[0].x-40,chatHeight+20,40,60,20,20);
//				wholeSceneGC.fillRoundRect(scrollRect[0].x+scrollRect[0].width-scrollbarRect[0].width,chatHeight+20,40,60,20,20);
//			}
//		}
		wholeSceneGC.setFont(basicFont);
		FontMetrics myFM = wholeSceneGC.getFontMetrics();
		if (showGames) {
			if (refreshGames) {
				drawScrollArea(0);
				refreshGames = false;
			}
			if (highlightPlay && (gamePlayers[playPoint.x][playPoint.y] == -1)) {
				scrollAreaImageGC[0].setColor(Color.gray);
				myDrawPolygon(scrollAreaImageGC[0], POLYXOFFSETS[playPoint.y], POLYYOFFSETS[playPoint.y]+(playPoint.x-1)*GAMEHEIGHT+currentImageOffset[0], playPoly, Color.gray, Color.black, null, Color.black);
				scrollAreaImageGC[0].setColor(Color.black);
				scrollAreaImageGC[0].drawRect(0,0,scrollRect[0].width-1,scrollRect[0].height-1);
			}
			wholeSceneGC.drawImage(scrollAreaImage[0],scrollRect[0].x,scrollRect[0].y,this);
		}
		if (showUsers) {
			drawOwner(wholeSceneGC);
			if (refreshUsers) {
				drawScrollArea(1);
				refreshUsers = false;
			}
			wholeSceneGC.drawImage(scrollAreaImage[1],scrollRect[1].x,scrollRect[1].y,this);
		}
		if (draggingMe) {
			wholeSceneGC.translate(origX+currentX-startX,origY+currentY-startY);
			wholeSceneGC.setColor(Color.green);
			wholeSceneGC.fillPolygon(playPoly);
			wholeSceneGC.setColor(Color.black);
			wholeSceneGC.drawPolygon(playPoly);
			wholeSceneGC.drawString("Join",-myFM.stringWidth("Join")/2,myFM.getMaxAscent()/2);
			wholeSceneGC.translate(-(origX+currentX-startX),-(origY+currentY-startY));
		}
		g.drawImage(wholeScene,0,0,this);
	}

	public void launchGame(String appName, int gameNum, String inPW, int numOpps) {

		Class myClass;

		playFrame[gameNum] = new ExtFrame(new String(userNames[0]+" "+appName+" "+gameNum+"  www.InterNetivity.com"),this);
		playFrame[gameNum].setLayout(null);
		try {
			myClass = Class.forName(appName);
			theGame[gameNum] = (extendedApplet)myClass.newInstance();
		} catch (Exception e) {
			System.out.println("EXCEPTION while trying to launch "+appName+": "+e);
		}
		playFrame[gameNum].add(theGame[gameNum]);
		playFrame[gameNum].show();
		theGame[gameNum].reshape(playFrame[gameNum].insets().left,playFrame[gameNum].insets().top,520,530);
		playFrame[gameNum].resize(520+playFrame[gameNum].insets().left+playFrame[gameNum].insets().right,530+playFrame[gameNum].insets().top+playFrame[gameNum].insets().bottom);
		playFrame[gameNum].setResizable(true);
		theGame[gameNum].init(theRootApplet,numOpps,"player",userNames[0],gameNum,userPlayLocations[0],inPW);
		playFrame[gameNum].start();
		theGame[gameNum].start();
	}

	public void launchGameSpectator(String appName, int gameNum) {

		Class myClass;

		playFrame[gameNum] = new ExtFrame(new String(userNames[0]+" "+appName+" "+gameNum+" - Spectator"+"  www.InterNetivity.com"),this);
		playFrame[gameNum].setLayout(null);
		try {
			myClass = Class.forName(appName);
			theGame[gameNum] = (extendedApplet)myClass.newInstance();
		} catch (Exception e) {
			System.out.println("EXCEPTION while trying to launch "+appName+": "+e);
		}
		playFrame[gameNum].add(theGame[gameNum]);
		playFrame[gameNum].show();
		theGame[gameNum].reshape(playFrame[gameNum].insets().left,playFrame[gameNum].insets().top,520,500);
		playFrame[gameNum].resize(520+playFrame[gameNum].insets().left+playFrame[gameNum].insets().right,500+playFrame[gameNum].insets().top+playFrame[gameNum].insets().bottom);
		playFrame[gameNum].setResizable(true);
		theGame[gameNum].init(theRootApplet,0,"spectator",userNames[0],gameNum,userPlayLocations[0],null);
		playFrame[gameNum].start();
		theGame[gameNum].start();
	}

	public void killFrame(ExtFrame inTF) {

		int frameNum = 0;
		while ((frameNum < (numberOfSessions+1)) && (inTF != playFrame[frameNum])) {
			frameNum++;
		}
		if (frameNum == (numberOfSessions+1)) {
			return;
		}
		int playerNumber = 0;
		while ((playerNumber < usersPerSession) && (gamePlayers[frameNum][playerNumber] != -1) && (!(gamePlayerNames[frameNum][playerNumber].equals(userNames[0])))) {
			playerNumber++;
		}
		if (playerNumber != usersPerSession) {
			gamePlayers[frameNum][playerNumber] = -1;
			gamePlayerNames[frameNum][playerNumber] = null;
		}
		playerNumber = 0;
		while ((playerNumber < MAXNUMBEROFSPECTATORS) && (gameSpectators[frameNum][playerNumber] != -1) && (!(gameSpectatorNames[frameNum][playerNumber].equals(userNames[0])))) {
			playerNumber++;
		}
		if (playerNumber != MAXNUMBEROFSPECTATORS) {
			gameSpectators[frameNum][playerNumber] = -1;
			gameSpectatorNames[frameNum][playerNumber] = null;
		}
		theGame[frameNum].kill();
		playFrame[frameNum].dispose();
		playFrame[frameNum] = null;
		boolean noFrames = true;
		for (int li=0;li<MAXNUMBEROFSESSIONS;li++) {
			if (playFrame[li+1] != null) {
				noFrames = false;
			}
		}
	}

	public void kill() {

		exitFlag = true;
		if (myNetConn != null) {
			myNetConn.setExitFlag();
		}
		if (myNetConnAux != null) {
			myNetConnAux.setExitFlag();
		}
		tempSB = new StringBuffer("220 ");
		if (!myNetConn.sendMessage(tempSB)) {
		}
		doDelay(100);
	}

	private void doUNCONNECTED() {					// state 1

		if (connectionTimeout < (new Date().getTime())) {
			remove(nameRequest);
			nameRequest = new Label("The server is not responding.");
			nameSpec = new Label("It may be down, or a firewall may be preventing the connection.");
			nameRequest.setFont(basicFont);
			nameSpec.setFont(basicFont);
			nameRequest.setForeground(Color.red);
			nameSpec.setForeground(Color.red);
			add(nameRequest);
			add(nameSpec);
			nameRequest.reshape(5,40,500,25);
			nameSpec.reshape(5,60,500,25);
			lobbyState = IDLE;
			repaint();
		} else {
			if (nameRequest == null) {
				nameRequest = new Label("Connecting...");
				nameRequest.setFont(basicFont);
				nameRequest.setForeground(Color.black);
				add(nameRequest);
				nameRequest.reshape(5,62,500,21);
			}
			repaint();
		}
		if (!myNetConn.haveConn() && !myNetConnAux.requestPending()) {
			myNetConnAux.requestConn();
		}
		if (!myNetConnAux.requestPending() && !myNetConnAux.didSuccessfulMake()) {
			myNetConnAux.requestConn();
		}
		if (!myNetConnAux.requestPending() && myNetConnAux.didSuccessfulMake()) {
			lobbyState = NOTINLOBBY;
			remove(nameRequest);
			tempSB = new StringBuffer("200 "+lobbySessionInt);
			if (!myNetConn.sendMessage(tempSB)) {
				lobbyState = IDLE;
			}
		}
	}

	private void doNOTINLOBBY() {				// state 2

		if (tempString != null) {
			StringTokenizer localST = new StringTokenizer(tempString);
			if (localST.countTokens() == 2) {
				String messType = localST.nextToken();
				if (messType.equals("202")) {
					nameRequest = new Label("Sorry, lobby has refused entry.  It may be full.");
					nameRequest.setFont(bigFont);
					nameRequest.setForeground(Color.red);
					add(nameRequest);
					nameRequest.reshape(10,30,500,25);
					lobbyState = IDLE;							/*** put EXIT button here */
					repaint();
				} else if (messType.equals("999")) {
				} else {
					System.out.println(userIDs[0]+": unaccounted for message while entering lobby: "+tempString);
				}
			} else if (localST.countTokens() > 2) {
				String messType = localST.nextToken();
				if (messType.equals("201")) {
					String sessNumStr = localST.nextToken();
					int sessNumInt = (Integer.valueOf(sessNumStr)).intValue();
					String playerIDStr = localST.nextToken();
					int playerIDInt = (Integer.valueOf(playerIDStr)).intValue();
					if (sessNumInt == 0) {
						userIDs[0] = playerIDInt;
						if (userNames[0] == null) {
							int textHeight = 15;
							nameRequest = new Label("To enter the lobby, type in a name you will use for playing Tantrix.");
							nameRequest.setFont(basicFont);
							nameRequest.setForeground(Color.blue);
							add(nameRequest);
							nameRequest.reshape(5,10+textHeight,500,25);
							nameSpec = new Label("Name must be at least 4 characters and use only a-z, A-Z, 0-9, and space.");
							nameSpec.setFont(basicFont);
							nameSpec.setForeground(Color.blue);
							add(nameSpec);
							nameSpec.reshape(5,38+4*textHeight,500,25);
							nameInput = new TextField();
							nameInput.setFont(basicFont);
							add(nameInput);
							nameInput.reshape(5,32+2*textHeight,120,30);
							submitButton = new Button("Submit");
							add(submitButton);
							submitButton.reshape(127,32+2*textHeight,60,30);
							userNames[0] = null;
							drawOtherUsers(scrollImageGC[1]);
							refreshUsers = true;
							lobbyState = UNNAMED;
							repaint();
							tempSB = new StringBuffer("302 ");
							if (!myNetConn.sendMessage(tempSB)) {
								lobbyState = IDLE;
							}
							tempSB = new StringBuffer("304 ");
							if (!myNetConn.sendMessage(tempSB)) {
								lobbyState = IDLE;
							}
						} else {
							tempSB = new StringBuffer("204 "+userNames[0]);
							if (!myNetConn.sendMessage(tempSB)) {
								System.out.println("Failed to send name message.");
								lobbyState = IDLE;
							}
							tempSB = new StringBuffer("302 ");
							if (!myNetConn.sendMessage(tempSB)) {
								lobbyState = IDLE;
							}
							tempSB = new StringBuffer("304 ");
							if (!myNetConn.sendMessage(tempSB)) {
								lobbyState = IDLE;
							}
							lobbyChat.doReshape(10,10,chatWidth,chatHeight);
							lobbyChat.setUser(0,userIDs[0],userNames[0]);
							((RootApplet)theRootApplet).setFrameName(userNames[0]+" - "+frameName);
							drawOtherUsers(scrollImageGC[1]);
							showGames = true;
							showChat = true;
							repaint();
							for (int i=0;i<(MAXNUMBEROFSESSIONS+1);i++) {
								lastGameRefresh[i] = 0;
								refreshGamePending[i] = false;
							}
							lobbyState = ACTIVE;
							updatePending = true;
						}
					}
				} else {
					System.out.println(userIDs[0]+": unaccounted for message while entering lobby: "+tempString);
				}
			} else {
				System.out.println(userIDs[0]+": unaccounted for message while entering lobby: "+tempString);
			}
			tempString = null;
			messageConsumed = true;
		}
	}

	private void doUNNAMED() {					// state 3

		if (tempString != null) {
			StringTokenizer localST = new StringTokenizer(tempString);
			if (localST.countTokens() == 2) {
				String messType = localST.nextToken();
				if (messType.equals("203")) {
					int playerID = (Integer.valueOf(localST.nextToken())).intValue();
					int userIndex = 1;
					while ((userIndex < numberOfUsers) && (userIDs[userIndex] != -1)) {
						userIndex++;
					}
					if (userIndex != numberOfUsers) {
						userIDs[userIndex] = playerID;
						userNames[userIndex] = null;
						updatePending = true;
					}
				} else if (messType.equals("223")) {
					String playerIDStr = localST.nextToken();
					int playerIDInt = (Integer.valueOf(playerIDStr)).intValue();
					removeUserFromUserlist(playerIDInt);
					lobbyChat.removeUser(playerIDInt);
					drawOtherUsers(scrollImageGC[1]);
					refreshUsers = true;
				} else if (messType.equals("303")) {
					numberOfSessions = (Integer.valueOf(localST.nextToken())).intValue() - 1;
					if (numberOfSessions < 1) {
						numberOfSessions = 1;
					} else if (numberOfSessions > MAXNUMBEROFSESSIONS) {
						numberOfSessions = MAXNUMBEROFSESSIONS;
					}
					reshape(0,0,this.getParent().size().width,this.getParent().size().height);
				}
			} else if (localST.countTokens() > 2) {
				String messType = localST.nextToken();
				if (messType.equals("213")) {
					String playerStr = localST.nextToken();
					int playerID = (Integer.valueOf(playerStr)).intValue();
					String commandStr = localST.nextToken();
					if (commandStr.equals("imin") || commandStr.equals("uimin")) {
						int toSess = (Integer.valueOf(localST.nextToken())).intValue();
						int toPlay = (Integer.valueOf(localST.nextToken())).intValue();
						int userIndex = 1;
						while ((userIndex < numberOfUsers) && (userIDs[userIndex] != playerID)) {
							userIndex++;
						}
						if (userIndex == numberOfUsers) {
							userIndex = 1;
							while ((userIndex < numberOfUsers) && (userIDs[userIndex] != -1)) {
								userIndex++;
							}
							if (userIndex != numberOfUsers) {
								userIDs[userIndex] = playerID;
								userNames[userIndex] = null;
								lobbyChat.setUser(userIDs[userIndex],"(unknown)");
								updatePending = true;
							}
						}
						if (userIndex != numberOfUsers) {
							if (((gamePlayers[toSess][toPlay] == -1) || (gamePlayers[toSess][toPlay] == playerID)) && (toSess != 0)) {
								if (userSessLocations[userIndex] != 0) {
									gamePlayers[userSessLocations[userIndex]][userPlayLocations[userIndex]] = -1;
									gamePlayerNames[userSessLocations[userIndex]][userPlayLocations[userIndex]] = null;
								}
								userSessLocations[userIndex] = toSess;
								userPlayLocations[userIndex] = toPlay;
								gamePlayers[toSess][toPlay] = playerID;
								if (userNames[userIndex] != null) {
									gamePlayerNames[toSess][toPlay] = new String(userNames[userIndex]);
								} else {
									gamePlayerNames[toSess][toPlay] = null;
								}
							} else {
								if ((userSessLocations[userIndex] != 0) && (gameStates[userSessLocations[userIndex]] != GAMESETTINGUP)) {
									gamePlayers[userSessLocations[userIndex]][userPlayLocations[userIndex]] = -1;
									gamePlayerNames[userSessLocations[userIndex]][userPlayLocations[userIndex]] = null;
								}
								userSessLocations[userIndex] = 0;
								userPlayLocations[userIndex] = 0;
							}
						} else {
							System.out.println(userIDs[0]+": too many users tried to join with imin??? ("+playerID+")");
						}
						if ((toSess != 0) && (gameStates[toSess] != GAMESESSIONUNKNOWN) && (gameStates[toSess] != GAMESESSIONIDLE)) {
							System.out.println(userIDs[0]+": imin received for game not idle or unknown.  Game: "+toSess+" state: "+gameStates[toSess]);
						}
						gameStates[toSess] = GAMESESSIONIDLE;
						drawGames(scrollImageGC[0]);
						drawOtherUsers(scrollImageGC[1]);
						refreshGames = true;
						refreshUsers = true;
						repaint();
					} else if (commandStr.equals("imnamed")) {
						String playerNameStr = localST.nextToken();
						while (localST.hasMoreTokens()) {
							playerNameStr = playerNameStr + " " + localST.nextToken();
						}
						int userIndex = 1;
						while ((userIndex < numberOfUsers) && (userIDs[userIndex] != playerID)) {
							userIndex++;
						}
						if (userIndex == numberOfUsers) {
							userIndex = 1;
							while ((userIndex < numberOfUsers) && (userIDs[userIndex] != -1)) {
								userIndex++;
							}
							if (userIndex != numberOfUsers) {
								userIDs[userIndex] = playerID;
								updatePending = true;
							}
						}
						if (userIndex != numberOfUsers) {
							if (playerNameStr != null) {
								userNames[userIndex] = new String(playerNameStr);
							} else {
								userNames[userIndex] = null;
							}
							for (int newCtr=0;newCtr<numberOfSessions;newCtr++) {
								for (int userCtr=0;userCtr<usersPerSession;userCtr++) {
									if (gamePlayers[newCtr+1][userCtr] == playerID) {
										if (playerNameStr != null) {
											gamePlayerNames[newCtr+1][userCtr] = new String(playerNameStr);
										} else {
											gamePlayerNames[newCtr+1][userCtr] = null;
										}
									}
								}
							}
							markedInLastRefresh[userIndex] = true;
							lobbyChat.setUser(userIDs[userIndex],playerNameStr);
							drawGames(scrollImageGC[0]);
							refreshGames = true;
							drawOtherUsers(scrollImageGC[1]);
							refreshUsers = true;
							repaint();
						}
					}
				} else if (messType.equals("305")) {
					refreshGamePending0 = false;
					lastGameRefresh0 = new Date().getTime();
					int sessNum = (Integer.valueOf(localST.nextToken())).intValue();
					int numOccupied = (Integer.valueOf(localST.nextToken())).intValue();
					int theCapacity = (Integer.valueOf(localST.nextToken())).intValue();
					int passwordSet = (Integer.valueOf(localST.nextToken())).intValue();
					if (sessNum == 0) {
						if (numberOfUsers != theCapacity) {
							numberOfUsers = theCapacity;
							reshape(0,0,this.getParent().size().width,this.getParent().size().height);
						}
					} else if ((numOccupied == 0) && (passwordSet == 0)) {
						gameStates[sessNum] = GAMESESSIONIDLE;
					} else if ((numOccupied > 0) && (passwordSet == 0)) {
						gameStates[sessNum] = GAMEINPROGRESS;
					} else if (passwordSet == 1) {
						gameStates[sessNum] = GAMESETTINGUP;
					}
					drawGames(scrollImageGC[0]);
					refreshGames = true;
					repaint();
				}
			}
			tempString = null;
			messageConsumed = true;
		}
	}

	public void removeUserFromUserlist(int playerIDInt) {

		int playerIndex = 0;
		while ((playerIndex < numberOfUsers) && (userIDs[playerIndex] != playerIDInt)) {
			playerIndex++;
		}
		if (playerIndex != numberOfUsers) {
			if (userSessLocations[playerIndex] != 0) {
				gamePlayers[userSessLocations[playerIndex]][userPlayLocations[playerIndex]] = -1;
				gamePlayerNames[userSessLocations[playerIndex]][userPlayLocations[playerIndex]] = null;
				drawGames(scrollImageGC[0]);
				refreshGames = true;
			}
			for (int subPI=playerIndex;subPI<(numberOfUsers-1);subPI++) {
				userIDs[subPI] = userIDs[subPI+1];
				if (userNames[subPI+1] != null) {
					userNames[subPI] = new String(userNames[subPI+1]);
				} else {
					userNames[subPI] = null;
				}
				markedInLastRefresh[subPI] = markedInLastRefresh[subPI+1];
				userSessLocations[subPI] = userSessLocations[subPI+1];
				userPlayLocations[subPI] = userPlayLocations[subPI+1];
			}
			userIDs[numberOfUsers-1] = -1;
			userNames[numberOfUsers-1] = null;
			markedInLastRefresh[numberOfUsers-1] = false;
			drawOtherUsers(scrollImageGC[1]);
			refreshUsers = true;
			repaint();
		}
	}

	private void doACTIVE() {					// state 4

		if (tempString != null) {
			StringTokenizer localST = new StringTokenizer(tempString);
			if (localST.countTokens() == 2) {
				String messType = localST.nextToken();
				if (messType.equals("223")) {
					String playerIDStr = localST.nextToken();
					int playerIDInt = (Integer.valueOf(playerIDStr)).intValue();
					removeUserFromUserlist(playerIDInt);
					lobbyChat.removeUser(playerIDInt);
					drawOtherUsers(scrollImageGC[1]);
					refreshUsers = true;
					repaint();
				} else if (messType.equals("203")) {
					int playerID = (Integer.valueOf(localST.nextToken())).intValue();
					int userIndex = 1;
					while ((userIndex < numberOfUsers) && (userIDs[userIndex] != -1)) {
						userIndex++;
					}
					if (userIndex != numberOfUsers) {
						userIDs[userIndex] = playerID;
						userNames[userIndex] = null;
						updatePending = true;
					}
				} else if (messType.equals("303")) {
					numberOfSessions = (Integer.valueOf(localST.nextToken())).intValue() - 1;
					if (numberOfSessions < 1) {
						numberOfSessions = 1;
					} else if (numberOfSessions > MAXNUMBEROFSESSIONS) {
						numberOfSessions = MAXNUMBEROFSESSIONS;
					}
					reshape(0,0,this.getParent().size().width,this.getParent().size().height);
				}
			} else if (localST.countTokens() > 2) {
				String messType = localST.nextToken();
				if (messType.equals("211")) {
					String commandStr = localST.nextToken();
					if (commandStr.equals("imin")) {
						if (movingToSess != -1) {
							int toSess = (Integer.valueOf(localST.nextToken())).intValue();
							int toPlay = (Integer.valueOf(localST.nextToken())).intValue();
							if (toSess != 0) {
								if (gamePlayers[toSess][toPlay] == userIDs[0]) {
									userSessLocations[0] = movingToSess;
									userPlayLocations[0] = movingToPlay;
//									lobbyChat.postMessage(998,"goodhint","You are now chatting only with people in this room.");
								}
								movingToSess = -1;
								movingToPlay = -1;
								drawGames(scrollImageGC[0]);
								drawOtherUsers(scrollImageGC[1]);
								refreshGames = true;
								refreshUsers = true;
								repaint();
							}
						}
					}
				} else if (messType.equals("213")) {
					String playerStr = localST.nextToken();
					int playerID = (Integer.valueOf(playerStr)).intValue();
					String commandStr = localST.nextToken();
					if (commandStr.equals("pchat") || commandStr.equals("schat")) {
						int userIndex = 1;
						while ((userIndex < numberOfUsers) && (userIDs[userIndex] != playerID)) {
							userIndex++;
						}
						if (userIndex == numberOfUsers) {
							System.out.println("chat from unknown user: "+playerID);
						} else {
//							if (((userSessLocations[userIndex] == userSessLocations[0]) && (movingToSess == -1)) || (userSessLocations[userIndex] == movingToSess)) {
								String localTempStr = " ";
								while (localST.hasMoreTokens()) {
									localTempStr = localTempStr + " " + localST.nextToken();
								}
								localTempStr = localTempStr + " ";
								lobbyChat.postMessage(playerID,"chat",localTempStr);
//							}
						}
					} else if (commandStr.equals("imin") || commandStr.equals("uimin")) {
						int toSess = (Integer.valueOf(localST.nextToken())).intValue();
						int toPlay = (Integer.valueOf(localST.nextToken())).intValue();
						int userIndex = 1;
						while ((userIndex < numberOfUsers) && (userIDs[userIndex] != playerID)) {
							userIndex++;
						}
						if (userIndex == numberOfUsers) {
							userIndex = 1;
							while ((userIndex < numberOfUsers) && (userIDs[userIndex] != -1)) {
								userIndex++;
							}
							if (userIndex != numberOfUsers) {
								userIDs[userIndex] = playerID;
								userNames[userIndex] = null;
								lobbyChat.setUser(userIDs[userIndex],"(unknown)");
								updatePending = true;
							}
						}
						if (userIndex != numberOfUsers) {
							if (((gamePlayers[toSess][toPlay] == -1) || (gamePlayers[toSess][toPlay] == playerID) || ((movingToSess == toSess) && (gamePlayers[toSess][toPlay] == userIDs[0]))) && (toSess != 0)) {
								if ((userSessLocations[userIndex] != 0) && (gameStates[userSessLocations[userIndex]] != GAMESETTINGUP)) {
									gamePlayers[userSessLocations[userIndex]][userPlayLocations[userIndex]] = -1;
									gamePlayerNames[userSessLocations[userIndex]][userPlayLocations[userIndex]] = null;
								}
								userSessLocations[userIndex] = toSess;
								userPlayLocations[userIndex] = toPlay;
								gamePlayers[toSess][toPlay] = playerID;
								if (userNames[userIndex] != null) {
									gamePlayerNames[toSess][toPlay] = new String(userNames[userIndex]);
								} else {
									gamePlayerNames[toSess][toPlay] = null;
								}
							} else {
								if ((userSessLocations[userIndex] != 0) && (gameStates[userSessLocations[userIndex]] != GAMESETTINGUP)) {
									gamePlayers[userSessLocations[userIndex]][userPlayLocations[userIndex]] = -1;
									gamePlayerNames[userSessLocations[userIndex]][userPlayLocations[userIndex]] = null;
								}
								userSessLocations[userIndex] = 0;
								userPlayLocations[userIndex] = 0;
							}
						} else {
							System.out.println(userIDs[0]+": too many users tried to join with imin??? ("+playerID+")");
						}
						if ((toSess != 0) && (gameStates[toSess] != GAMESESSIONUNKNOWN) && (gameStates[toSess] != GAMESESSIONIDLE)) {
							System.out.println("imin received for game not idle or unknown.");
						}
						gameStates[toSess] = GAMESESSIONIDLE;
						drawGames(scrollImageGC[0]);
						drawOtherUsers(scrollImageGC[1]);
						refreshGames = true;
						refreshUsers = true;
						repaint();
					} else if (commandStr.equals("imnamed")) {
						String playerNameStr = localST.nextToken();
						while (localST.hasMoreTokens()) {
							playerNameStr = playerNameStr + " " + localST.nextToken();
						}
						int userIndex = 1;
						while ((userIndex < numberOfUsers) && (userIDs[userIndex] != playerID)) {
							userIndex++;
						}
						if (userIndex == numberOfUsers) {
							userIndex = 1;
							while ((userIndex < numberOfUsers) && (userIDs[userIndex] != -1)) {
								userIndex++;
							}
							if (userIndex != numberOfUsers) {
								userIDs[userIndex] = playerID;
								updatePending = true;
							}
						}
						if (userIndex != numberOfUsers) {
							if (playerNameStr != null) {
								userNames[userIndex] = new String(playerNameStr);
							} else {
								userNames[userIndex] = null;
							}
							for (int newCtr=0;newCtr<numberOfSessions;newCtr++) {
								for (int userCtr=0;userCtr<usersPerSession;userCtr++) {
									if (gamePlayers[newCtr+1][userCtr] == playerID) {
										if (playerNameStr != null) {
											gamePlayerNames[newCtr+1][userCtr] = new String(playerNameStr);
										} else {
											gamePlayerNames[newCtr+1][userCtr] = null;
										}
									}
								}
							}
							markedInLastRefresh[userIndex] = true;
							lobbyChat.setUser(userIDs[userIndex],playerNameStr);
							drawGames(scrollImageGC[0]);
							refreshGames = true;
							drawOtherUsers(scrollImageGC[1]);
							refreshUsers = true;
							repaint();
						}
					} else if (commandStr.equals("setpw")) {
						int sessNum = (Integer.valueOf(localST.nextToken())).intValue();
						String thePassword = localST.nextToken();
						if (sessNum == userSessLocations[0]) {
							if ((startingSessNum != sessNum) || !launchingGame) {
								startingSessNum = sessNum;
								lobbyChat.postMessage(998,"chat",new String("Launching game session for "+sessionName+" "+startingSessNum));
							}
							startingSessNum = sessNum;
							launchingGame = true;
							startFlashFlag = true;
							startFlashTime = new Date().getTime();
							sessionNumbers[sessNum] = sessNum;
							sessionPasswords[sessNum] = thePassword;
							numPlayers[startingSessNum] = 0;
							for (int iSPI=0;iSPI<usersPerSession;iSPI++) {
								if (gamePlayers[startingSessNum][iSPI] != -1) {
									numPlayers[startingSessNum]++;
								}
							}
							loadNeeded = true;
						} else if (sessNum == movingToSess) {
							for (int gamePI=0;gamePI<usersPerSession;gamePI++) {
								if (gamePlayers[sessNum][gamePI] == userIDs[0]) {
									gamePlayers[sessNum][gamePI] = -1;
									gamePlayerNames[sessNum][gamePI] = null;
								}
							}
							userSessLocations[0] = 0;
							userPlayLocations[0] = 0;
							movingToSess = -1;
							movingToPlay = -1;
							drawOtherUsers(scrollImageGC[1]);
							drawGames(scrollImageGC[0]);
							refreshGames = true;
							refreshUsers = true;
							repaint();
						} else if (gameStates[sessNum] == GAMESESSIONIDLE) {
							gameStates[sessNum] = GAMESETTINGUP;
							drawGames(scrollImageGC[0]);
							refreshGames = true;
							repaint();
						}
					}
				} else if (messType.equals("305")) {
					refreshGamePending0 = false;
					lastGameRefresh0 = new Date().getTime();
					int sessNum = (Integer.valueOf(localST.nextToken())).intValue();
					int numOccupied = (Integer.valueOf(localST.nextToken())).intValue();
					int theCapacity = (Integer.valueOf(localST.nextToken())).intValue();
					int passwordSet = (Integer.valueOf(localST.nextToken())).intValue();
					if (sessNum == 0) {
						if (numberOfUsers != theCapacity) {
							numberOfUsers = theCapacity;
							reshape(0,0,this.getParent().size().width,this.getParent().size().height);
						}
					} else if ((numOccupied == 0) && (passwordSet == 0)) {
						if (gameStates[sessNum] != GAMESESSIONIDLE) {
							for (int pI=0;pI<MAXPLAYERSPERGAME;pI++) {
								gamePlayers[sessNum][pI] = -1;
								gamePlayerNames[sessNum][pI] = null;
							}
							for (int pI=0;pI<MAXNUMBEROFSPECTATORS;pI++) {
								gameSpectators[sessNum][pI] = -1;
								gameSpectatorNames[sessNum][pI] = null;
							}
						}
						gameStates[sessNum] = GAMESESSIONIDLE;
					} else if ((numOccupied > 0) && (passwordSet == 0)) {
						gameStates[sessNum] = GAMEINPROGRESS;
					} else if (passwordSet == 1) {
						gameStates[sessNum] = GAMESETTINGUP;
					}
					drawGames(scrollImageGC[0]);
					refreshGames = true;
					repaint();
				} else if (messType.equals("307")) {
					int sessNum = (Integer.valueOf(localST.nextToken())).intValue();
					int playerID = (Integer.valueOf(localST.nextToken())).intValue();
					int passwordFlag = (Integer.valueOf(localST.nextToken())).intValue();
					String theName = localST.nextToken();
					while (localST.hasMoreTokens()) {
						theName = theName + " " + localST.nextToken();
					}
					if (sessNum != 0) {
						if (refreshGamePending[sessNum]) {
							refreshGamePending[sessNum] = false;
							for (int pI=0;pI<MAXPLAYERSPERGAME;pI++) {
								gamePlayers[sessNum][pI] = -1;
								gamePlayerNames[sessNum][pI] = null;
							}
							for (int pI=0;pI<MAXNUMBEROFSPECTATORS;pI++) {
								gameSpectators[sessNum][pI] = -1;
								gameSpectatorNames[sessNum][pI] = null;
							}
						}
						int pI = 0;
						while ((pI < MAXPLAYERSPERGAME) && (gamePlayers[sessNum][pI] != -1)) {
							pI++;
						}
						if ((pI != MAXPLAYERSPERGAME) && (passwordFlag == 1)) {
							gamePlayers[sessNum][pI] = playerID;
							if (theName != null) {
								gamePlayerNames[sessNum][pI] = new String(theName);
							} else {
								gamePlayerNames[sessNum][pI] = null;
							}
						}
						if ((pI != MAXNUMBEROFSPECTATORS) && (passwordFlag != 1)) {
							pI = 0;
							while ((pI < MAXNUMBEROFSPECTATORS) && (gameSpectators[sessNum][pI] != -1)) {
								pI++;
							}
							if (pI != MAXNUMBEROFSPECTATORS) {
								gameSpectators[sessNum][pI] = playerID;
								if (theName != null) {
									gameSpectatorNames[sessNum][pI] = new String(theName);
								} else {
									gameSpectatorNames[sessNum][pI] = null;
								}
//								System.out.println(userIDs[0]+" : just set spectator "+pI+"'s name to "+theName);
							}
						}
						lastGameRefresh[sessNum] = new Date().getTime();
						drawGames(scrollImageGC[0]);
						refreshGames = true;
					} else {
						if (refreshGamePending[0]) {
							refreshGamePending[0] = false;
							for (int tempInt=0;tempInt<numberOfUsers;tempInt++) {
								if (!markedInLastRefresh[tempInt]) {
									userIDs[tempInt] = -1;
									userNames[tempInt] = null;
								}
							}
							for (int tempInt=0;tempInt<numberOfUsers;tempInt++) {
								markedInLastRefresh[tempInt] = false;
							}
						}
						int pI = 0;
						while ((pI < numberOfUsers) && (userIDs[pI] != playerID)) {
							pI++;
						}
						if (pI == numberOfUsers) {
							pI = 0;
							while ((pI < numberOfUsers) && (userIDs[pI] != -1)) {
								pI++;
							}
							if (pI != numberOfUsers) {
								userIDs[pI] = playerID;
								updatePending = true;
							}
						}
						if (pI != numberOfUsers) {
							if ((userNames[pI] == null) || (!(userNames[pI].equals(theName)))) {
								if (theName != null) {
									userNames[pI] = new String(theName);
								} else {
									userNames[pI] = null;
								}
								lobbyChat.setUser(userIDs[pI],theName);
								drawOtherUsers(scrollImageGC[1]);
								refreshUsers = true;
								repaint();
							}
							markedInLastRefresh[pI] = true;
						}
						lastGameRefresh[0] = new Date().getTime();
					}
					repaint();
				} else if (messType.equals("333")) {
					int sessNum = (Integer.valueOf(localST.nextToken())).intValue();
					String thePassword = localST.nextToken();
					if (launchingGame) {
						sessionPasswords[sessNum] = thePassword;
						tempSB = new StringBuffer("210 setpw "+sessNum+" "+thePassword);
						if (!myNetConn.sendMessage(tempSB)) {
							System.out.println("NF 1");
							lobbyChat.setUser(0,0,"Lobby");
							lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
							lobbyState = IDLE;
						}
					}
				} else if (messType.equals("999")) {
					String intMessType = localST.nextToken();
					if (intMessType.equals("306")) {
						int sessNum = (Integer.valueOf(localST.nextToken())).intValue();
						refreshGamePending[sessNum] = false;
						for (int pI=0;pI<MAXPLAYERSPERGAME;pI++) {
							gamePlayers[sessNum][pI] = -1;
							gamePlayerNames[sessNum][pI] = null;
						}
						for (int pI=0;pI<MAXNUMBEROFSPECTATORS;pI++) {
							gameSpectators[sessNum][pI] = -1;
							gameSpectatorNames[sessNum][pI] = null;
						}
					}
				}
			}
			tempString = null;
			messageConsumed = true;
		}
	}

	private void doDelay(int inDel) {

		try {
			Thread.sleep(inDel);
		} catch (InterruptedException e) {
			System.out.println("Sleep was interrupted.");
		}
	}

	public void run() {

		doInit();
		for (;;) {
			if (exitFlag) {
				break;
			}
			if (numOccupants < (numberOfUsers - 5)) {
				doTouch();
			}
			if (loadNeeded) {
				loadNeeded = false;
				if (((!loadSucceeded) && (myLT == null)) || loadFailed) {
					myLT = null;
					loadFailed = false;
					myLT = new loadThread();
					myLT.setLoadParameters(appletName,this);
					myLT.start();
				}
			}
			if ((new Date().getTime()) > (lobbyIdleTimeout - 60000)) {	/* 1 min. warning */
				boolean noPlayFrames = true;
				for (int pfCtr=0;pfCtr<numberOfSessions;pfCtr++) {
					if (playFrame[pfCtr+1] != null) {
						noPlayFrames = false;
					}
				}
				if (noPlayFrames && !gaveWarning && (refreshInterval == ACTIVEREFRESHINTERVAL)) {
					lobbyChat.postMessage(998,"chat","Time is "+(new Date().getHours())+":"+(new Date().getMinutes())+"  Lobby will shutdown in 1 minute (idle).");
					lobbyIdleTimeout = new Date().getTime() + 60000;
					gaveWarning = true;
					repaint();
				}
				if (noPlayFrames && gaveWarning && ((new Date().getTime()) > lobbyIdleTimeout)) {
					lobbyChat.postMessage(998,"chat","Lobby shutdown...");
					lobbyState = IDLE;
					drawOtherUsers(scrollImageGC[1]);
					drawGames(scrollImageGC[0]);
					refreshUsers = true;
					refreshGames = true;
					repaint();
					kill();
					break;
				}
			}
			long currentTime = new Date().getTime();
			if (launchingGame) {
				if (currentTime > (startFlashTime + FLASHINTERVAL)) {
					startFlashTime = currentTime;
					if (gameStates[startingSessNum] != GAMESETTINGUP) {
						if (startFlashFlag) {
							myDrawPolygon(scrollImageGC[0],STARTXOFFSET,(startingSessNum-1)*GAMEHEIGHT+STARTYOFFSET,startPoly,Color.black,Color.black,"Start",Color.white);
						} else {
							myDrawPolygon(scrollImageGC[0],STARTXOFFSET,(startingSessNum-1)*GAMEHEIGHT+STARTYOFFSET,startPoly,Color.white,Color.black,"Start",Color.black);
						}
					}
					startFlashFlag = !startFlashFlag;
				}
				if ((sessionPasswords[startingSessNum] != null) && (loadSucceeded)) {
					launchGame(appletName,startingSessNum,sessionPasswords[startingSessNum],numPlayers[startingSessNum]-1);
					gameStates[startingSessNum] = GAMESETTINGUP;
					launchingGame = false;
					tempSB = new StringBuffer("210 imin 0 0 ");
					if (!myNetConn.sendMessage(tempSB)) {
						System.out.println("NF 2");
						lobbyChat.setUser(0,0,"Lobby");
						lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
						lobbyState = IDLE;
					}
					userSessLocations[0] = 0;
					userPlayLocations[0] = 0;
					drawOtherUsers(scrollImageGC[1]);
					refreshUsers = true;
					drawGames(scrollImageGC[0]);
				}
				refreshGames = true;
				repaint();
			}
			if (launchSpectator != -1) {
				if (currentTime > (startFlashTime + FLASHINTERVAL)) {
					startFlashTime = currentTime;
					if (startFlashFlag) {
						myDrawPolygon(scrollImageGC[0],SPECTATORTITLEXOFFSET+SPECTATORWIDTH,(startingSessNum-1)*GAMEHEIGHT+PLAYERTITLEYOFFSET-SPECTATORBUTTONYOFFSET,narrowPoly,Color.black,Color.black,"Spectate",Color.white);
					} else {
						myDrawPolygon(scrollImageGC[0],SPECTATORTITLEXOFFSET+SPECTATORWIDTH,(startingSessNum-1)*GAMEHEIGHT+PLAYERTITLEYOFFSET-SPECTATORBUTTONYOFFSET,narrowPoly,Color.white,Color.black,"Spectate",Color.black);
					}
					startFlashFlag = !startFlashFlag;
				}
				if (loadSucceeded) {
					launchGameSpectator(appletName,startingSessNum);
					launchSpectator = -1;
					spectatorOf = -1;
				}
				repaint();
			}
			if ((lobbyState == ACTIVE) || (lobbyState == UNNAMED)) {
				if (!refreshGamePending0 && (currentTime > (lastGameRefresh0 + refreshInterval))) {
					refreshGamePending0 = true;
					tempSB = new StringBuffer("304 ");
					if (!myNetConn.sendMessage(tempSB)) {
						System.out.println("NF 3");
						lobbyChat.setUser(0,0,"Lobby");
						lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
						lobbyState = IDLE;
					}
				}
			}
			if (refreshInterval == ACTIVEREFRESHINTERVAL) {
				if ((lobbyState == ACTIVE) && !launchingGame && (launchSpectator == -1)) {
					for (int gameIndex=1;gameIndex<(numberOfSessions+1);gameIndex++) {
						if (((gameStates[gameIndex] == GAMEINPROGRESS) || (gameStates[gameIndex] == GAMESETTINGUP)) && !refreshGamePending[gameIndex] && (currentTime > (lastGameRefresh[gameIndex] + refreshInterval))) {
							refreshGamePending[gameIndex] = true;
							lastGameRefresh[gameIndex] = new Date().getTime();
							tempSB = new StringBuffer("306 "+gameIndex);
							if (!myNetConn.sendMessage(tempSB)) {
								System.out.println("NF 4");
								lobbyChat.setUser(0,0,"Lobby");
								lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
								lobbyState = IDLE;
							}
						}
					}
				}
				if ((lobbyState == UNNAMED) || (lobbyState == ACTIVE)) {
					if (!refreshGamePending[0] && (currentTime > (lastGameRefresh[0] + refreshInterval))) {
						refreshGamePending[0] = true;
						tempSB = new StringBuffer("306 0");
						if (!myNetConn.sendMessage(tempSB)) {
							System.out.println("NF 5");
							lobbyChat.setUser(0,0,"Lobby");
							lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
							lobbyState = IDLE;
						}
					}
				}
			}
			if (justDidReshape) {
				justDidReshape = false;
				drawGames(scrollImageGC[0]);
				refreshGames = true;
				repaint();
			}
			if (updatePending && (movingToSess == -1)) {
				updatePending = false;
				tempSB = new StringBuffer("210 uimin "+userSessLocations[0]+" "+userPlayLocations[0]);
				if (!myNetConn.sendMessage(tempSB)) {
					System.out.println("NF 6");
					lobbyChat.setUser(0,0,"Lobby");
					lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
					lobbyState = IDLE;
				}
				if (userNames[0] != null) {
					tempSB = new StringBuffer("210 imnamed "+userNames[0]);
					if (!myNetConn.sendMessage(tempSB)) {
						System.out.println("NF 7");
						lobbyChat.setUser(0,0,"Lobby");
						lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
						lobbyState = IDLE;
					}
				}
			}
			if (smallRepeatFlag) {
				if (repeatWait < (new Date().getTime())) {
					repeatWait = new Date().getTime() + REPEATINTERVAL;
					smallJump(scrollingArea,repeatDirection);
					if (scrollingArea == 0) {
						refreshGames = true;
					} else {
						refreshUsers = true;
					}
					repaint();
				}
			} else if (bigRepeatFlag) {
				if (repeatWait < (new Date().getTime())) {
					repeatWait = new Date().getTime() + REPEATINTERVAL;
					bigJump(scrollingArea,repeatDirection);
					if (scrollingArea == 0) {
						refreshGames = true;
					} else {
						refreshUsers = true;
					}
					repaint();
				}
			}
			newSizeX = this.getParent().size().width;
			newSizeY = this.getParent().size().height;
			if ((newSizeX != oldSizeX) || (newSizeY != oldSizeY)) {
				oldSizeX = newSizeX;
				oldSizeY = newSizeY;
				reshape(0,0,newSizeX,newSizeY);
				justDidReshape = true;
			}
			if ((tempString == null) || messageConsumed) {
				tempString = myNetConn.getInputItem();
				messageConsumed = false;
			}
			mainLoopDelay = DEFAULTLOOPDELAY;
			if ((launchingGame || (tempString != null) || (spectatorOf != -1)) && (lobbyState != IDLE)) {
				mainLoopDelay = 25;
			}
			if (lobbyState == IDLE) {			// state 0
			} else if (lobbyState == UNCONNECTED) {		// state 1
				doUNCONNECTED();
			} else if (lobbyState == NOTINLOBBY) {		// state 2
				doNOTINLOBBY();
			} else if (lobbyState == UNNAMED) {			// state 3
				doUNNAMED();
			} else if (lobbyState == ACTIVE) {			// state 4
				doACTIVE();
			} else {
				System.out.println(userIDs[0]+"  Invalid lobbyState! "+lobbyState);
				lobbyState = IDLE;
			}
			doDelay(mainLoopDelay);
		}
	}

	public int inSpectate(int inX, int inY) {

		if ((inX < scrollRect[0].x) || (inX > (scrollRect[0].x+scrollRect[0].width)) || (inY <scrollRect[0].y) || (inY > (scrollRect[0].y+scrollRect[0].height))) {
			return(-1);
		}
		int localX = inX - scrollRect[0].x - SPECTATORTITLEXOFFSET - SPECTATORWIDTH;
		int localY = inY - scrollRect[0].y - currentImageOffset[0];
		int sessionNum = localY/GAMEHEIGHT;
		if ((gameStates[sessionNum+1] != GAMEINPROGRESS) || (playFrame[sessionNum+1] != null)) {
			return(-1);
		}
		localY = localY - sessionNum*GAMEHEIGHT - PLAYERTITLEYOFFSET + SPECTATORBUTTONYOFFSET;
		int inNum = -1;
		if (narrowPoly.inside(localX,localY)) {
			inNum = sessionNum+1;
			origX = SPECTATORTITLEXOFFSET+SPECTATORWIDTH+scrollRect[0].x;
			origY = sessionNum*GAMEHEIGHT+PLAYERTITLEYOFFSET-SPECTATORBUTTONYOFFSET + scrollRect[0].y + currentImageOffset[0];
		}
		return(inNum);
	}

	public int inInfo(int inX, int inY) {

		if ((inX < scrollRect[0].x) || (inX > (scrollRect[0].x+scrollRect[0].width)) || (inY <scrollRect[0].y) || (inY > (scrollRect[0].y+scrollRect[0].height))) {
			return(-1);
		}
		int localX = inX - scrollRect[0].x - GAMEIMAGEWIDTH + INFODELTAX;
		int localY = inY - scrollRect[0].y - currentImageOffset[0];
		int sessionNum = localY/GAMEHEIGHT;
		localY = localY - sessionNum*GAMEHEIGHT - INFODELTAY;
		if ((localX < INFOWIDTH) && (localY < INFOHEIGHT)) {
			return(sessionNum+1);
		}
		return(-1);
	}

	public int inStart(int inX, int inY) {

		if ((inX < scrollRect[0].x) || (inX > (scrollRect[0].x+scrollRect[0].width)) || (inY <scrollRect[0].y) || (inY > (scrollRect[0].y+scrollRect[0].height))) {
			return(-1);
		}
		int localX = inX - scrollRect[0].x - STARTXOFFSET;
		int localY = inY - scrollRect[0].y - currentImageOffset[0];
		int sessionNum = localY/GAMEHEIGHT;
		if (gameStates[sessionNum+1] != GAMESESSIONIDLE) {
			return(-1);
		}
		int playerCount = 0;
		for (int iSPI=0;iSPI<usersPerSession;iSPI++) {
			if (gamePlayers[sessionNum+1][iSPI] != -1) {
				playerCount++;
			}
		}
		if (playerCount < minPlayersForLaunch) {
			return(-1);
		}
		localY = localY - sessionNum*GAMEHEIGHT - STARTYOFFSET;
		if (startPoly.inside(localX,localY)) {
			return(sessionNum+1);
		}
		return(-1);
	}

	public Point draggedOverPlay(int inX, int inY) {

		if ((inX < (scrollRect[0].x-20)) || (inX > (scrollRect[0].x+scrollRect[0].width)) || (inY < (scrollRect[0].y-20)) || (inY > (scrollRect[0].y+scrollRect[0].height+20))) {
			return(new Point(-1,-1));
		}
		int sessionY = inY - scrollRect[0].y - currentImageOffset[0];
		int sessionNum = sessionY/GAMEHEIGHT;
		if (gameStates[sessionNum+1] != GAMESESSIONIDLE) {
			return(new Point(-1,-1));
		}
		if (playFrame[sessionNum+1] != null) {
			return(new Point(-1,-1));
		}
		int localX;
		int localY;
		Point inPoint = new Point(-1,-1);
		for (int playerSpaceIndex=0;playerSpaceIndex<usersPerSession;playerSpaceIndex++) {
			localX = inX - scrollRect[0].x - POLYXOFFSETS[playerSpaceIndex];
			localY = inY - scrollRect[0].y - currentImageOffset[0] - sessionNum*GAMEHEIGHT - POLYYOFFSETS[playerSpaceIndex];
			if (playPoly.inside(localX,localY)) {
				inPoint = new Point(sessionNum+1,playerSpaceIndex);
				return(inPoint);
			}
		}
		for (int playerSpaceIndex=0;playerSpaceIndex<usersPerSession;playerSpaceIndex++) {
			localX = inX - scrollRect[0].x - POLYXOFFSETS[playerSpaceIndex];
			localY = inY - scrollRect[0].y - currentImageOffset[0] - sessionNum*GAMEHEIGHT - POLYYOFFSETS[playerSpaceIndex];
			for (int pointIndex=0;pointIndex<playPoly.npoints;pointIndex++) {
				if (playPoly.inside(localX+playPoly.xpoints[pointIndex],localY+playPoly.ypoints[pointIndex])) {
					inPoint = new Point(sessionNum+1,playerSpaceIndex);
					if ((inPoint.x == playPoint.x) && (inPoint.y == playPoint.y)) {
						return(inPoint);
					}
				}
			}
		}
		return(inPoint);
	}

	public synchronized String inPlay(int inX, int inY) {

		if ((inX < (scrollRect[0].x)) || (inX > (scrollRect[0].x+scrollRect[0].width-scrollbarRect[0].width)) || (inY < (scrollRect[0].y)) || (inY > (scrollRect[0].y+scrollRect[0].height))) {
			return(null);
		}
		int sessionY = inY - scrollRect[0].y - currentImageOffset[0];
		int sessionNum = sessionY/GAMEHEIGHT;
		int localX;
		int localY;
		String theName = null;
		for (int playerSpaceIndex=0;playerSpaceIndex<usersPerSession;playerSpaceIndex++) {
			localX = inX - scrollRect[0].x - POLYXOFFSETS[playerSpaceIndex];
			localY = inY - scrollRect[0].y - currentImageOffset[0] - sessionNum*GAMEHEIGHT - POLYYOFFSETS[playerSpaceIndex];
			if (playPoly.inside(localX,localY)) {
				if (gamePlayerNames[sessionNum+1][playerSpaceIndex] != null) {
					if (!(gamePlayerNames[sessionNum+1][playerSpaceIndex].equals(userNames[0]))) {
						theName = gamePlayerNames[sessionNum+1][playerSpaceIndex];
					}
				}
			}
		}
		if (gameStates[sessionNum+1] != GAMESESSIONIDLE) {
			if (theName != null) {
				if (gameStates[sessionNum+1] == GAMESETTINGUP) {
					lobbyChat.postMessage(998,"badhint","Can't reach "+theName+" while session "+(sessionNum+1)+" is launching.");
				} else if (gameStates[sessionNum+1] == GAMEINPROGRESS) {
					lobbyChat.postMessage(998,"badhint","You must join session "+(sessionNum+1)+" a spectator to talk to "+theName);
				}
			}
			return(null);
		}
		return(theName);
	}

	public synchronized int inPlaySess(int inX, int inY) {

		if ((inX < (scrollRect[0].x)) || (inX > (scrollRect[0].x+scrollRect[0].width-scrollbarRect[0].width)) || (inY < (scrollRect[0].y)) || (inY > (scrollRect[0].y+scrollRect[0].height))) {
			return(-1);
		}
		return((inY - scrollRect[0].y - currentImageOffset[0])/GAMEHEIGHT);
	}

	public synchronized String inLobbyIcon(int inX, int inY) {

		if ((inX < (scrollRect[1].x+scrollbarRect[1].width)) || (inX > (scrollRect[1].x+scrollRect[1].width)) || (inY < scrollRect[1].y) || (inY > (scrollRect[1].y+scrollRect[1].height))) {
			return(null);
		}
		return(lobbyNames[(inY - scrollRect[1].y - currentImageOffset[1])/USERHEIGHT]);
	}

	public boolean draggedOverMyPlay(int inX, int inY) {

		if ((inX < (ownerRect.x-20)) || (inX > (ownerRect.x+ownerRect.width)) || (inY < ownerRect.y) || (inY > (ownerRect.y+ownerRect.height+20))) {
			return(false);
		}
		int localX = inX - ownerRect.x - (USERSCROLLWIDTH - SCROLLBARWIDTH - PolyParams[1] - 3);
		int localY = inY - ownerRect.y - (PolyParams[0]+3);
		for (int pointIndex=0;pointIndex<playPoly.npoints;pointIndex++) {
			if (playPoly.inside(localX+playPoly.xpoints[pointIndex],localY+playPoly.ypoints[pointIndex])) {
				return(true);
			}
		}
		return(false);
	}

	public boolean inMyToken(int inX, int inY) {

		if (movingToSess != -1) {
			return(false);
		}
		if (userSessLocations[0] == 0) {
			if ((inX < ownerRect.x) || (inX > (ownerRect.x+ownerRect.width+20)) || (inY < (ownerRect.y-10)) || (inY > (ownerRect.y+ownerRect.height+10))) {
				return(false);
			}
			int localX = inX - ownerRect.x - (USERSCROLLWIDTH - SCROLLBARWIDTH - PolyParams[1] - 3);
			int localY = inY - ownerRect.y - (PolyParams[0]+3);
			if (playPoly.inside(localX,localY)) {
				origX = ownerRect.x + (USERSCROLLWIDTH - SCROLLBARWIDTH - PolyParams[1] - 3);
				origY = ownerRect.y + (PolyParams[0]+3);
				return(true);
			}
		} else {
			if ((inX < (scrollRect[0].x)) || (inX > (scrollRect[0].x+scrollRect[0].width)) || (inY < (scrollRect[0].y)) || (inY > (scrollRect[0].y+scrollRect[0].height))) {
				return(false);
			}
			int sessionY = inY - scrollRect[0].y - currentImageOffset[0];
			int sessionNum = sessionY/GAMEHEIGHT;
			if ((sessionNum+1) != userSessLocations[0]) {
				return(false);
			}
			int localX = inX - scrollRect[0].x - POLYXOFFSETS[userPlayLocations[0]];
			int localY = inY - scrollRect[0].y - currentImageOffset[0] - sessionNum*GAMEHEIGHT - POLYYOFFSETS[userPlayLocations[0]];
			if (playPoly.inside(localX,localY)) {
				origX = scrollRect[0].x + POLYXOFFSETS[userPlayLocations[0]];
				origY = scrollRect[0].y + currentImageOffset[0] + sessionNum*GAMEHEIGHT + POLYYOFFSETS[userPlayLocations[0]];
				return(true);
			}
		}
		return(false);
	}

	private boolean goodNameString(String inStr) {

		if (inStr == null) {
			return(false);
		}
		StringTokenizer checkST = new StringTokenizer(inStr);
		if (!checkST.hasMoreTokens()) {
			return(false);
		}
		String localNameString = checkST.nextToken();
		while (checkST.hasMoreTokens()) {
			localNameString = localNameString + " " + checkST.nextToken();
		}
		if (localNameString.length() < 4) {
			return(false);
		}
		StringBuffer mySB = new StringBuffer(localNameString);
		int tI;
		for (int sbIndex=0;sbIndex<mySB.length();sbIndex++) {
			tI = (int)mySB.charAt(sbIndex);
			if (((tI < (int)'0') || (tI > (int)'9')) && ((tI < (int)'a') || (tI > (int)'z')) && ((tI < (int)'A') || (tI > (int)'Z')) && (tI != (int)' ')) {
				return(false);
			}
		}
		return(true);
	}

	public void doTouch() {

		lobbyIdleTimeout = new Date().getTime() + lobbyIdleTimeoutInterval;
		gaveWarning = false;
	}

	public boolean action(Event e, Object target) {

		if ((e.target == submitButton) || (e.target == nameInput)) {
			lobbyIdleTimeout = new Date().getTime() + lobbyIdleTimeoutInterval;
			gaveWarning = false;
			String theName = nameInput.getText();
			if (goodNameString(theName)) {
				tempSB = new StringBuffer("204 "+theName);
				if (!myNetConn.sendMessage(tempSB)) {
					System.out.println("Failed to send name message.");
					lobbyState = IDLE;
				}
				userNames[0] = new String(theName);
				markedInLastRefresh[0] = true;
				remove(submitButton);
				remove(nameRequest);
				remove(nameInput);
				remove(nameSpec);
				lobbyChat.doReshape(10,10,chatWidth,chatHeight);
				lobbyChat.setUser(0,userIDs[0],theName);					/* set owner info */
				((RootApplet)theRootApplet).setFrameName(theName+" - "+frameName);
				showGames = true;
				showChat = true;
				repaint();
				for (int i=0;i<(MAXNUMBEROFSESSIONS+1);i++) {
					lastGameRefresh[i] = 0;
					refreshGamePending[i] = false;
				}
				lobbyState = ACTIVE;
				updatePending = true;
			} else {
				((RootApplet)theRootApplet).playASoundClip(badNameSoundNumber);
				nameSpec.setForeground(Color.red);
				repaint();
			}
		}
		return(super.action(e,target));
	}

	public boolean handleEvent(Event e) {

		if (!initialized) {
			return(super.handleEvent(e));
		}
		if (e.target == nameInput) {
			lobbyIdleTimeout = new Date().getTime() + lobbyIdleTimeoutInterval;
			gaveWarning = false;
			if ((nameInput.getText()).length() > MAXSTRINGLENGTH) {
				int sStart = nameInput.getSelectionStart();
				int sEnd = nameInput.getSelectionEnd();
				nameInput.setText((nameInput.getText()).substring(0,MAXSTRINGLENGTH));
				if ((sStart > MAXSTRINGLENGTH) || (sStart > MAXSTRINGLENGTH)) {
					nameInput.select(MAXSTRINGLENGTH,MAXSTRINGLENGTH);
				} else {
					nameInput.select(sStart,sEnd);
				}
			}
		} else if (e.id == Event.MOUSE_DOWN) {
			lobbyIdleTimeout = new Date().getTime() + lobbyIdleTimeoutInterval;
			gaveWarning = false;
			for (int scrollAreaIndex=0;scrollAreaIndex<2;scrollAreaIndex++) {
				if (inScrollAreaRect(scrollAreaIndex,e.x,e.y)) {
					if (inScrollAreaBarRect(scrollAreaIndex,e.x,e.y)) {
						if (inScrollAreaBarUp(scrollAreaIndex,e.x,e.y)) {
							smallJump(scrollAreaIndex,true);
							smallRepeatFlag = true;
							repeatDirection = true;
						} else if (inScrollAreaBarJumpUp(scrollAreaIndex,e.x,e.y)) {
							bigJump(scrollAreaIndex,true);
							bigRepeatFlag = true;
							repeatDirection = true;
						} else if (inScrollAreaBarDown(scrollAreaIndex,e.x,e.y)) {
							smallJump(scrollAreaIndex,false);
							smallRepeatFlag = true;
							repeatDirection = false;
						} else if (inScrollAreaBarJumpDown(scrollAreaIndex,e.x,e.y)) {
							bigJump(scrollAreaIndex,false);
							bigRepeatFlag = true;
							repeatDirection = false;
						} else if (inScrollAreaBarThumb(scrollAreaIndex,e.x,e.y)) {
							scrolling[scrollAreaIndex] = true;
							saveThumb = currentThumbOffset[scrollAreaIndex];
							saveY = e.y;
						}
						scrollingArea = scrollAreaIndex;
						repeatWait = new Date().getTime() + 2*REPEATINTERVAL;
						if (scrollAreaIndex == 0) {
							refreshGames = true;
						} else {
							refreshUsers = true;
						}
					}
				}
			}
			int inI = inInfo(e.x,e.y);
			if (inI != -1) {
				String newMess = null;
				if (gameStates[inI] == GAMESESSIONUNKNOWN) {
					newMess = "Session number "+inI+": state unknown.";
				} else {
					if (gameStates[inI] == GAMESESSIONIDLE) {
						newMess = "Session number "+inI+" is idle.  ";
					} else if (gameStates[inI] == GAMESETTINGUP) {
						newMess = "Session number "+inI+" is being launched.  ";
					} else if (gameStates[inI] == GAMEINPROGRESS) {
						newMess = "Session number "+inI+" is active.  ";
					}
					int countPs = 0;
					for (int countr=0;countr<usersPerSession;countr++) {
						if (gamePlayers[inI][countr] != -1) {
							countPs++;
						}
					}
					if (countPs > 2) {
						newMess += "Players are: ";
						for (int countr=0;countr<usersPerSession;countr++) {
							if (gamePlayers[inI][countr] != -1) {
								if (countPs > 2) {
									newMess += gamePlayerNames[inI][countr] + ", ";
									countPs--;
								} else if (countPs == 2) {
									newMess += gamePlayerNames[inI][countr] + " and ";
									countPs--;
								} else {
									newMess += gamePlayerNames[inI][countr] + ".";
								}
							}
						}
					} else if (countPs == 2) {
						newMess += "Players are: ";
						for (int countr=0;countr<usersPerSession;countr++) {
							if (gamePlayers[inI][countr] != -1) {
								if (countPs == 2) {
									newMess += gamePlayerNames[inI][countr] + " and ";
									countPs--;
								} else {
									newMess += gamePlayerNames[inI][countr] + ".";
								}
							}
						}
					} else if (countPs == 1) {
						newMess += "Player is ";
						for (int countr=0;countr<usersPerSession;countr++) {
							if (gamePlayers[inI][countr] != -1) {
								newMess += gamePlayerNames[inI][countr] + ".";
							}
						}
					} else {
						newMess += "No players.";
					}
					if (gameStates[inI] == GAMEINPROGRESS) {
						int countSs = 0;
						for (int countr=0;countr<numberOfSpectators;countr++) {
							if (gameSpectators[inI][countr] != -1) {
								countSs++;
							}
						}
						newMess += "  ";
						if (countSs > 2) {
							newMess += "Spectators are: ";
							for (int countr=0;countr<numberOfSpectators;countr++) {
								if (gameSpectators[inI][countr] != -1) {
									if (countSs > 2) {
										newMess += gameSpectatorNames[inI][countr] + ", ";
										countSs--;
									} else if (countSs == 2) {
										newMess += gameSpectatorNames[inI][countr] + " and ";
										countSs--;
									} else {
										newMess += gameSpectatorNames[inI][countr] + ".";
									}
								}
							}
						} else if (countSs == 2) {
							newMess += "Spectators are: ";
							for (int countr=0;countr<numberOfSpectators;countr++) {
								if (gameSpectators[inI][countr] != -1) {
									if (countSs == 2) {
										newMess += gameSpectatorNames[inI][countr] + " and ";
										countSs--;
									} else {
										newMess += gameSpectatorNames[inI][countr] + ".";
									}
								}
							}
						} else if (countSs == 1) {
							newMess += "Spectator is ";
							for (int countr=0;countr<numberOfSpectators;countr++) {
								if (gameSpectators[inI][countr] != -1) {
									newMess += gameSpectatorNames[inI][countr] + ".";
								}
							}
						} else {
							newMess += "No spectators.";
						}
					}
				}
				if (lobbyState == IDLE) {
					newMess = "Lobby is not connected to the server.";
				}
				lobbyChat.postMessage(998,"chat",newMess);
			}
			if ((launchSpectator == -1) && !launchingGame) {
				spectatorOf = inSpectate(e.x,e.y);
				if (spectatorOf != -1) {
					if ((userSessLocations[0] != 0) || (movingToSess != -1)) {
						lobbyChat.postMessage(998,"badhint","You can only spectate from common lobby.");
					} else {
						lobbyChat.postMessage(998,"chat",new String("Launching spectator for "+sessionName+" "+spectatorOf));
						launchSpectator = spectatorOf;
						startingSessNum = launchSpectator;
						startFlashFlag = false;
						loadNeeded = true;
						int specNum = 0;
						while ((specNum < MAXNUMBEROFSPECTATORS) && (gameSpectators[startingSessNum][specNum] != -1)) {
							specNum++;
						}
						if (specNum < MAXNUMBEROFSPECTATORS) {
							gameSpectators[startingSessNum][specNum] = userIDs[0];
							gameSpectatorNames[startingSessNum][specNum] = userNames[0];
						}
						drawGames(scrollImageGC[0]);
						myDrawPolygon(scrollImageGC[0],SPECTATORTITLEXOFFSET+SPECTATORWIDTH,(startingSessNum-1)*GAMEHEIGHT+PLAYERTITLEYOFFSET-SPECTATORBUTTONYOFFSET,narrowPoly,Color.black,Color.black,"Spectate",Color.white);
						startFlashTime = new Date().getTime();
						refreshGames = true;
						repaint();
					}
				}
				if (lobbyState == ACTIVE) {
					int gameToStart = inStart(e.x,e.y);
					if (gameToStart != -1) {
						lobbyChat.postMessage(998,"chat",new String("Launching game session for "+sessionName+" "+gameToStart));
						startingSessNum = gameToStart;
						gameStates[startingSessNum] = GAMESETTINGUP;
						numPlayers[startingSessNum] = 0;
						for (int iSPI=0;iSPI<usersPerSession;iSPI++) {
							if (gamePlayers[startingSessNum][iSPI] != -1) {
								numPlayers[startingSessNum]++;
							}
						}
						launchingGame = true;
						startFlashFlag = false;
						loadNeeded = true;
						myDrawPolygon(scrollImageGC[0],STARTXOFFSET,(startingSessNum-1)*GAMEHEIGHT+STARTYOFFSET,startPoly,Color.black,Color.black,"Start",Color.white);
						startFlashTime = new Date().getTime();
						refreshGames = true;
						repaint();
						sessionPasswords[gameToStart] = null;
						sessionNumbers[gameToStart] = gameToStart;
						tempSB = new StringBuffer("332 "+gameToStart+" pass1234");
						if (!myNetConn.sendMessage(tempSB)) {
							System.out.println("NF 8");
							lobbyChat.setUser(0,0,"Lobby");
							lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
							lobbyState = IDLE;
						}
					}
				}
				if ((lobbyState == ACTIVE) && inMyToken(e.x,e.y)) {
					startX = e.x;
					startY = e.y;
					currentX = e.x;
					currentY = e.y;
					draggingMe = true;
					drawOtherUsers(scrollImageGC[1]);
					refreshUsers = true;
					if (userSessLocations[0] != 0) {
						gamePlayers[userSessLocations[0]][userPlayLocations[0]] = -1;
						gamePlayerNames[userSessLocations[0]][userPlayLocations[0]] = null;
						userSessLocations[0] = 0;
						userPlayLocations[0] = 0;
						drawGames(scrollImageGC[0]);
						tempPoint = draggedOverPlay(e.x,e.y);
						playPoint = new Point(tempPoint.x,tempPoint.y);
						highlightPlay = true;
						refreshGames = true;
					}
				}
				String aName = inPlay(e.x,e.y);
				if (aName != null) {
					lobbyChat.typeThis(new String(aName + ", "));
				}
//				int aSess = inPlaySess(e.x,e.y) + 1;
//				if ((userSessLocations[0] == aSess) && (movingToSess == -1) && (aName != null)) {
//					lobbyChat.typeThis(new String(aName + ", "));
//				} else if (((userSessLocations[0] != aSess) || (movingToSess != -1)) && (aName != null)) {
//					lobbyChat.postMessage(998,"badhint",new String("Can't talk to "+aName+" unless you're in the same session."));
//				}
				aName = inLobbyIcon(e.x,e.y);
				if (aName != null) {
					lobbyChat.typeThis(new String(aName + ", "));
				}
//				if ((userSessLocations[0] == 0) && (movingToSess == -1) && (aName != null)) {
//					lobbyChat.typeThis(new String(aName + ", "));
//				} else if (((userSessLocations[0] != 0) || (movingToSess != -1)) && (aName != null)) {
//					lobbyChat.postMessage(998,"badhint",new String("Can't talk to "+aName+" unless you're in the common lobby too."));
//				}
			} else {
				if ((lobbyState == ACTIVE) && (inMyToken(e.x,e.y) || (inSpectate(e.x,e.y) != -1))) {
					if (launchSpectator != -1) {
						lobbyChat.postMessage(998,"badhint","Spectator still launching... please wait.");
					} else if (launchingGame) {
						lobbyChat.postMessage(998,"badhint","Session still launching... please wait.");
					}
				}
			}
		} else if (e.id == Event.MOUSE_DRAG) {
			for (int scrollAreaIndex=0;scrollAreaIndex<2;scrollAreaIndex++) {
				if (scrolling[scrollAreaIndex]) {
					setThumbOffset(scrollAreaIndex,saveThumb+e.y-saveY);
					if (scrollAreaIndex == 0) {
						refreshGames = true;
					} else {
						refreshUsers = true;
					}
				}
			}
			currentX = e.x;
			currentY = e.y;
			if (draggingMe) {
				tempPoint = draggedOverPlay(e.x+origX-startX,e.y+origY-startY);
				if ((tempPoint.x != -1) && (tempPoint.y != -1) && (gamePlayers[tempPoint.x][tempPoint.y] == -1)) {
					if (!highlightPlay || (playPoint.x != tempPoint.x) || (playPoint.y != tempPoint.y)) {
						highlightPlay = true;
						playPoint = new Point(tempPoint.x,tempPoint.y);
						refreshGames = true;
					}
					playPoint = new Point(tempPoint.x,tempPoint.y);
					highlightPlay = true;
				} else {
					if (highlightPlay) {
						highlightPlay = false;
						refreshGames = true;
					}
				}
				if (draggedOverMyPlay(e.x+origX-startX,e.y+origY-startY)) {
					highlightMyPlay = true;
				} else {
					if (highlightMyPlay) {
						highlightMyPlay = false;
					}
				}
			}
		} else if (e.id == Event.MOUSE_UP) {
			smallRepeatFlag = false;
			bigRepeatFlag = false;
			if (draggingMe && highlightPlay) {
				movingToSess = playPoint.x;
				movingToPlay = playPoint.y;
				gamePlayers[movingToSess][movingToPlay] = userIDs[0];
				gamePlayerNames[movingToSess][movingToPlay] = new String(userNames[0]);
				drawGames(scrollImageGC[0]);
				refreshGames = true;
				tempSB = new StringBuffer("210 imin "+movingToSess+" "+movingToPlay);
				if (!myNetConn.sendMessage(tempSB)) {
					System.out.println("NF 9");
					lobbyChat.setUser(0,0,"Lobby");
					lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
					lobbyState = IDLE;
				}
			} else if (draggingMe) {
				tempSB = new StringBuffer("210 imin 0 0");
				if (!myNetConn.sendMessage(tempSB)) {
					System.out.println("NF 10");
					lobbyChat.setUser(0,0,"Lobby");
					lobbyChat.postMessage(0,"chat","NETWORK FAILURE!!!  Restart applet...");
					lobbyState = IDLE;
				}
				userSessLocations[0] = 0;
				userPlayLocations[0] = 0;
				draggingMe = false;
				drawOtherUsers(scrollImageGC[1]);
				refreshUsers = true;
			}
			draggingMe = false;
			highlightPlay = false;
			highlightMyPlay = false;
			for (int scrollAreaIndex=0;scrollAreaIndex<2;scrollAreaIndex++) {
				scrolling[scrollAreaIndex] = false;
			}
		}
		repaint();
		return(super.handleEvent(e));
	}

	/*********************************************************************/
	/******************** Begin ScrollArea Definition ********************/
	/*********************************************************************/

	int numberOfScrollAreas;
	Image scrollAreaImage[] = {};
	Graphics scrollAreaImageGC[] = {};
	Rectangle scrollRect[] = {};
	Rectangle scrollbarRect[] = {};
	Polygon upTriangle[] = {};
	Polygon downTriangle[] = {};
	int maxImageOffset[] = {};
	int minImageOffset[] = {};
	int currentImageOffset[] = {};
	int maxThumbOffset[] = {};
	int minThumbOffset[] = {};
	int currentThumbOffset[] = {};
	boolean scrolling[] = {};
	Image scrollImage[] = {};
	int imageHeight[] = {};
	Graphics scrollImageGC[] = {};
	int saveThumb, saveY;
	boolean rightScroll[] = {};
	int smallJumpValue[] = {};
	int bigJumpValue[] = {};

	public void initScrollAreas(int inNum) {

		numberOfScrollAreas = inNum;
		scrollAreaImage = new Image[numberOfScrollAreas];
		scrollAreaImageGC = new Graphics[numberOfScrollAreas];
		scrollRect = new Rectangle[numberOfScrollAreas];
		scrollbarRect = new Rectangle[numberOfScrollAreas];
		upTriangle = new Polygon[numberOfScrollAreas];
		downTriangle = new Polygon[numberOfScrollAreas];
		maxImageOffset = new int[numberOfScrollAreas];
		minImageOffset = new int[numberOfScrollAreas];
		currentImageOffset = new int[numberOfScrollAreas];
		maxThumbOffset = new int[numberOfScrollAreas];
		minThumbOffset = new int[numberOfScrollAreas];
		currentThumbOffset = new int[numberOfScrollAreas];
		scrolling = new boolean[numberOfScrollAreas];
		scrollImage = new Image[numberOfScrollAreas];
		imageHeight = new int[numberOfScrollAreas];
		scrollImageGC = new Graphics[numberOfScrollAreas];
		rightScroll = new boolean[numberOfScrollAreas];
		smallJumpValue = new int[numberOfScrollAreas];
		bigJumpValue = new int[numberOfScrollAreas];
	}

	public void initScrollArea(int inSANum, int inX, int inY, int inWidth, int inHeight, int inSBWidth, int inIHeight, boolean onRight) {

		scrollRect[inSANum] = new Rectangle(inX,inY,inWidth,inHeight);
		upTriangle[inSANum] = new Polygon();
		downTriangle[inSANum] = new Polygon();
		if (onRight) {
			scrollbarRect[inSANum] = new Rectangle(inWidth-inSBWidth,0,inSBWidth,inHeight);
			upTriangle[inSANum].addPoint(inWidth-inSBWidth+5,inSBWidth-5);
			upTriangle[inSANum].addPoint(inWidth-inSBWidth/2,5);
			upTriangle[inSANum].addPoint(inWidth-5,inSBWidth-5);
			upTriangle[inSANum].addPoint(inWidth-inSBWidth+5,inSBWidth-5);
			downTriangle[inSANum].addPoint(inWidth-inSBWidth+5,inHeight-inSBWidth+5);
			downTriangle[inSANum].addPoint(inWidth-inSBWidth/2,inHeight-5);
			downTriangle[inSANum].addPoint(inWidth-5,inHeight-inSBWidth+5);
			downTriangle[inSANum].addPoint(inWidth-inSBWidth+5,inHeight-inSBWidth+5);
		} else {
			scrollbarRect[inSANum] = new Rectangle(0,0,inSBWidth,inHeight);
			upTriangle[inSANum].addPoint(5,inSBWidth-5);
			upTriangle[inSANum].addPoint(inSBWidth/2,5);
			upTriangle[inSANum].addPoint(inSBWidth-5,inSBWidth-5);
			upTriangle[inSANum].addPoint(5,inSBWidth-5);
			downTriangle[inSANum].addPoint(5,inHeight-inSBWidth+5);
			downTriangle[inSANum].addPoint(inSBWidth/2,inHeight-5);
			downTriangle[inSANum].addPoint(inSBWidth-5,inHeight-inSBWidth+5);
			downTriangle[inSANum].addPoint(5,inHeight-inSBWidth+5);
		}
		minImageOffset[inSANum] = -inIHeight+inHeight;
		maxImageOffset[inSANum] = 0;
		currentImageOffset[inSANum] = 0;
		minThumbOffset[inSANum] = inSBWidth;
		maxThumbOffset[inSANum] = inHeight-2*inSBWidth+2;
		currentThumbOffset[inSANum] = inSBWidth;
		scrolling[inSANum] = false;
		imageHeight[inSANum] = inIHeight;
		scrollImage[inSANum] = createImage(inWidth-inSBWidth,inIHeight);
		scrollImageGC[inSANum] = scrollImage[inSANum].getGraphics();
		rightScroll[inSANum] = onRight;
		smallJumpValue[inSANum] = 2;
		bigJumpValue[inSANum] = 20;
	}

	public boolean inScrollAreaRect(int inSANum, int inX, int inY) {

		if ((inX > scrollRect[inSANum].x) && (inX < (scrollRect[inSANum].x+scrollRect[inSANum].width)) && (inY > scrollRect[inSANum].y) && (inY < (scrollRect[inSANum].y+scrollRect[inSANum].height))) {
			return(true);
		}
		return(false);
	}

	public boolean inScrollAreaBarRect(int inSANum, int inX, int inY) {

		if (((inX-scrollRect[inSANum].x) > scrollbarRect[inSANum].x) && ((inX-scrollRect[inSANum].x) < (scrollbarRect[inSANum].x+scrollbarRect[inSANum].width)) && ((inY-scrollRect[inSANum].y) > scrollbarRect[inSANum].y) && ((inY-scrollRect[inSANum].y) < (scrollbarRect[inSANum].y+scrollbarRect[inSANum].height))) {
			return(true);
		}
		return(false);
	}

	public boolean inScrollAreaBarThumb(int inSANum, int inX, int inY) {

		if (((inY-scrollRect[inSANum].y) > (scrollbarRect[inSANum].y+currentThumbOffset[inSANum])) && ((inY-scrollRect[inSANum].y) < (scrollbarRect[inSANum].y+currentThumbOffset[inSANum]+scrollbarRect[inSANum].width))) {
			if (((inX-scrollRect[inSANum].x) > scrollbarRect[inSANum].x) && ((inX-scrollRect[inSANum].x) < (scrollbarRect[inSANum].x+scrollbarRect[inSANum].width))) {
				return(true);
			}
		}
		return(false);
	}

	public boolean inScrollAreaBarUp(int inSANum, int inX, int inY) {

		if (((inY-scrollRect[inSANum].y) > 0) && ((inY-scrollRect[inSANum].y) < (scrollbarRect[inSANum].y+scrollbarRect[inSANum].width))) {
			if (((inX-scrollRect[inSANum].x) > scrollbarRect[inSANum].x) && ((inX-scrollRect[inSANum].x) < (scrollbarRect[inSANum].x+scrollbarRect[inSANum].width))) {
				return(true);
			}
		}
		return(false);
	}

	public boolean inScrollAreaBarJumpUp(int inSANum, int inX, int inY) {

		if (((inY-scrollRect[inSANum].y) > (scrollbarRect[inSANum].y+scrollbarRect[inSANum].width)) && ((inY-scrollRect[inSANum].y) < (scrollbarRect[inSANum].y+currentThumbOffset[inSANum]))) {
			if (((inX-scrollRect[inSANum].x) > scrollbarRect[inSANum].x) && ((inX-scrollRect[inSANum].x) < (scrollbarRect[inSANum].x+scrollbarRect[inSANum].width))) {
				return(true);
			}
		}
		return(false);
	}

	public boolean inScrollAreaBarDown(int inSANum, int inX, int inY) {

		if (((inY-scrollRect[inSANum].y) > (scrollRect[inSANum].height-scrollbarRect[inSANum].width)) && ((inY-scrollRect[inSANum].y) < scrollRect[inSANum].height)) {
			if (((inX-scrollRect[inSANum].x) > scrollbarRect[inSANum].x) && ((inX-scrollRect[inSANum].x) < (scrollbarRect[inSANum].x+scrollbarRect[inSANum].width))) {
				return(true);
			}
		}
		return(false);
	}

	public boolean inScrollAreaBarJumpDown(int inSANum, int inX, int inY) {

		if (((inY-scrollRect[inSANum].y) > (scrollbarRect[inSANum].y+currentThumbOffset[inSANum]+scrollbarRect[inSANum].width)) && ((inY-scrollRect[inSANum].y) < (scrollRect[inSANum].height-scrollbarRect[inSANum].width))) {
			if (((inX-scrollRect[inSANum].x) > scrollbarRect[inSANum].x) && ((inX-scrollRect[inSANum].x) < (scrollbarRect[inSANum].x+scrollbarRect[inSANum].width))) {
				return(true);
			}
		}
		return(false);
	}

	public void modifyThumbOffset(int inSANum, int delta) {
	
		currentThumbOffset[inSANum] += delta;
		if (currentThumbOffset[inSANum] < minThumbOffset[inSANum]) {
			currentThumbOffset[inSANum] = minThumbOffset[inSANum];
		} else if (currentThumbOffset[inSANum] > maxThumbOffset[inSANum]) {
			currentThumbOffset[inSANum] = maxThumbOffset[inSANum];
		}
		setImageOffset(inSANum,(currentThumbOffset[inSANum]-minThumbOffset[inSANum])*(minImageOffset[inSANum]-maxImageOffset[inSANum])/(maxThumbOffset[inSANum]-minThumbOffset[inSANum]));
	}

	public void setSmallJumpValue(int inSANum, int inVal) {

		smallJumpValue[inSANum] = inVal;
	}

	public void setBigJumpValue(int inSANum, int inVal) {

		bigJumpValue[inSANum] = inVal;
	}

	public void smallJump(int inSANum, boolean up) {

		if (up) {
			setImageOffset(inSANum,currentImageOffset[inSANum]+smallJumpValue[inSANum]);
		} else {
			setImageOffset(inSANum,currentImageOffset[inSANum]-smallJumpValue[inSANum]);
		}
		computeThumbOffset(inSANum);
	}

	public void bigJump(int inSANum, boolean up) {

		if (up) {
			setImageOffset(inSANum,currentImageOffset[inSANum]+bigJumpValue[inSANum]);
		} else {
			setImageOffset(inSANum,currentImageOffset[inSANum]-bigJumpValue[inSANum]);
		}
		computeThumbOffset(inSANum);
	}

	public void computeThumbOffset(int inSANum) {

		currentThumbOffset[inSANum] = minThumbOffset[inSANum] + (maxImageOffset[inSANum]-currentImageOffset[inSANum])*(maxThumbOffset[inSANum]-minThumbOffset[inSANum])/(maxImageOffset[inSANum]-minImageOffset[inSANum]);
		if (currentThumbOffset[inSANum] < minThumbOffset[inSANum]) {
			currentThumbOffset[inSANum] = minThumbOffset[inSANum];
		} else if (currentThumbOffset[inSANum] > maxThumbOffset[inSANum]) {
			currentThumbOffset[inSANum] = maxThumbOffset[inSANum];
		}
	}

	public void setThumbOffset(int inSANum, int absolute) {
	
		currentThumbOffset[inSANum] = absolute;
		if (currentThumbOffset[inSANum] < minThumbOffset[inSANum]) {
			currentThumbOffset[inSANum] = minThumbOffset[inSANum];
		} else if (currentThumbOffset[inSANum] > maxThumbOffset[inSANum]) {
			currentThumbOffset[inSANum] = maxThumbOffset[inSANum];
		}
		setImageOffset(inSANum,(currentThumbOffset[inSANum]-minThumbOffset[inSANum])*(minImageOffset[inSANum]-maxImageOffset[inSANum])/(maxThumbOffset[inSANum]-minThumbOffset[inSANum]));
	}

	public void setImageOffset(int inSANum, int absolute) {
	
		currentImageOffset[inSANum] = absolute;
		if (currentImageOffset[inSANum] < minImageOffset[inSANum]) {
			currentImageOffset[inSANum] = minImageOffset[inSANum];
		} else if (currentImageOffset[inSANum] > maxImageOffset[inSANum]) {
			currentImageOffset[inSANum] = maxImageOffset[inSANum];
		}
	}

	public synchronized void myDraw3DRect(Graphics g, int inX, int inY, int inW, int inH) {

		g.setColor(Color.lightGray);
		g.fillRect(inX,inY,inW,inH);
		g.setColor(Color.black);
		g.drawRect(inX,inY,inW,inH);
		g.setColor(Color.gray);
		g.drawLine(inX+1,inY+inH-1,inX+inW-1,inY+inH-1);
		g.drawLine(inX+2,inY+inH-2,inX+inW-1,inY+inH-2);
		g.drawLine(inX+inW-1,inY+1,inX+inW-1,inY+inH-1);
		g.drawLine(inX+inW-2,inY+2,inX+inW-2,inY+inH-1);
		g.setColor(Color.white);
		g.drawLine(inX+1,inY+inH-1,inX+1,inY+1);
		g.drawLine(inX+2,inY+inH-2,inX+2,inY+2);
		g.drawLine(inX+1,inY+1,inX+inW-1,inY+1);
		g.drawLine(inX+1,inY+2,inX+inW-2,inY+2);
	}

	public synchronized void drawScrollArea(int inSANum) {

		Graphics tempGC = scrollAreaImageGC[inSANum];
		if (rightScroll[inSANum]) {
			tempGC.drawImage(scrollImage[inSANum],0,currentImageOffset[inSANum],this);
		} else {
			tempGC.drawImage(scrollImage[inSANum],scrollbarRect[inSANum].width,currentImageOffset[inSANum],this);
		}
		Rectangle tempRect = scrollbarRect[inSANum];
		tempGC.setColor(Color.lightGray);
		tempGC.fillRect(tempRect.x,tempRect.y,tempRect.width,tempRect.height);
		tempGC.setColor(Color.black);
		tempGC.drawRect(tempRect.x,tempRect.y,tempRect.width-1,tempRect.height-1);
		myDraw3DRect(tempGC,tempRect.x,tempRect.y,tempRect.width-1,tempRect.width-1);
		myDraw3DRect(tempGC,tempRect.x,tempRect.y+tempRect.height-tempRect.width,tempRect.width-1,tempRect.width-1);
		myDraw3DRect(tempGC,tempRect.x+1,currentThumbOffset[inSANum],tempRect.width-3,tempRect.width-3);
		tempGC.setColor(Color.black);
		tempGC.fillPolygon(upTriangle[inSANum]);
		tempGC.fillPolygon(downTriangle[inSANum]);
		tempGC.drawRect(0,0,scrollRect[inSANum].width-1,scrollRect[inSANum].height-1);
	}

	/*******************************************************************/
	/******************** End ScrollArea Definition ********************/
	/*******************************************************************/
}

class loadThread extends Thread {

	String className;
	Lobby theParent;
	Class myClass;
	extendedApplet myApplet;
	Thread myThread = null;

	public void setLoadParameters(String inStr, Lobby inParent) {

		className = inStr;
		theParent = inParent;
	}

	public void start() {

		if (myThread == null) {
			myThread = new Thread(this);
			myThread.start();
		}
	}

	public void run() {

		try {
			myClass = Class.forName(className);
			myApplet = (extendedApplet)myClass.newInstance();
			theParent.loadSucceeded = true;
		} catch (Exception e) {
			System.out.println("EXCEPTION while trying to load "+className+": "+e);
			theParent.loadFailed = true;
		}
	}
}