import java.awt.*;
import java.applet.*;
import java.util.StringTokenizer;

public class chatApplet extends Applet {

	private final String InitMessage = "Type your message here.";
	private int chatSoundNumber = -1;
	private int goodHintSoundNumber = -1;
	private int badHintSoundNumber = -1;
	private Applet theRoot = null;
	private final int MAXPEOPLE = 20;
	private final int HEIGHT = 100;
	private final int MAXITEMS = 50;
	private final String MESSAGEPROMPT = "Message:";
	private int MINTEXTHEIGHT = 15;
	
	private boolean doSound = true;
	private int peopleNums[] = new int[MAXPEOPLE];
	private String peopleNames[] = new String[MAXPEOPLE];

	private TextArea messages;
	private TextField inputField;
	private Label messageLabel;
	private Button sendButton;

	private netConn theConn = null;
	private Graphics thisGC = null;
	private Checkbox seePlayers, seeSpectators, seeHints;
	private boolean ownerIsPlayer = false;
	private String nextElement;
	private String currentStr;
	private StringTokenizer myST;
	private int theWidth;
	private boolean isSpectator = true;
	private final String Spaces = "     ";
	private final int MAXSTRINGLENGTH = 200;
	private boolean hideUserCheckboxes = false;
	private boolean hideHintCheckbox = false;
	private boolean hideInputField = false;
	private Font basicFont = new Font("Helvetica",Font.PLAIN,12);
	private boolean isUnix = false;

	private FontMetrics myFM = null;

	public chatApplet() {
	
		try {
			String osName = System.getProperty("os.name");
			System.out.println("Chat - Operating system is: "+osName);
			if (osName != null) {
				osName = osName.toLowerCase();
				if ((osName.indexOf("solaris") != -1) || (osName.indexOf("sunos") != -1) || (osName.indexOf("x") != -1)) {
					isUnix = true;
				}
			}
		} catch (Exception e) {
			System.out.println("Exception getting OS name: "+e);
		}
		if (isUnix) {
			MINTEXTHEIGHT = 30;
		}

		setLayout(null);
		for (int i=0;i<MAXPEOPLE;i++) {
			peopleNums[i] = -1;
			peopleNames[i] = null;
		}
		seePlayers = new Checkbox("see player comments");
		seePlayers.setFont(basicFont);
		seePlayers.setState(true);
		add(seePlayers);
		seeSpectators = new Checkbox("see spectator comments");
		seeSpectators.setFont(basicFont);
		seeSpectators.setState(true);
		add(seeSpectators);
		seeHints = new Checkbox("see hints");
		seeHints.setFont(basicFont);
		seeHints.setState(true);
		add(seeHints);
		messages = new TextArea();
		messages.setFont(basicFont);
		messages.setEditable(false);
		add(messages);
		inputField = new TextField("Connection uninitialized.");
		inputField.setFont(basicFont);
		inputField.setEditable(false);
		add(inputField);
		messageLabel = new Label(MESSAGEPROMPT);
		messageLabel.setFont(new Font("Helvetica",Font.PLAIN,12)); /* basicFont */
		add(messageLabel);
		sendButton = new Button("Send");
		add(sendButton);
	}

	public void doReshape(int inX, int inY, int inWidth, int inHeight) {

		reshape(inX,inY,inWidth,inHeight);
		setLayout(null);
		thisGC = this.getGraphics();
		thisGC.setFont(new Font("helvetica",Font.PLAIN,12));
		myFM = thisGC.getFontMetrics();
		theWidth = inWidth;
		int fontHeight = myFM.getHeight();
		if (fontHeight < MINTEXTHEIGHT) {
			fontHeight = MINTEXTHEIGHT;
		}
		if (hideUserCheckboxes && hideHintCheckbox) {
			if (hideInputField) {
				messages.reshape(0,0,theWidth,inHeight - 3);
			} else {
				messages.reshape(0,0,theWidth,inHeight - fontHeight - 9);
				messageLabel.reshape(2,inHeight - fontHeight - 7,myFM.stringWidth(MESSAGEPROMPT)+12,fontHeight + 6);
				sendButton.reshape(inWidth - 50,inHeight - fontHeight - 7,50,fontHeight + 6);
				inputField.reshape(myFM.stringWidth(MESSAGEPROMPT)+15,inHeight - fontHeight - 7,inWidth-54-myFM.stringWidth(MESSAGEPROMPT)-15,fontHeight + 6);
			}
		} else if (hideHintCheckbox) {
			if (hideInputField) {
				seePlayers.reshape(0,0,theWidth/3 - 4,fontHeight);
				seeSpectators.reshape(theWidth/3,0,theWidth/3 - 4,fontHeight);
				messages.reshape(0,fontHeight,theWidth,inHeight - fontHeight - 3);
			} else {
				seePlayers.reshape(0,0,theWidth/3 - 4,fontHeight);
				seeSpectators.reshape(theWidth/3,0,theWidth/3 - 4,fontHeight);
				messages.reshape(0,fontHeight,theWidth,inHeight - 2*fontHeight - 9);
				messageLabel.reshape(2,inHeight - fontHeight - 7,myFM.stringWidth(MESSAGEPROMPT)+12,fontHeight + 6);
				sendButton.reshape(inWidth - 50,inHeight - fontHeight - 7,50,fontHeight + 6);
				inputField.reshape(myFM.stringWidth(MESSAGEPROMPT)+15,inHeight - fontHeight - 7,inWidth-54-myFM.stringWidth(MESSAGEPROMPT)-15,fontHeight + 6);
			}
		} else if (hideUserCheckboxes) {
			if (hideInputField) {
				seeHints.reshape(0,0,theWidth/3 - 4,fontHeight);
				messages.reshape(0,fontHeight,theWidth,inHeight - fontHeight - 3);
			} else {
				seeHints.reshape(0,0,theWidth/3 - 4,fontHeight);
				messages.reshape(0,fontHeight,theWidth,inHeight - 2*fontHeight - 9);
				messageLabel.reshape(2,inHeight - fontHeight - 7,myFM.stringWidth(MESSAGEPROMPT)+12,fontHeight + 6);
				sendButton.reshape(inWidth - 50,inHeight - fontHeight - 7,50,fontHeight + 6);
				inputField.reshape(myFM.stringWidth(MESSAGEPROMPT)+15,inHeight - fontHeight - 7,inWidth-54-myFM.stringWidth(MESSAGEPROMPT)-15,fontHeight + 6);
			}
		} else {
			if (hideInputField) {
				seePlayers.reshape(0,0,theWidth/3 - 4,fontHeight);
				seeSpectators.reshape(theWidth/3,0,theWidth/3 - 4,fontHeight);
				seeHints.reshape(2*theWidth/3,0,theWidth/3 - 4,fontHeight);
				messages.reshape(0,fontHeight,theWidth,inHeight - fontHeight - 3);
			} else {
				seePlayers.reshape(0,0,theWidth/3 - 4,fontHeight);
				seeSpectators.reshape(theWidth/3,0,theWidth/3 - 4,fontHeight);
				seeHints.reshape(2*theWidth/3,0,theWidth/3 - 4,fontHeight);
				messages.reshape(0,fontHeight,theWidth,inHeight - 2*fontHeight - 9);
				messageLabel.reshape(2,inHeight - fontHeight - 7,myFM.stringWidth(MESSAGEPROMPT)+12,fontHeight + 6);
				sendButton.reshape(inWidth - 50,inHeight - fontHeight - 7,50,fontHeight + 6);
				inputField.reshape(myFM.stringWidth(MESSAGEPROMPT)+15,inHeight - fontHeight - 7,inWidth-54-myFM.stringWidth(MESSAGEPROMPT)-15,fontHeight + 6);
			}
		}
		repaint();
	}

	public void beSilent(boolean inVal) {
	
		doSound = !inVal;
	}

	public void setHideUserCheckboxes(boolean inVal) {

		hideUserCheckboxes = inVal;
	}

	public void setHideHintCheckbox(boolean inVal) {

		hideHintCheckbox = inVal;
	}

	public void setHideInputField(boolean inVal) {

		hideInputField = inVal;
	}

	public void setRoot(Applet inRoot) {

		theRoot = inRoot;
		if (theRoot != null) {
			chatSoundNumber = ((RootApplet)theRoot).loadASoundClip("bfms/chat.au");
			goodHintSoundNumber = ((RootApplet)theRoot).loadASoundClip("bfms/goodhint.au");
			badHintSoundNumber = ((RootApplet)theRoot).loadASoundClip("bfms/badhint.au");
		}
	}

	public synchronized void setConn(netConn inConn) {

		theConn = inConn;
		inputField.setText(InitMessage);
		inputField.setEditable(true);
	}

	public synchronized void removeUser(int inNum) {

		int index = 0;
		while ((index < MAXPEOPLE) && (peopleNums[index] != inNum)) {
			index++;
		}
		if (index == MAXPEOPLE) {
			return;
		}
		peopleNums[index] = -1;
		peopleNames[index] = null;
	}

	public synchronized void setUser(int inNum, String inName) {

		int index = 0;
		while ((index < MAXPEOPLE) && (peopleNums[index] != -1) && (peopleNums[index] != inNum)) {
			index++;
		}
		if (index == MAXPEOPLE) {
			return;
		}
		peopleNums[index] = inNum;
		peopleNames[index] = inName;
	}

	public synchronized void setUser(int index, int inNum, String inName) {

		if ((index > MAXPEOPLE) || (index < 0)) {
			return;
		}
		peopleNums[index] = inNum;
		peopleNames[index] = inName;
	}

	public synchronized boolean knowsAbout(int inNum) {

		int index = 0;
		while ((index < MAXPEOPLE) && (peopleNums[index] != inNum)) {
			index++;
		}
		if (index == MAXPEOPLE) {
			return(false);
		}
		return(true);
	}

	public synchronized void setSpectator(boolean inState) {

		isSpectator = inState;
	}

	public synchronized void addAMessage(String inStr) {

		nextElement = null;
		currentStr = null;
		int useWidth = theWidth - 15;
		if (useWidth < 400) {
			useWidth = 400;
		}
		myST = new StringTokenizer(inStr);
		while (myST.hasMoreElements()) {
			nextElement = myST.nextToken();
			if (myFM.stringWidth(currentStr+" "+nextElement) < (useWidth - 10)) {
				if (currentStr != null) {
					currentStr = new String(currentStr+" "+nextElement);
				} else {
					currentStr = new String(nextElement);
				}
			} else {
				if (currentStr != null) {
					messages.appendText(currentStr+"\n");
				}
				currentStr = new String(Spaces+nextElement);
			}
		}
		if (currentStr != null) {
			messages.appendText(currentStr+"\n");
		}
	}

	public synchronized void postMessage(int userNum, String command, String theMessage) {

		int i = 0;
		while ((i < MAXPEOPLE) && (peopleNums[i] != userNum)) {
			i++;
		}
		if (i == MAXPEOPLE) {
			return;
		}
		if (command.equals("pchat")) {
			if (!seePlayers.getState()) {
				return;
			}
			if (doSound) {
				((RootApplet)theRoot).playASoundClip(chatSoundNumber);
			}
		}
		if (command.equals("schat")) {
			if (!seeSpectators.getState()) {
				return;
			}
			if (doSound) {
				((RootApplet)theRoot).playASoundClip(chatSoundNumber);
			}
		}
		if (command.equals("chat")) {
			if (doSound) {
				((RootApplet)theRoot).playASoundClip(chatSoundNumber);
			}
		}
		if (command.equals("goodhint")) {
			if (doSound) {
				((RootApplet)theRoot).playASoundClip(goodHintSoundNumber);
			}
			if (!seeHints.getState()) {
				return;
			}
		}
		if (command.equals("badhint")) {
			if (doSound) {
				((RootApplet)theRoot).playASoundClip(badHintSoundNumber);
			}
			if (!seeHints.getState()) {
				return;
			}
		}
		if (peopleNames[i] != null) {
			addAMessage(new String(peopleNames[i]+": "+theMessage));
		} else {
			addAMessage(new String("Spectator: "+theMessage));
		}
	}

	public void typeThis(String inStr) {

		if ((inputField.getText()).equals(InitMessage)) {
			inputField.setText(inStr);
		} else {
			inputField.setText(new String(inputField.getText() + " " + inStr));
		}
	}

	public boolean action(Event e, Object target) {
	
		if ((e.target == inputField) || (e.target == sendButton)) {
			String xStr = inputField.getText() + ".";
			if (xStr.length() > 1) {
				if (theConn != null) {
					if (isSpectator) {
						theConn.sendMessage(new StringBuffer(new String("210 schat "+xStr.substring(0,Math.min(MAXSTRINGLENGTH,xStr.length()-1)))));
					} else {
						theConn.sendMessage(new StringBuffer(new String("210 pchat "+xStr.substring(0,Math.min(MAXSTRINGLENGTH,xStr.length()-1)))));
					}
				}
				postMessage(peopleNums[0],"chat",xStr.substring(0,Math.min(MAXSTRINGLENGTH,xStr.length()-1)));
			}
			inputField.setText("");
		}
		if (this.getParent() instanceof extendedApplet) {
			((extendedApplet)this.getParent()).doTouch();
		}
		repaint();
		return(true);
	}

	public boolean handleEvent(Event e) {

		if (e.target == inputField) {
			if ((inputField.getText()).length() > MAXSTRINGLENGTH) {
				int sStart = inputField.getSelectionStart();
				int sEnd = inputField.getSelectionEnd();
				inputField.setText((inputField.getText()).substring(0,MAXSTRINGLENGTH));
				if ((sStart > MAXSTRINGLENGTH) || (sStart > MAXSTRINGLENGTH)) {
					inputField.select(MAXSTRINGLENGTH,MAXSTRINGLENGTH);
				} else {
					inputField.select(sStart,sEnd);
				}
			}
		}
		return(super.handleEvent(e));
	}
}