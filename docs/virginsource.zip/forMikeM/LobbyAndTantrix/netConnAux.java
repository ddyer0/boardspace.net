import java.net.*;
import java.io.*;

public class netConnAux extends Thread {

	final int LongLoopDelay = 2000;
	final int ShortLoopDelay = 200;
	netConn theNetConn = null;
	boolean makeConn = false;
	boolean successfulMake = false;
	Thread nCAThread = null;
	boolean exitFlag = false;

	public netConnAux(netConn inNetConn) {

		theNetConn = inNetConn;
	}

	public void start() {

		if (nCAThread == null) {
			nCAThread = new Thread(this);
			nCAThread.start();
		}
	}

	public void setExitFlag() {

		exitFlag = true;
	}

	public void requestConn() {

		makeConn = true;
	}

	public boolean requestPending() {

		return(makeConn);
	}

	public boolean didSuccessfulMake() {

		return(successfulMake);
	}

	public void doDelay(int inDelay) {

		try {
			sleep(inDelay);
		} catch (InterruptedException e) {
			System.out.println("Sleep interrupted.");
		}
	}

	public void run() {

		for (;;) {
			if (exitFlag) {
				break;
			}
			if (makeConn) {
				successfulMake = false;
				if (theNetConn != null) {
					if (theNetConn.mySocket == null) {
						successfulMake = theNetConn.makeConn();
					}
				}
				makeConn = false;
			}
			if (theNetConn != null) {
				if (theNetConn.mySocket == null) {
					doDelay(ShortLoopDelay);
				} else {
					doDelay(LongLoopDelay);
				}
			} else {
				doDelay(LongLoopDelay);
			}
		}
	}
}

