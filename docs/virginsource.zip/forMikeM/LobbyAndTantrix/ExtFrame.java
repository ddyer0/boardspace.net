import java.awt.*;
import java.applet.Applet;
import java.util.StringTokenizer;
import java.util.Date;

public class ExtFrame extends Frame implements Runnable {

	extendedApplet theParent = null;
	Thread myThread = null;
	int oldWidth = 0, oldHeight = 0, newWidth, newHeight;

	public ExtFrame(String inStr, extendedApplet inParent) {

		super(inStr);
		theParent = inParent;
		setLayout(null);
	}

	public void start() {

		if (myThread == null) {
			myThread = new Thread(this);
			myThread.start();
		}
		setLayout(null);
	}

	public boolean handleEvent(Event e) {

		if (e.id == Event.WINDOW_DESTROY) {
			theParent.killFrame(this);
		}
		return(super.handleEvent(e));
	}

	public void doDelay(int inDel) {

		try {
			Thread.sleep(inDel);
		} catch (InterruptedException e) {
			System.out.println("Sleep was interrupted.");
		}
	}

	public void run() {

		for (;;) {
			newWidth = size().width;
			newHeight = size().height;
			if ((newWidth != oldWidth) || (newHeight != oldHeight)) {
				oldWidth = newWidth;
				oldHeight = newHeight;
				for (int i=0;i<this.countComponents();i++) {
					this.getComponent(i).reshape(0,0,newWidth,newHeight);
				}
			}
			doDelay(500);
		}
	}
}