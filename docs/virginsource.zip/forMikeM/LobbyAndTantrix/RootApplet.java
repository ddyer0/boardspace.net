import java.awt.Frame;
import java.awt.Color;
import java.applet.Applet;
import java.applet.AudioClip;
import java.util.StringTokenizer;
import java.util.Date;

public class RootApplet extends Applet implements Runnable {

	final int DEFAULTWIDTH = 520;
	final int DEFAULTHEIGHT = 530;
	LFrame myLF = null;
	Lobby myL;
	Thread RAThread = null;
	final int MAXNUMBEROFSOUNDCLIPS = 20;
	AudioClip soundClips[] = new AudioClip[MAXNUMBEROFSOUNDCLIPS];
	int numberOfSoundClips = 0;
	int readPtr = 0, writePtr = 0;
	final int QUEUELENGTH = 20;
	int sounds[] = new int[QUEUELENGTH];

	public void init() {

	}

	public void start() {

		if (RAThread == null) {
			RAThread = new Thread(this);
			RAThread.start();
		}
	}

	public void doDelay(int inVal) {

		try {
			Thread.sleep(inVal);
		} catch (Exception e) {
			System.out.println("Root sleep interrupted.");
		}
	}

	public void run() {

		myL = new Lobby();
		myLF = new LFrame("Lobby  www.InterNetivity.com",this,myL);
		myLF.setBackground(Color.white);
		myLF.add(myL);
		myLF.show();
		myL.reshape(0,0,DEFAULTWIDTH,DEFAULTHEIGHT);
		myLF.resize(DEFAULTWIDTH+myLF.insets().left+myLF.insets().right,DEFAULTHEIGHT+myLF.insets().top+myLF.insets().bottom);
		myLF.setResizable(true);
		myL.init(this);
		myL.start();
		for (;;) {
			doDelay(200);
			while (readPtr != writePtr) {
				soundClips[sounds[readPtr]].play();
				readPtr++;
				if (readPtr == QUEUELENGTH) {
					readPtr = 0;
				}
				doDelay(25);
			}
		}
	}

	public int loadASoundClip(String clipName) {

		if (numberOfSoundClips == MAXNUMBEROFSOUNDCLIPS) {
			return(-1);
		}
		soundClips[numberOfSoundClips] = this.getAudioClip(this.getDocumentBase(),clipName);
		numberOfSoundClips++;
		return(numberOfSoundClips-1);
	}

	public void playASoundClip(int clipNum) {

		if ((writePtr == (readPtr-1)) || ((writePtr == (QUEUELENGTH - 1)) && (readPtr == 0))) {
			return;
		}
		if ((clipNum < numberOfSoundClips) && (clipNum >=0)) {
			sounds[writePtr] = clipNum;
			writePtr++;
			if (writePtr == QUEUELENGTH) {
				writePtr = 0;
			}
		}
	}

	public void setFrameName(String inStr) {

		myLF.setTitle(inStr);
	}

	public void killFrame(LFrame inLF) {

		if (inLF != myLF) {
			return;
		}
		myL.kill();
		myLF.dispose();
	}
}