import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.applet.*;

public class TantrixPuzzle extends extendedApplet implements Runnable {

	final String HOSTIP = "47.135.32.1";
	final int DEFAULTWIDTH = 520;
	final int DEFAULTHEIGHT = 540;
	int oldWidth = 0, oldHeight = 0, newWidth, newHeight;
	AudioClip dropTileSound = null;
	AudioClip gameOverSound = null;
	AudioClip turnChangeSound = null;
	boolean playTileDropSound = false;
	String doAutoRotateStr;
	boolean doAutoRotate = true;

	boolean signalEndGame = false;
	boolean atLeastOne = true;

	int waitForPlayers = 0;
	final int DEFAULTLOOPDELAY = 250;
	int mainLoopDelay = DEFAULTLOOPDELAY;
	final int Red = 0;
	final int Yellow = 1;
	final int Green = 2;
	final int Blue = 3;
	final int ShortArc = 0;
	final int LongArc = 1;
	final int Straight = 2;
	final int HalfWidth = 5;
	final Color LightGray = new Color(150,150,150);
	final Color myColours[] = {new Color(250,0,0),new Color(250,250,0),new Color(0,200,0),new Color(0,0,250)};
	final Color lightColours[] = {new Color(250,200,200),new Color(250,250,200),new Color(200,250,200),new Color(200,200,250)};
	final Color lightBlue = new Color(150,150,250);
	final double Root3 = 1.73205080756;
	final int MoveThreshold = 9;
	boolean initialized = false;
	boolean firstPass = true;
	boolean myMoveIsValid;
	int tilesLeft = 56;
	boolean drawingSelectiveColours = false;
	final int FontHeight = 12;
	boolean mouseDownFlag = false;
	boolean validBoardPosition, invalid_edges, sendHint = false;
	boolean freeTaken;

	TantrixPuzzle thisTantrix = null;
	ExtFrame myFrame = null;
	int windowWidth = DEFAULTWIDTH, windowHeight = DEFAULTHEIGHT;
	int boardExtentX, boardExtentY;
	final long HEARTBEATINTERVAL = 60000;
	long heartBeatTime = 0, currentTime, startSpectateTime;

	boolean spectator = false;
	boolean getStatePending = false;

	int gameVOffset = 202;

	int whoseTurn = -1;
	boolean exitFlag = false;

	String namePassedIn = null;

	boolean puzzle = false;
	chatApplet theChat = null;
	boolean dontPaint = true;
	String puzzleObject = null;
	int lastComputeScores = 0;
	long timeNow, lastTimeUpdate;
	long elapsedTimes[] = new long[4];
	final int TimeHeight = 20;
	boolean havePuzzleSolution = false;

	final int NumBandPoints = 35;

	final int MINCHATHEIGHT = 110;
	final int MAXCHATHEIGHT = 200;
	final int BARWIDTH = 72;
	final int MINTOTALWIDTH = 5*BARWIDTH+10;
	int totalWidth = DEFAULTWIDTH;
	final int barYOffset = 18;
//	BARHEIGHT = 9.5*PolyParam[unity][0] + barYOffset + 16 + BUTTHEIGHT + ZOOMHEIGHT + STARTHEIGHT;
	final int BARHEIGHT = 200 + barYOffset + 16 + 2*BARWIDTH/3 + BARWIDTH/3 + BARWIDTH/2;
	final int TimeYOffset = BARHEIGHT + 2;
	int gameHeight = BARHEIGHT;
	Polygon arrowPolygon;
	Polygon turnPolygon;
	int numberOtherPlayers = 0;
	final int STARTTOP = BARHEIGHT-BARWIDTH/2, STARTBOTTOM = BARHEIGHT, STARTLEFT = 0, STARTRIGHT = BARWIDTH;

	final int ZOOMBOTTOM = STARTTOP - 1;
	final int ZOOMHEIGHT = BARWIDTH/3;
	final int ZOOMTOP = ZOOMBOTTOM - ZOOMHEIGHT;
	final int SmallZLeft = 5;
	final int SmallZTop = ZOOMBOTTOM - 15;
	final int SmallZRight = SmallZLeft + 11;
	final int SmallZBottom = SmallZTop + 11;
	final int BigZLeft = BARWIDTH - 20;
	final int BigZTop = ZOOMBOTTOM - 17;
	final int BigZRight = BigZLeft + 15;
	final int BigZBottom = BigZTop + 15;

	final int BUTTSBOTTOM = ZOOMTOP - 1;
	final int BUTTSTOP = BUTTSBOTTOM - BARWIDTH/3;
	final int BUTTSLEFT[] = {0,BARWIDTH/3,2*BARWIDTH/3};
	final int BUTTSRIGHT[] = {BARWIDTH/3 - 1,2*BARWIDTH/3 - 1,BARWIDTH - 1};
	final int BUTTBOTTOM = BUTTSTOP - 1;
	final int BUTTTOP = BUTTBOTTOM - BARWIDTH/3;
	final int BUTTLEFT = 0;
	final int BUTTRIGHT = BARWIDTH - 1;
	int buttTops[] = {ZOOMTOP-2*BARWIDTH/3,ZOOMTOP-BARWIDTH/3,ZOOMTOP-BARWIDTH/3,ZOOMTOP-2*BARWIDTH/3};
	int buttBottoms[] = {ZOOMTOP-BARWIDTH/3,ZOOMTOP,ZOOMTOP,ZOOMTOP-BARWIDTH/3};
	int buttLefts[] = {BARWIDTH/2 + 1,BARWIDTH/2 + 1,0,0};
	int buttRights[] = {BARWIDTH - 1,BARWIDTH - 1,BARWIDTH/2,BARWIDTH/2};

	int firstTileX = -1, firstTileY = -1;
	int forcedTilesX[] = new int[57];
	int forcedTilesY[] = new int[57];
	boolean usedMoved[] = new boolean[57];
	int forcedTiles[] = new int[57];
	boolean showForced[] = new boolean[57];
	int numberForced = 0;

	final int IDLE = 0;
	final int UNCONNECTED = 1;
	final int CONNECTED = 2;
	final int NOTMYCHOICE = 3;
	final int MYCHOICE = 4;
	final int NOTMYTURN = 5;
	final int MYTURN = 6;
	final int SPECTATE = 7;
	final int PUZZLE = 8;

	final int bigNumber = 99999;

	int gameState = IDLE;

	Thread myThread = null;
	Image allFixed = null, theBoard, leftBar, rightBar, offScreen;
	Graphics allFixedGC = null, theBoardGC = null, leftBarGC = null, rightBarGC = null, offScreenGC = null;
	int playerIDs[] = {-1,-1,-1,-1};
	int playerColours[] = {-1,-1,-1,-1};
	boolean movedPiece[][] = new boolean[4][6];
	boolean forcedPiece[][] = new boolean[4][6];
	boolean refreshBoard = true, refreshBars = true, refreshMoving = false, refreshTimes = false;
	final int UnityScaleIndex = 1;
	int boardScaleIndex = UnityScaleIndex;
	double ScaleFactors[] = {0.8,1.0,1.6,2.0};
	final int PolyParams[][] = {{17,15,4,2,3},{21,18,6,1,2},{33,29,8,1,2}};		/* {41,35,10,1,1} */
	final double StraightScales[] = {0.92,0.95,0.95,0.96};
	final int NumBoardScaleIndices = 3;
	final int TopBoardScaleIndex = NumBoardScaleIndices - 1;
	int boardXOffset = BARWIDTH, boardYOffset = 0;
	Color holdColourMain, holdColourBack;
	int grabbedPiece = -1, touchedPiece = -1, touchedOrient = 0;
	boolean movingBoard = false;
	boolean translateMotion = false;
	double origX, origY;
	int startX, startY, endX, endY, origOrient, bOrigX, bOrigY;
	boolean running = false;
	String readString;
	String serverName = null;
	int serverPort;
	int sessionNum;
	StringBuffer tempSB;
	Choice colourChoice = null;
	String colourStrings[] = {"Red","Yellow","Green","Blue"};

	String tempString = null;
	boolean messageConsumed = true;

	int puzzleSize;
	String puzzleType;
	int puzzleWin = 1000;
	int puzzlePieces[] = new int[56];
	/* Puzzle params are:
	<param name=puzzle value=<puzzle_size>>
	<param name=pieces value="<puzzle_piece_1> <puzzle_piece_2> <puzzle_piece_3> ...">
	<param name=win value=<winning score>>
	<param name=object value="<string describing the goal of the puzzle>">
	Example:
	<param name=puzzle value=7>
	<param name=pieces value="18 23 15 21 25 22 28">
	<param name=win value=14>
	<param name=object value="Make a yellow loop using all 7 tiles.">
	*/

	Applet theRoot = null;
	String sessionPassword = null;

	Polygon rightTriangle, leftTriangle;
	Polygon tilePoly[] = new Polygon[NumBoardScaleIndices];
	Polygon smallArcPoly[][] = new Polygon[NumBoardScaleIndices][6];
	Polygon bigArcPoly[][] = new Polygon[NumBoardScaleIndices][6];
	Polygon straightPoly[][] = new Polygon[NumBoardScaleIndices][3];

	double cornerXs[] = new double[6];
	double cornerYs[] = new double[6];
	double sideCentreXs[] = new double[6];
	double sideCentreYs[] = new double[6];

	int tilePos[][] = new int[57][2];
	int tileOrientation[] = new int[57];
	int score[] = new int[4];
	int maxLoopScore, maxLineScore;
	boolean onBoard[] = new boolean[57];
	int scored[] = new int[57];
	boolean scoredFlags[][] = new boolean[57][4];

	boolean freePieces[] = new boolean[57];
	final int BoardDimX = 43, BoardDimY = 25;
	int board[][] = new int[BoardDimX][BoardDimY];
	int boardOrient[][] = new int [BoardDimX][BoardDimY];
	int minBoardXOffset = (int)(totalWidth - (BoardDimX+1) * PolyParams[boardScaleIndex][1]);
	int minBoardYOffset = (int)(BARHEIGHT - (3*BoardDimY+1) * PolyParams[boardScaleIndex][0] / 2.0);
	int puzzleCentreX = -1;
	int puzzleCentreY = -1;

	/* Here are the tile descriptions.  Don't use index 0, to match hardware numbers               */
	/* Descriptions are: {Colour, Type of Arc, and Orientation} for each of 3 arcs on each tile    */
	/* Vertices, edges, and bisectors are numbered as follows.  Orientations are given in terms of */
	/* the vertex or edge surrounded by an arc, or the starting edge for a bisector.               */
    /*                                                                                             */
    /*                 0                                                                           */
	/*             5  /|\  0                                                                       */
	/*              /  |  \                                                                        */
	/*          5 /    |  0 \ 1                                                                    */
	/*           |  \  |  /  |                                                                     */
	/*           |    \|/   1|                                                                     */
	/*         4 |-----*-----| 1                                                                   */
	/*           |    /|\    |                                                                     */
	/*           |  /  |  \2 |                                                                     */
	/*          4 \    |    / 2                                                                    */
	/*              \  |  /                                                                        */
	/*            3   \|/  2                                                                       */
    /*                 3                                                                           */


	int tiles[][] = {{0,0,0,0,0,0,0,0,0},
					{Red,ShortArc,3,Yellow,ShortArc,5,Green,ShortArc,1},	// 1
					{Red,ShortArc,1,Yellow,ShortArc,5,Green,ShortArc,3},	// 2
					{Red,ShortArc,3,Yellow,Straight,1,Green,ShortArc,0},	// 3
					{Red,ShortArc,3,Yellow,ShortArc,0,Green,Straight,1},	// 4
					{Red,Straight,1,Yellow,ShortArc,0,Green,ShortArc,3},	// 5
					{Red,LongArc,1,Yellow,Straight,1,Green,LongArc,4},		// 6
					{Red,LongArc,1,Green,Straight,1,Yellow,LongArc,4},		// 7
					{Green,LongArc,1,Red,Straight,1,Yellow,LongArc,4},		// 8
					{Green,LongArc,3,Red,LongArc,2,Yellow,ShortArc,0},		// 9
					{Red,LongArc,3,Green,LongArc,2,Yellow,ShortArc,0},		// 10
					{Yellow,LongArc,3,Red,LongArc,2,Green,ShortArc,0},		// 11
					{Red,LongArc,3,Yellow,LongArc,2,Green,ShortArc,0},		// 12
					{Red,ShortArc,0,Yellow,LongArc,3,Green,LongArc,2},		// 13
					{Red,ShortArc,0,Green,LongArc,3,Yellow,LongArc,2},		// 14

					{Yellow,ShortArc,5,Green,ShortArc,1,Blue,ShortArc,3},	// 15
					{Yellow,ShortArc,5,Green,ShortArc,3,Blue,ShortArc,1},	// 16
					{Yellow,Straight,1,Green,ShortArc,0,Blue,ShortArc,3},	// 17
					{Yellow,ShortArc,0,Green,Straight,1,Blue,ShortArc,3},	// 18
					{Yellow,ShortArc,0,Green,ShortArc,3,Blue,Straight,1},	// 19
					{Blue,LongArc,1,Yellow,Straight,1,Green,LongArc,4},		// 20
					{Blue,LongArc,1,Green,Straight,1,Yellow,LongArc,4},		// 21
					{Green,LongArc,1,Blue,Straight,1,Yellow,LongArc,4},		// 22
					{Yellow,ShortArc,0,Green,LongArc,3,Blue,LongArc,2},		// 23
					{Yellow,ShortArc,0,Blue,LongArc,3,Green,LongArc,2},		// 24
					{Yellow,LongArc,3,Green,ShortArc,0,Blue,LongArc,2},		// 25
					{Blue,LongArc,3,Yellow,LongArc,2,Green,ShortArc,0},		// 26
					{Yellow,LongArc,3,Green,LongArc,2,Blue,ShortArc,0},		// 27
					{Green,LongArc,3,Yellow,LongArc,2,Blue,ShortArc,0},		// 28

					{Red,ShortArc,1,Yellow,ShortArc,5,Blue,ShortArc,3},		// 29
					{Red,ShortArc,5,Yellow,ShortArc,1,Blue,ShortArc,3},		// 30
					{Red,ShortArc,0,Yellow,Straight,1,Blue,ShortArc,3},		// 31
					{Red,Straight,1,Yellow,ShortArc,0,Blue,ShortArc,3},		// 32
					{Red,ShortArc,3,Yellow,ShortArc,0,Blue,Straight,1},		// 33
					{Blue,LongArc,1,Yellow,Straight,1,Red,LongArc,4},		// 34
					{Blue,LongArc,1,Red,Straight,1,Yellow,LongArc,4},		// 35
					{Red,LongArc,1,Blue,Straight,1,Yellow,LongArc,4},		// 36
					{Red,LongArc,3,Yellow,ShortArc,0,Blue,LongArc,2},		// 37
					{Yellow,ShortArc,0,Blue,LongArc,3,Red,LongArc,2},		// 38
					{Red,ShortArc,0,Yellow,LongArc,3,Blue,LongArc,2},		// 39
					{Red,ShortArc,0,Blue,LongArc,3,Yellow,LongArc,2},		// 40
					{Yellow,LongArc,3,Blue,ShortArc,0,Red,LongArc,2},		// 41
					{Red,LongArc,3,Yellow,LongArc,2,Blue,ShortArc,0},		// 42

					{Red,ShortArc,1,Green,ShortArc,5,Blue,ShortArc,3},		// 43
					{Red,ShortArc,3,Green,ShortArc,5,Blue,ShortArc,1},		// 44
					{Red,ShortArc,0,Green,Straight,1,Blue,ShortArc,3},		// 45
					{Red,Straight,1,Green,ShortArc,0,Blue,ShortArc,3},		// 46
					{Red,ShortArc,3,Green,ShortArc,0,Blue,Straight,1},		// 47
					{Blue,LongArc,1,Green,Straight,1,Red,LongArc,4},		// 48
					{Blue,LongArc,1,Red,Straight,1,Green,LongArc,4},		// 49
					{Red,LongArc,1,Blue,Straight,1,Green,LongArc,4},		// 50
					{Red,LongArc,3,Green,ShortArc,0,Blue,LongArc,2},		// 51
					{Green,ShortArc,0,Blue,LongArc,3,Red,LongArc,2},		// 52
					{Red,ShortArc,0,Green,LongArc,3,Blue,LongArc,2},		// 53
					{Red,ShortArc,0,Blue,LongArc,3,Green,LongArc,2},		// 54
					{Green,LongArc,3,Blue,ShortArc,0,Red,LongArc,2},		// 55
					{Red,LongArc,3,Green,LongArc,2,Blue,ShortArc,0}};		// 56

	public void doTouch() {

	}

	public void killFrame(ExtFrame inTF) {

		if (inTF == myFrame) {
			thisTantrix.kill();
			myFrame.dispose();
			myFrame = null;
		}
	}

	private int computeChatHeight(int inHeight) {

		if (insets().top < 10) {
			inHeight = inHeight - 50;
		} else {
			inHeight = inHeight - insets().top - insets().bottom;
		}
		int localChatHeight = MINCHATHEIGHT;
		if (inHeight > (MINCHATHEIGHT+BARHEIGHT)) {
			localChatHeight = MINCHATHEIGHT + (inHeight-MINCHATHEIGHT-BARHEIGHT)/3;
		}
		if (localChatHeight > MAXCHATHEIGHT) {
			localChatHeight = MAXCHATHEIGHT;
		}
		return(localChatHeight);
	}

	private int computeGameHeight(int inHeight, int inChatHeight) {

		if (insets().top < 10) {
			inHeight = inHeight - 50;
		} else {
			inHeight = inHeight - insets().top - insets().bottom;
		}
		int localGameHeight = BARHEIGHT;
		if ((inHeight-inChatHeight - 15) > BARHEIGHT) {
			localGameHeight = inHeight - inChatHeight - 15;
		}
		if (localGameHeight > ((int)(ScaleFactors[boardScaleIndex]*3*PolyParams[UnityScaleIndex][0]*(BoardDimY+1)/2.0))) {
			localGameHeight = (int)(ScaleFactors[boardScaleIndex]*3*PolyParams[UnityScaleIndex][0]*(BoardDimY+1)/2.0);
		}
		return(localGameHeight);
	}

	private int computeTotalWidth(int inWidth) {

		if (insets().left == 0) {
			inWidth = inWidth - 10;
		} else {
			inWidth = inWidth - insets().left - insets().right;
		}
		int localTotalWidth = inWidth;
		if (localTotalWidth > (BARWIDTH + (BoardDimX+1) * PolyParams[boardScaleIndex][1])) {
			localTotalWidth = BARWIDTH + (BoardDimX+1) * PolyParams[boardScaleIndex][1];
		}
		return(localTotalWidth);
	}

	public synchronized void reshape(int inX, int inY, int inWidth, int inHeight) {

		windowWidth = inWidth;
		windowHeight = inHeight;
		if (insets().left == 0) {
			inX = inX + 5;
		} else {
			inX = inX + insets().left;
		}
		if (insets().top < 10) {
			inY = inY + 25;
		} else {
			inY = inY + insets().top;
		}
		super.reshape(inX,inY,inWidth,inHeight);
		if (initialized) {
			int chatHeight = computeChatHeight(inHeight);
			gameHeight = computeGameHeight(inHeight, chatHeight);
			gameVOffset = chatHeight + 10;
			int oldTotalWidth = totalWidth;
			totalWidth = computeTotalWidth(inWidth);
			theChat.doReshape(0,0,totalWidth,chatHeight);
			setMinOffsets();
			limitOffsets();
			if ((gameHeight > 0) && (totalWidth > 0)) {
				allFixed = createImage(totalWidth,gameHeight);
				offScreen = createImage(totalWidth,gameHeight);
				allFixedGC = allFixed.getGraphics();
				allFixedGC.setColor(Color.white);
				allFixedGC.setPaintMode();
				allFixedGC.fillRect(0,0,windowWidth,windowHeight);
				offScreenGC = offScreen.getGraphics();
				offScreenGC.setColor(Color.white);
				offScreenGC.setPaintMode();
				offScreenGC.fillRect(0,0,windowWidth,windowHeight);
			}
			Graphics thisGC = this.getGraphics();
			thisGC.setColor(Color.white);
			thisGC.setPaintMode();
			thisGC.fillRect(0,0,windowWidth,windowHeight);
			refreshBoard = true;
			refreshBars = true;
		}
		repaint();
	}

	private String formName() {

		char ourName[] = new char[13];	/* 13 characters  for our name */
		ourName[0] = '9';
		ourName[1] = (char)((int)'n' - 16);
		ourName[2] = 'd';
		ourName[3] = 'U';
		ourName[4] = 'b';
		ourName[5] = '>';
		ourName[6] = 'U';
		ourName[7] = 'd';
		ourName[8] = 'Y';
		ourName[9] = 'f';
		ourName[10] = 'Y';
		ourName[11] = 'd';
		ourName[12] = 'i';
		for (int charCnt=0;charCnt<13;charCnt++) {
			ourName[charCnt] += 16;
		}
		return(new String(ourName));
	}

	public void init() {

	}

	public void doInit() {

//		String checkCB = this.getCodeBase().toString();
//		if (checkCB.indexOf(HOSTIP) == -1) {
//			System.out.println("System error.");
//			System.exit(1);
//		}
		myFrame = new ExtFrame(formName()+" Tantrix Puzzle",this);
		myFrame.setBackground(Color.white);
		String winReadStr = null;
		String objectReadStr = null;
		String piecesReadStr = null;
		String solutionType = null;
		readString = getParameter("puzzle");
		if (readString != null) {
			puzzle = true;
			gameState = PUZZLE;
			winReadStr = getParameter("win");
			solutionType = getParameter("solutiontype");
			objectReadStr = getParameter("object");
			if (objectReadStr == null) {
				objectReadStr = "Move tiles to form colour strings and loops.";
			}
			piecesReadStr = getParameter("pieces");
		}
		thisTantrix = new TantrixPuzzle();
		myFrame.add(thisTantrix);
		myFrame.show();
		myFrame.resize(DEFAULTWIDTH+myFrame.insets().left+myFrame.insets().right,DEFAULTHEIGHT+myFrame.insets().top+myFrame.insets().bottom);
		myFrame.setResizable(true);
		thisTantrix.init(this, 0, new String("puzzle "+solutionType+" "+winReadStr+" "+readString+" "+piecesReadStr+" "+objectReadStr), "Puzzle", -1, -1, null);
		myFrame.start();
		thisTantrix.start();
	}

	public void init(Applet inRoot, int inWaitForPlayers, String inRole, String inName, int inSessNum, int inGamePos, String inPW) {

//		String checkCB = theRoot.getCodeBase().toString();
//		if (checkCB.indexOf(HOSTIP) == -1) {
//			System.out.println("System error.");
//			System.exit(1);
//		}
		setBackground(Color.white);
		allFixed = createImage(totalWidth,BARHEIGHT);
		boardExtentX = myRound(ScaleFactors[TopBoardScaleIndex]*Root3*PolyParams[UnityScaleIndex][0]*(BoardDimX+1)/2.0);
		boardExtentY = myRound(ScaleFactors[TopBoardScaleIndex]*3*PolyParams[UnityScaleIndex][0]*(BoardDimY+1)/2.0);
		theBoard = createImage(boardExtentX,boardExtentY);
		leftBar = createImage(BARWIDTH,(int)(ScaleFactors[TopBoardScaleIndex]*3*PolyParams[UnityScaleIndex][0]*(BoardDimY+1)/2.0));
		rightBar = createImage(4*BARWIDTH,(int)(ScaleFactors[TopBoardScaleIndex]*3*PolyParams[UnityScaleIndex][0]*(BoardDimY+1)/2.0));
		offScreen = createImage(totalWidth,BARHEIGHT);
		allFixedGC = allFixed.getGraphics();
		theBoardGC = theBoard.getGraphics();
		leftBarGC = leftBar.getGraphics();
		leftBarGC.setFont(new Font("helvetica",Font.BOLD,FontHeight));
		rightBarGC = rightBar.getGraphics();
		offScreenGC = offScreen.getGraphics();
		arrowPolygon = new Polygon();
		arrowPolygon.addPoint(-12,-1);
		arrowPolygon.addPoint(-12,-4);
		arrowPolygon.addPoint(-16,0);
		arrowPolygon.addPoint(-12,+4);
		arrowPolygon.addPoint(-12,1);
		arrowPolygon.addPoint(12,1);
		arrowPolygon.addPoint(12,+4);
		arrowPolygon.addPoint(16,0);
		arrowPolygon.addPoint(12,-4);
		arrowPolygon.addPoint(12,-1);
		arrowPolygon.addPoint(-12,-1);
		namePassedIn = inName;
		theRoot = inRoot;
		doAutoRotateStr = theRoot.getParameter("doautorotate");
		if (doAutoRotateStr != null) {
			doAutoRotate = doAutoRotateStr.equals("true");
		}
		StringTokenizer localST = new StringTokenizer(inRole);
		String cmdStr = localST.nextToken();
		if (cmdStr.equals("puzzle")) {
			puzzle = true;
			puzzleType = localST.nextToken();
			puzzleWin = (Integer.valueOf(localST.nextToken())).intValue();
			puzzleSize = (Integer.valueOf(localST.nextToken())).intValue();
			for (int piecesIndex=0;piecesIndex<puzzleSize;piecesIndex++) {
				puzzlePieces[piecesIndex] = (Integer.valueOf(localST.nextToken())).intValue();
			}
			puzzleObject = localST.nextToken();
			while (localST.hasMoreTokens()) {
				puzzleObject = puzzleObject + " " + localST.nextToken();
			}
			gameState = PUZZLE;
		}
		repaint();
	}

	public void start() {

		if (myThread == null) {
			myThread = new Thread(this);
			myThread.start();
		}
		setLayout(null);
	}

	private int myMod(int inNum, int inBase) {

		int tempInt = inNum - (inNum/inBase)*inBase;
		if (tempInt < 0) {
			tempInt += inBase;
		}
		return(tempInt);
	}

	private int colourOnSide(int tileNum, int tileOrient, int sideNum) {

		int realSide = myMod(sideNum-tileOrient,6);
		for (int i=0;i<9;i+=3) {
			if (tiles[tileNum][i+1] == ShortArc) {
				if ((tiles[tileNum][i+2] == realSide) || (myMod(tiles[tileNum][i+2]-1,6) == realSide)) {
					return(tiles[tileNum][i]);
				}
			} else if (tiles[tileNum][i+1] == LongArc) {
				if ((myMod(tiles[tileNum][i+2]-1,6) == realSide) || (myMod(tiles[tileNum][i+2]+1,6) == realSide)) {
					return(tiles[tileNum][i]);
				}
			} else if (tiles[tileNum][i+1] == Straight) {
				if ((tiles[tileNum][i+2] == realSide) || (myMod(tiles[tileNum][i+2]+3,6) == realSide)) {
					return(tiles[tileNum][i]);
				}
			}
		}
		return(Red);
	}

	private boolean validSides(int XPos, int YPos) {
	
		atLeastOne = false;
		if (tilesLeft == (56 - (numberOtherPlayers + 1) * 6)) {
			atLeastOne = true;
		}
		boolean allMatch = true;
		if (validBoardPos(XPos-1, YPos-1)) {
			if (board[XPos-1][YPos-1] != -1) {
				atLeastOne = true;
				if (colourOnSide(board[XPos][YPos],boardOrient[XPos][YPos],5) != colourOnSide(board[XPos-1][YPos-1],boardOrient[XPos-1][YPos-1],2)) {
					allMatch = false;
				}
			}
		}
		if (validBoardPos(XPos+1, YPos-1)) {
			if (board[XPos+1][YPos-1] != -1) {
				atLeastOne = true;
				if (colourOnSide(board[XPos][YPos],boardOrient[XPos][YPos],0) != colourOnSide(board[XPos+1][YPos-1],boardOrient[XPos+1][YPos-1],3)) {
					allMatch = false;
				}
			}
		}
		if (validBoardPos(XPos+2, YPos)) {
			if (board[XPos+2][YPos] != -1) {
				atLeastOne = true;
				if (colourOnSide(board[XPos][YPos],boardOrient[XPos][YPos],1) != colourOnSide(board[XPos+2][YPos],boardOrient[XPos+2][YPos],4)) {
					allMatch = false;
				}
			}
		}
		if (validBoardPos(XPos+1, YPos+1)) {
			if (board[XPos+1][YPos+1] != -1) {
				atLeastOne = true;
				if (colourOnSide(board[XPos][YPos],boardOrient[XPos][YPos],2) != colourOnSide(board[XPos+1][YPos+1],boardOrient[XPos+1][YPos+1],5)) {
					allMatch = false;
				}
			}
		}
		if (validBoardPos(XPos-1, YPos+1)) {
			if (board[XPos-1][YPos+1] != -1) {
				atLeastOne = true;
				if (colourOnSide(board[XPos][YPos],boardOrient[XPos][YPos],3) != colourOnSide(board[XPos-1][YPos+1],boardOrient[XPos-1][YPos+1],0)) {
					allMatch = false;
				}
			}
		}
		if (validBoardPos(XPos-2, YPos)) {
			if (board[XPos-2][YPos] != -1) {
				atLeastOne = true;
				if (colourOnSide(board[XPos][YPos],boardOrient[XPos][YPos],4) != colourOnSide(board[XPos-2][YPos],boardOrient[XPos-2][YPos],1)) {
					allMatch = false;
				}
			}
		}
		return(atLeastOne && allMatch);
	}

	private boolean validSpaces(int XPos, int YPos) {

		boolean allValid = true;
		if (validBoardPos(XPos-1, YPos-1)) {
			if (board[XPos-1][YPos-1] == -1) {
				allValid = allValid && validSpace(XPos-1,YPos-1);
			}
		}
		if (validBoardPos(XPos+1, YPos-1)) {
			if (board[XPos+1][YPos-1] == -1) {
				allValid = allValid && validSpace(XPos+1,YPos-1);
			}
		}
		if (validBoardPos(XPos+2, YPos)) {
			if (board[XPos+2][YPos] == -1) {
				allValid = allValid && validSpace(XPos+2,YPos);
			}
		}
		if (validBoardPos(XPos+1, YPos+1)) {
			if (board[XPos+1][YPos+1] == -1) {
				allValid = allValid && validSpace(XPos+1,YPos+1);
			}
		}
		if (validBoardPos(XPos-1, YPos+1)) {
			if (board[XPos-1][YPos+1] == -1) {
				allValid = allValid && validSpace(XPos-1,YPos+1);
			}
		}
		if (validBoardPos(XPos-2, YPos)) {
			if (board[XPos-2][YPos] == -1) {
				allValid = allValid && validSpace(XPos-2,YPos);
			}
		}
		return(allValid);
	}

	private boolean validSpace(int XPos, int YPos) {

		boolean hasColour[] = {false,false,false,false};
		int numColours[] = {0,0,0,0};
		int colourNum;
		if (board[XPos][YPos] != -1) {
			return(true);
		}
		if (validBoardPos(XPos-1, YPos-1)) {
			if (board[XPos-1][YPos-1] != -1) {
				colourNum = colourOnSide(board[XPos-1][YPos-1],boardOrient[XPos-1][YPos-1],2);
				hasColour[colourNum] = true;
				numColours[colourNum]++;
			}
		}
		if (validBoardPos(XPos+1, YPos-1)) {
			if (board[XPos+1][YPos-1] != -1) {
				colourNum = colourOnSide(board[XPos+1][YPos-1],boardOrient[XPos+1][YPos-1],3);
				hasColour[colourNum] = true;
				numColours[colourNum]++;
			}
		}
		if (validBoardPos(XPos+2, YPos)) {
			if (board[XPos+2][YPos] != -1) {
				colourNum = colourOnSide(board[XPos+2][YPos],boardOrient[XPos+2][YPos],4);
				hasColour[colourNum] = true;
				numColours[colourNum]++;
			}
		}
		if (validBoardPos(XPos+1, YPos+1)) {
			if (board[XPos+1][YPos+1] != -1) {
				colourNum = colourOnSide(board[XPos+1][YPos+1],boardOrient[XPos+1][YPos+1],5);
				hasColour[colourNum] = true;
				numColours[colourNum]++;
			}
		}
		if (validBoardPos(XPos-1, YPos+1)) {
			if (board[XPos-1][YPos+1] != -1) {
				colourNum = colourOnSide(board[XPos-1][YPos+1],boardOrient[XPos-1][YPos+1],0);
				hasColour[colourNum] = true;
				numColours[colourNum]++;
			}
		}
		if (validBoardPos(XPos-2, YPos)) {
			if (board[XPos-2][YPos] != -1) {
				colourNum = colourOnSide(board[XPos-2][YPos],boardOrient[XPos-2][YPos],1);
				hasColour[colourNum] = true;
				numColours[colourNum]++;
			}
		}
		boolean isOK = true;
		for (colourNum=0;colourNum<4;colourNum++) {
			if (numColours[colourNum] > 2) {
				isOK = false;
			}
		}
		return(isOK && !(hasColour[0] && hasColour[1] && hasColour[2] && hasColour[3]));
	}

	private boolean notControlled(int XPos, int YPos) {

		boolean isOK = true;
		int xOff, yOff;
		if (validBoardPos(XPos-1, YPos-1)) {
			if (board[XPos-1][YPos-1] == -1) {
				xOff = -2;
				yOff = -2;
				while (validBoardPos(XPos+xOff, YPos+yOff)) {
					if (board[XPos+xOff][YPos+yOff] != -1) {
						isOK = false;
					}
					xOff += -1;
					yOff += -1;
				}
			}
		}
		if (validBoardPos(XPos+1, YPos-1)) {
			if (board[XPos+1][YPos-1] == -1) {
				xOff = +2;
				yOff = -2;
				while (validBoardPos(XPos+xOff, YPos+yOff)) {
					if (board[XPos+xOff][YPos+yOff] != -1) {
						isOK = false;
					}
					xOff += 1;
					yOff += -1;
				}
			}
		}
		if (validBoardPos(XPos+2, YPos)) {
			if (board[XPos+2][YPos] == -1) {
				xOff = 4;
				while (validBoardPos(XPos+xOff, YPos)) {
					if (board[XPos+xOff][YPos] != -1) {
						isOK = false;
					}
					xOff += 2;
				}
			}
		}
		if (validBoardPos(XPos+1, YPos+1)) {
			if (board[XPos+1][YPos+1] == -1) {
				xOff = 2;
				yOff = 2;
				while (validBoardPos(XPos+xOff, YPos+yOff)) {
					if (board[XPos+xOff][YPos+yOff] != -1) {
						isOK = false;
					}
					xOff += 1;
					yOff += 1;
				}
			}
		}
		if (validBoardPos(XPos-1, YPos+1)) {
			if (board[XPos-1][YPos+1] == -1) {
				xOff = -2;
				yOff = 2;
				while (validBoardPos(XPos+xOff, YPos+yOff)) {
					if (board[XPos+xOff][YPos+yOff] != -1) {
						isOK = false;
					}
					xOff += -1;
					yOff += 1;
				}
			}
		}
		if (validBoardPos(XPos-2, YPos)) {
			if (board[XPos-2][YPos] == -1) {
				xOff = -4;
				while (validBoardPos(XPos+xOff, YPos)) {
					if (board[XPos+xOff][YPos] != -1) {
						isOK = false;
					}
					xOff += -2;
				}
			}
		}
		return(isOK);
	}

	private boolean threeSides(int inX, int inY) {

		int tempCount = 0;
		if (validBoardPos(inX-1,inY-1) && (board[inX-1][inY-1] != -1)) {
			tempCount++;
		}
		if (validBoardPos(inX+1,inY-1) && (board[inX+1][inY-1] != -1)) {
			tempCount++;
		}
		if (validBoardPos(inX+2,inY) && (board[inX+2][inY] != -1)) {
			tempCount++;
		}
		if (validBoardPos(inX+1,inY+1) && (board[inX+1][inY+1] != -1)) {
			tempCount++;
		}
		if (validBoardPos(inX-1,inY+1) && (board[inX-1][inY+1] != -1)) {
			tempCount++;
		}
		if (validBoardPos(inX-2,inY) && (board[inX-2][inY] != -1)) {
			tempCount++;
		}
		if (tempCount >= 3) {
			return(true);
		}
		return(false);
	}

	private boolean mobileBorder(int inX, int inY, int movedTileNum) {
	
		if (validBoardPos(inX-1,inY-1) && (board[inX-1][inY-1] == movedTileNum)) {
			return(true);
		}
		if (validBoardPos(inX+1,inY-1) && (board[inX+1][inY-1] == movedTileNum)) {
			return(true);
		}
		if (validBoardPos(inX+2,inY) && (board[inX+2][inY] == movedTileNum)) {
			return(true);
		}
		if (validBoardPos(inX+1,inY+1) && (board[inX+1][inY+1] == movedTileNum)) {
			return(true);
		}
		if (validBoardPos(inX-1,inY+1) && (board[inX-1][inY+1] == movedTileNum)) {
			return(true);
		}
		if (validBoardPos(inX-2,inY) && (board[inX-2][inY] == movedTileNum)) {
			return(true);
		}
		return(false);
	}

	private int computeScores() {
	
		int tileInd, scoreColour, tileSide, currentScore, currentTileSide, nextTile;
		int origScore0 = score[0];
		int origScore1 = score[1];
		int origScore2 = score[2];
		int origScore3 = score[3];
		int origMaxLoopScore = maxLoopScore;
		int origMaxLineScore = maxLineScore;
		int mismatches = 0;

		for (int i=0;i<4;i++) {
			score[i] = 0;
		}
		maxLoopScore = 0;
		maxLineScore = 0;
		if (firstTileX == -1) {
			return(-1);
		}
		for (int i=1;i<57;i++) {
			onBoard[i] = false;
			scored[i] = 0;
			scoredFlags[i][Red] = false;
			scoredFlags[i][Yellow] = false;
			scoredFlags[i][Green] = false;
			scoredFlags[i][Blue] = false;
		}
		onBoard[board[firstTileX][firstTileY]] = true;
		boolean doneScoring = false;
		while (!doneScoring) {
			doneScoring = true;
			tileInd = 1;
			while ((tileInd<57) && ((onBoard[tileInd] == false) || ((onBoard[tileInd] == true) && (scored[tileInd] == 3)))) {
				tileInd++;
			}
			if (tileInd != 57) {
				doneScoring = false;
				scoreColour = -1;
				tileSide = 0;
				while ((tileSide < 6) && (scoreColour == -1)) {
					scoreColour = colourOnSide(tileInd,tileOrientation[tileInd],tileSide);
					if (scoredFlags[tileInd][scoreColour]) {
						scoreColour = -1;
						tileSide++;
					}
				}
				if (tileSide == 6) {
//					System.out.println(playerIDs[0]+": Error computing scores: no non-scored colour found for tile "+tileInd+" at ("+tilePos[tileInd][0]+","+tilePos[tileInd][1]+")");
					systemError(4);
					for (int uhoh=1;uhoh<57;uhoh++) {
						if (onBoard[uhoh]) {
//							System.out.println(playerIDs[0]+": Tile "+uhoh+" at ("+tilePos[uhoh][0]+","+tilePos[uhoh][1]+") has "+scored[uhoh]+" scored: "+scoredFlags[0]+","+scoredFlags[1]+","+scoredFlags[2]+","+scoredFlags[3]);
							systemError(5);
						}
					}
					score[0] = origScore0;
					score[1] = origScore1;
					score[2] = origScore2;
					score[3] = origScore3;
					maxLoopScore = origMaxLoopScore;
					maxLineScore = origMaxLineScore;
					return(-1);
				}
				scoredFlags[tileInd][scoreColour] = true;
				scored[tileInd]++;
				currentScore = 1;
				currentTileSide = tileSide;
				nextTile = neighbourTileNum(tileInd,currentTileSide);
				currentTileSide = myMod(currentTileSide+3,6);
				while ((nextTile != -1) && (nextTile != tileInd) && (scoreColour == colourOnSide(nextTile,tileOrientation[nextTile],currentTileSide))) {
					onBoard[nextTile] = true;
					scored[nextTile]++;
					scoredFlags[nextTile][scoreColour] = true;
					currentScore++;
					currentTileSide = oppositeTileSide(nextTile,tileOrientation[nextTile],currentTileSide);
					nextTile = neighbourTileNum(nextTile,currentTileSide);
					currentTileSide = myMod(currentTileSide+3,6);
				}
				if  ((nextTile != -1) && (scoreColour != colourOnSide(nextTile,tileOrientation[nextTile],currentTileSide))) {
					mismatches++;
					onBoard[nextTile] = true;
				}
				if ((nextTile == tileInd) && (scoreColour == colourOnSide(nextTile,tileOrientation[nextTile],currentTileSide))) {
					currentScore = 2*currentScore;
					if (currentScore > maxLoopScore) {
						maxLoopScore = currentScore;
					}
				} else {
					currentTileSide = oppositeTileSide(tileInd,tileOrientation[tileInd],tileSide);
					nextTile = neighbourTileNum(tileInd,currentTileSide);
					currentTileSide = myMod(currentTileSide+3,6);
					while ((nextTile != -1) && (scoreColour == colourOnSide(nextTile,tileOrientation[nextTile],currentTileSide))) {
						onBoard[nextTile] = true;
						scored[nextTile]++;
						currentScore++;
						scoredFlags[nextTile][scoreColour] = true;
						currentTileSide = oppositeTileSide(nextTile,tileOrientation[nextTile],currentTileSide);
						nextTile = neighbourTileNum(nextTile,currentTileSide);
						currentTileSide = myMod(currentTileSide+3,6);
					}
					if  ((nextTile != -1) && (scoreColour != colourOnSide(nextTile,tileOrientation[nextTile],currentTileSide))) {
						mismatches++;
						onBoard[nextTile] = true;
					}
					if (currentScore > maxLineScore) {
						maxLineScore = currentScore;
					}
				}
				if (currentScore > score[scoreColour]) {
					score[scoreColour] = currentScore;
				}
			}
		}
		return(mismatches/2);
	}

	private int oppositeTileSide(int tileN, int tileO, int tileS) {

		int arcType, sideNum;
		int realSide = myMod(tileS-tileO,6);
		for (int ix=1;ix<8;ix=ix+3) {
			arcType = tiles[tileN][ix];
			sideNum = tiles[tileN][ix+1];
			if (arcType == ShortArc) {
				if (realSide == sideNum) {
					return(myMod(sideNum-1+tileO,6));
				} else if (realSide == myMod(sideNum-1,6)) {
					return(myMod(sideNum+tileO,6));
				}
			} else if (arcType == LongArc) {
				if (realSide == myMod(sideNum-1,6)) {
					return(myMod(sideNum+1+tileO,6));
				} else if (realSide == myMod(sideNum+1,6)) {
					return(myMod(sideNum-1+tileO,6));
				}
			} else if (arcType == Straight) {
				if (realSide == sideNum) {
					return(myMod(sideNum+3+tileO,6));
				} else if (realSide == myMod(sideNum+3,6)) {
					return(myMod(sideNum+tileO,6));
				}
			}
		}
		return(-1);
	}

	private int neighbourTileNum(int tileN, int tileS) {

		int newX = tilePos[tileN][0], newY = tilePos[tileN][1];
		if (tileS == 0) {
			newX++;
			newY--;
		} else if (tileS == 1) {
			newX += 2;
		} else if (tileS == 2) {
			newX++;
			newY++;
		} else if (tileS == 3) {
			newX--;
			newY++;
		} else if (tileS == 4) {
			newX -= 2;
		} else if (tileS == 5) {
			newX--;
			newY--;
		}
		if (validBoardPos(newX,newY)) {
			return(board[newX][newY]);
		}
		return(-1);
	}

	private void createPolygons(int scaleIndex) {

		double angle, radius, xPos, yPos;
		Polygon thePoly = null;

		thePoly = new Polygon();
		cornerXs[0] = 0;
		cornerYs[0] = 2-PolyParams[scaleIndex][0];
		cornerXs[1] = PolyParams[scaleIndex][1]-1;
		cornerYs[1] = 1-(PolyParams[scaleIndex][0]/2.0);
		cornerXs[2] = PolyParams[scaleIndex][1]-1;
		cornerYs[2] = PolyParams[scaleIndex][0]/2.0-1;
		cornerXs[3] = 0;
		cornerYs[3] = PolyParams[scaleIndex][0]-1;
		cornerXs[4] = 1-PolyParams[scaleIndex][1];
		cornerYs[4] = PolyParams[scaleIndex][0]/2.0-1;
		cornerXs[5] = 1-PolyParams[scaleIndex][1];
		cornerYs[5] = 1-(PolyParams[scaleIndex][0]/2.0);
		sideCentreXs[0] = PolyParams[scaleIndex][1];
		sideCentreXs[1] = 2*PolyParams[scaleIndex][1];
		sideCentreXs[2] = PolyParams[scaleIndex][1];
		sideCentreXs[3] = -PolyParams[scaleIndex][1];
		sideCentreXs[4] = -2*PolyParams[scaleIndex][1];
		sideCentreXs[5] = -PolyParams[scaleIndex][1];
		sideCentreYs[0] = -3*PolyParams[scaleIndex][0]/2.0;
		sideCentreYs[1] = 0;
		sideCentreYs[2] = 3*PolyParams[scaleIndex][0]/2.0;
		sideCentreYs[3] = 3*PolyParams[scaleIndex][0]/2.0;
		sideCentreYs[4] = 0;
		sideCentreYs[5] = -3*PolyParams[scaleIndex][0]/2.0;
		if (scaleIndex == 0) {
			thePoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2]));
			thePoly.addPoint(myRound(cornerXs[3]),myRound(cornerYs[3]));
			thePoly.addPoint(myRound(cornerXs[4]),myRound(cornerYs[4]));
			thePoly.addPoint(myRound(cornerXs[5]),myRound(cornerYs[5]));
			thePoly.addPoint(myRound(cornerXs[0]),myRound(cornerYs[0])-1);
			thePoly.addPoint(myRound(cornerXs[1]),myRound(cornerYs[1]));
			thePoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2]));
		} else {
			thePoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2])-4);
			thePoly.addPoint(myRound(cornerXs[2])-1,myRound(cornerYs[2]));
			thePoly.addPoint(myRound(cornerXs[2])-3,myRound(cornerYs[2])+2);

			thePoly.addPoint(myRound(cornerXs[3])+3,myRound(cornerYs[3])-1);
			thePoly.addPoint(myRound(cornerXs[3]+1),myRound(cornerYs[3]));
			thePoly.addPoint(myRound(cornerXs[3]-1),myRound(cornerYs[3]));
			thePoly.addPoint(myRound(cornerXs[3])-3,myRound(cornerYs[3])-1);

			thePoly.addPoint(myRound(cornerXs[4])+3,myRound(cornerYs[4])+2);
			thePoly.addPoint(myRound(cornerXs[4])+1,myRound(cornerYs[4]));
			thePoly.addPoint(myRound(cornerXs[4]),myRound(cornerYs[4])-4);

			thePoly.addPoint(myRound(cornerXs[5]),myRound(cornerYs[5])+4);
			thePoly.addPoint(myRound(cornerXs[5])+1,myRound(cornerYs[5]));
			thePoly.addPoint(myRound(cornerXs[5])+3,myRound(cornerYs[5])-2);

			thePoly.addPoint(myRound(cornerXs[0])-3,myRound(cornerYs[0])+1);
			thePoly.addPoint(myRound(cornerXs[0]-1),myRound(cornerYs[0]));
			thePoly.addPoint(myRound(cornerXs[0]+1),myRound(cornerYs[0]));
			thePoly.addPoint(myRound(cornerXs[0])+3,myRound(cornerYs[0])+1);

			thePoly.addPoint(myRound(cornerXs[1])-3,myRound(cornerYs[1])-2);
			thePoly.addPoint(myRound(cornerXs[1])-1,myRound(cornerYs[1]));
			thePoly.addPoint(myRound(cornerXs[1]),myRound(cornerYs[1])+4);

			thePoly.addPoint(myRound(cornerXs[2]),myRound(cornerYs[2])-4);
		}
		tilePoly[scaleIndex] = new Polygon(thePoly.xpoints,thePoly.ypoints,thePoly.npoints);

		for (int i=0;i<6;i++) {
			thePoly = new Polygon();
			double startAngle = i*60 + 30.0 + PolyParams[scaleIndex][3];
			double spanAngle = 120.0 - 2*PolyParams[scaleIndex][3];
			for (int j=0;j<=NumBandPoints;j++) {
				angle = startAngle + j*spanAngle/NumBandPoints;
				radius = (PolyParams[scaleIndex][0] - PolyParams[scaleIndex][2]-1)/2.0;
				xPos = cornerXs[i] + radius*myCos(angle);
				yPos = cornerYs[i] + radius*mySin(angle);
				thePoly.addPoint(myRound(xPos),myRound(yPos));
			}
			for (int j=0;j<=NumBandPoints;j++) {
				angle = startAngle + (NumBandPoints-j)*spanAngle/NumBandPoints;
				radius = (PolyParams[scaleIndex][0] + PolyParams[scaleIndex][2])/2.0;
				xPos = cornerXs[i] + radius*myCos(angle);
				yPos = cornerYs[i] + radius*mySin(angle);
				thePoly.addPoint(myRound(xPos),myRound(yPos));
			}
			angle = i*60 + 30.0 + PolyParams[scaleIndex][3];
			radius = (PolyParams[scaleIndex][0] - PolyParams[scaleIndex][2])/2.0;
			xPos = cornerXs[i] + radius*myCos(angle);
			yPos = cornerYs[i] + radius*mySin(angle);
			thePoly.addPoint(myRound(xPos),myRound(yPos));
			smallArcPoly[scaleIndex][i] = new Polygon(thePoly.xpoints,thePoly.ypoints,thePoly.npoints);
		}

		for (int i=0;i<6;i++) {
			thePoly = new Polygon();
			double startAngle = i*60 + 90.0 + PolyParams[scaleIndex][4];
			double spanAngle = 60 - 2*PolyParams[scaleIndex][4];
			for (int j=0;j<=NumBandPoints;j++) {
				angle = startAngle + j*spanAngle/NumBandPoints;
				radius = (3*PolyParams[scaleIndex][0] - PolyParams[scaleIndex][2])/2.0;
				xPos = sideCentreXs[i] + radius*myCos(angle);
				yPos = sideCentreYs[i] + radius*mySin(angle);
				thePoly.addPoint(myRound(xPos),myRound(yPos));
			}
			for (int j=0;j<=NumBandPoints;j++) {
				angle = startAngle + (NumBandPoints-j)*spanAngle/NumBandPoints;
				radius = (3*PolyParams[scaleIndex][0] + PolyParams[scaleIndex][2])/2.0;
				xPos = sideCentreXs[i] + radius*myCos(angle);
				yPos = sideCentreYs[i] + radius*mySin(angle);
				thePoly.addPoint(myRound(xPos),myRound(yPos));
			}
			angle = i*60 + 90.0 + PolyParams[scaleIndex][4];
			radius = (3*PolyParams[scaleIndex][0] - PolyParams[scaleIndex][2])/2.0;
			xPos = sideCentreXs[i] + radius*myCos(angle);
			yPos = sideCentreYs[i] + radius*mySin(angle);
			thePoly.addPoint(myRound(xPos),myRound(yPos));
			bigArcPoly[scaleIndex][i] = new Polygon(thePoly.xpoints,thePoly.ypoints,thePoly.npoints);
		}
		for (int i=0;i<3;i++) {
			thePoly = new Polygon();
			angle = i*60 - 60.0;
			xPos = PolyParams[scaleIndex][1]*myCos(angle) + (PolyParams[scaleIndex][2]/2.0)*myCos(angle+90.0);
			yPos = PolyParams[scaleIndex][1]*mySin(angle) + (PolyParams[scaleIndex][2]/2.0)*mySin(angle+90.0);
			thePoly.addPoint(myRound(xPos*StraightScales[scaleIndex]),myRound(yPos*StraightScales[scaleIndex]));
			xPos -= PolyParams[scaleIndex][2]*myCos(angle+90.0);
			yPos -= PolyParams[scaleIndex][2]*mySin(angle+90.0);
			thePoly.addPoint(myRound(xPos*StraightScales[scaleIndex]),myRound(yPos*StraightScales[scaleIndex]));
			angle = angle + 180.0;
			xPos = PolyParams[scaleIndex][1]*myCos(angle) + (PolyParams[scaleIndex][2]/2.0)*myCos(angle+90.0);
			yPos = PolyParams[scaleIndex][1]*mySin(angle) + (PolyParams[scaleIndex][2]/2.0)*mySin(angle+90.0);
			thePoly.addPoint(myRound(xPos*StraightScales[scaleIndex]),myRound(yPos*StraightScales[scaleIndex]));
			xPos -= PolyParams[scaleIndex][2]*myCos(angle+90.0);
			yPos -= PolyParams[scaleIndex][2]*mySin(angle+90.0);
			thePoly.addPoint(myRound(xPos*StraightScales[scaleIndex]),myRound(yPos*StraightScales[scaleIndex]));
			angle = angle - 180.0;
			xPos = PolyParams[scaleIndex][1]*myCos(angle) + (PolyParams[scaleIndex][2]/2.0)*myCos(angle+90.0);
			yPos = PolyParams[scaleIndex][1]*mySin(angle) + (PolyParams[scaleIndex][2]/2.0)*mySin(angle+90.0);
			thePoly.addPoint(myRound(xPos*StraightScales[scaleIndex]),myRound(yPos*StraightScales[scaleIndex]));
			straightPoly[scaleIndex][i] = new Polygon(thePoly.xpoints,thePoly.ypoints,thePoly.npoints);
		}
	}

	private boolean odd(int inVal) {

		int absInVal = inVal;
		if (inVal < 0) {
			absInVal = -inVal;
		}
		return((absInVal - (absInVal/2)*2) == 1);
	}

	private boolean even(int inVal) {

		int absInVal = inVal;
		if (inVal < 0) {
			absInVal = -inVal;
		}
		return((absInVal - (absInVal/2)*2) == 0);
	}

	private void doDelay(int inDel) {

		try {
			Thread.sleep(inDel);
		} catch (InterruptedException e) {
//			System.out.println("Sleep was interrupted.");
			systemError(6);
		}
	}

	private synchronized void drawButton(Graphics inG, int theLeft, int theTop, int theWidth, int theHeight, Color theColour) {

		if (dontPaint || (inG == null)) {
			return;
		}
		inG.setColor(theColour);
		inG.fillRect(theLeft,theTop,theWidth,theHeight);
		inG.setColor(Color.white);
		inG.drawLine(theLeft+1,theTop+1,theLeft+theWidth-1,theTop+1);
		inG.drawLine(theLeft+2,theTop+2,theLeft+theWidth-2,theTop+2);
		inG.drawLine(theLeft+1,theTop+1,theLeft+1,theTop+theHeight-1);
		inG.drawLine(theLeft+2,theTop+2,theLeft+2,theTop+theHeight-2);
		inG.setColor(Color.gray);
		inG.drawLine(theLeft+1,theTop+theHeight-1,theLeft+theWidth-1,theTop+theHeight-1);
		inG.drawLine(theLeft+2,theTop+theHeight-2,theLeft+theWidth-2,theTop+theHeight-2);
		inG.drawLine(theLeft+theWidth-1,theTop+1,theLeft+theWidth-1,theTop+theHeight-1);
		inG.drawLine(theLeft+theWidth-2,theTop+2,theLeft+theWidth-2,theTop+theHeight-2);
		inG.drawRect(theLeft,theTop,theWidth,theHeight);
	}

	private synchronized void printTime(Graphics inGC, int inXOffset, long inVal) {

		if (dontPaint || (inGC == null)) {
			return;
		}
		int hours = (int)(inVal/3600000);
		int minutes = (int)((inVal - hours*3600000)/60000);
		int seconds = (int)((inVal - hours*3600000 - minutes*60000)/1000);
		String timeString = Integer.toString(hours) + ":";
		if (minutes < 10) {
			timeString = timeString + "0" + Integer.toString(minutes) + ":";
		} else {
			timeString = timeString + Integer.toString(minutes) + ":";
		}
		if (seconds < 10) {
			timeString = timeString + "0" + Integer.toString(seconds);
		} else {
			timeString = timeString + Integer.toString(seconds);
		}
		fillArea(inGC,inXOffset+1,TimeYOffset,BARWIDTH-2,TimeHeight,Color.white);
		centreText(inGC,inXOffset+1,TimeYOffset,BARWIDTH-2,TimeHeight,Color.black,timeString);
	}

	private synchronized void fillArea(Graphics inG, int theLeft, int theTop, int theWidth, int theHeight, Color theColour) {

		if (dontPaint || (inG == null)) {
			return;
		}
		inG.setColor(theColour);
		inG.fillRect(theLeft,theTop,theWidth,theHeight);
	}

	private void systemError(int inNum) {
	
		System.out.println(playerIDs[0]+": Error "+inNum);
	}

	private synchronized void userMessage(Graphics inG, int inX, int inY, int inWidth, int inHeight, Color inColour, String inStr) {

		int lineNum = 1;
		String nextElement = null;
		String currentStr = null;

		if (dontPaint || (inG == null)) {
			return;
		}
		inG.setColor(Color.white);
		inG.setPaintMode();
		inG.fillRect(0,0,BARWIDTH,BUTTTOP - 2);
		FontMetrics myFM = inG.getFontMetrics();
		StringTokenizer myST = new StringTokenizer(inStr);
		inG.setColor(inColour);
		while (myST.hasMoreElements()) {
			nextElement = myST.nextToken();
			if (myFM.stringWidth(currentStr+" "+nextElement) < inWidth) {
				if (currentStr != null) {
					currentStr = new String(currentStr+" "+nextElement);
				} else {
					currentStr = new String(nextElement);
				}
			} else {
				if (currentStr != null) {
					inG.drawString(currentStr,inX,inY+lineNum*(myFM.getHeight()+3));
				}
				currentStr = new String(nextElement);
				lineNum += 1;
			}
		}
		if (currentStr != null) {
			inG.drawString(currentStr,inX,inY+lineNum*(myFM.getHeight()+3));
		}
	}

	private synchronized void centreText(Graphics inG, int inX, int inY, int inWidth, int inHeight, Color inColour, String inStr) {

		if (dontPaint || (inG == null)) {
			return;
		}
		FontMetrics myFM = inG.getFontMetrics();
		inG.setColor(inColour);
		inG.drawString(inStr,inX + (inWidth - myFM.stringWidth(inStr))/2,inY + (inHeight + myFM.getHeight())/2 - 3);
	}

	private void setMinOffsets() {

		minBoardXOffset = myRound(totalWidth - (BoardDimX+1) * PolyParams[boardScaleIndex][1]);
		minBoardYOffset = myRound(gameHeight - (3*BoardDimY+1) * PolyParams[boardScaleIndex][0] / 2.0);
	}

	private void limitOffsets() {

		if (boardXOffset < minBoardXOffset) {
			boardXOffset = minBoardXOffset;
		}
		if (boardXOffset > BARWIDTH) {
			boardXOffset = BARWIDTH;
		}
		if (boardYOffset < minBoardYOffset) {
			boardYOffset = minBoardYOffset;
		}
		if (boardYOffset > 0) {
			boardYOffset = 0;
		}
	}

	private synchronized void drawZoom(Graphics inGC) {

		if (inGC == null) {
			return;
		}
		inGC.drawRoundRect(SmallZLeft,SmallZTop,SmallZRight-SmallZLeft,SmallZBottom-SmallZTop,6,6);
		inGC.drawLine(SmallZLeft+3,SmallZTop+3,SmallZRight-3,SmallZTop+3);
		inGC.drawLine(SmallZRight-3,SmallZTop+3,SmallZLeft+3,SmallZBottom-3);
		inGC.drawLine(SmallZLeft+3,SmallZBottom-3,SmallZRight-3,SmallZBottom-3);
		inGC.drawRoundRect(BigZLeft,BigZTop,BigZRight-BigZLeft,BigZBottom-BigZTop,6,6);
		inGC.drawLine(BigZLeft+3,BigZTop+3,BigZRight-3,BigZTop+3);
		inGC.drawLine(BigZRight-3,BigZTop+3,BigZLeft+3,BigZBottom-3);
		inGC.drawLine(BigZLeft+3,BigZBottom-3,BigZRight-3,BigZBottom-3);
		inGC.drawLine(SmallZRight+3,(SmallZTop+SmallZBottom)/2,BigZLeft-3,(SmallZTop+SmallZBottom)/2);
	}

	private synchronized void clearLeftBar() {

		leftBarGC.setColor(Color.white);
		leftBarGC.setPaintMode();
		leftBarGC.fillRect(0,0,BARWIDTH,gameHeight);
	}

	private Point getBoardXY(int tileNum) {

		for (int xInd=0;xInd<BoardDimX;xInd++) {
			for (int yInd=0;yInd<BoardDimY;yInd++) {
				if (board[xInd][yInd] == tileNum) {
					return(new Point(xInd,yInd));
				}
			}
		}
		return(new Point(-1,-1));
	}

	private void doPUZZLE() {
	
		int tempCS = 1;
		if ((puzzleCentreX != -1) && (puzzleCentreY != -1) && (board[puzzleCentreX][puzzleCentreY] != -1)) {
			firstTileX = puzzleCentreX;
			firstTileY = puzzleCentreY;
			maxLineScore = 0;
			maxLoopScore = 0;
			tempCS = computeScores();
			if ((tempCS != lastComputeScores) && (tempCS > 0) && (theChat != null)) {
				playTileDropSound = false;
				if (tempCS == 1) {
					theChat.postMessage(0,"badhint","1 link doesn't match.");
				} else if (tempCS < 5) {
					theChat.postMessage(0,"badhint",new String(tempCS+" links don't match."));
				} else {
					theChat.postMessage(0,"badhint","Many links don't match.");
				}
			}
			lastComputeScores = tempCS;
			firstTileX = -1;
			firstTileY = -1;
		} else {
			score[0] = 0;
			score[1] = 0;
			score[2] = 0;
			score[3] = 0;
			maxLineScore = 0;
			maxLoopScore = 0;
		}
		if (((maxLineScore == puzzleWin) && (puzzleType.equals("line"))) || ((maxLoopScore == puzzleWin) && (puzzleType.equals("loop")))) {
			if (tempCS == 0) {
				if (!havePuzzleSolution) {
					if (theChat != null) {
						playTileDropSound = false;
						theChat.postMessage(0,"chat","Congratulations, you have found a solution to the puzzle.");
					}
				}
				havePuzzleSolution = true;
			} else {
				if (havePuzzleSolution) {
					if (theChat != null) {
						playTileDropSound = false;
						theChat.postMessage(0,"chat","You no longer have a solution to the puzzle.");
					}
				}
				havePuzzleSolution = false;
			}
		} else {
			if (havePuzzleSolution) {
				if (theChat != null) {
					playTileDropSound = false;
					theChat.postMessage(0,"chat","You no longer have a solution to the puzzle.");
				}
			}
			havePuzzleSolution = false;
		}
		if (playTileDropSound) {
			if (dropTileSound != null) {
 				dropTileSound.play();
			}
			playTileDropSound = false;
		}
		for (int buttCount=0;buttCount<4;buttCount++) {
			drawButton(leftBarGC,buttLefts[buttCount],buttTops[buttCount],buttRights[buttCount]-buttLefts[buttCount],buttBottoms[buttCount]-buttTops[buttCount],myColours[buttCount]);
		}
		if (refreshTimes) {
			refreshTimes = false;
			if (!mouseDownFlag) {
				printTime(leftBarGC,0,elapsedTimes[0]);
				refreshBars = true;
				repaint();
			}
		}
	}

	public void kill() {

		exitFlag = true;
		doDelay(100);
		myThread.stop();
		myThread = null;
		doDelay(100);
	}

	public void run() {

		if (theRoot == null) {
			doInit();
		}
		if (!initialized) {
			for (int i=0;i<NumBoardScaleIndices;i++) {
				createPolygons(i);
			}
			for (int i=0;i<56;i++) {
				freePieces[i+1] = true;
				tilePos[i+1][0] = -1;
				tilePos[i+1][1] = -1;
				tileOrientation[i+1] = -1;
			}
			for (int i=0;i<4;i++) {
				score[i] = 0;
			}
			dontPaint = false;
			clearBoard();
			if (puzzle) {
				int localXX = BoardDimX/2 - 5;
				int localYY = BoardDimY/2 - 2;
				for (int tileCtr=0;tileCtr<puzzleSize;tileCtr++) {
					board[localXX][localYY] = puzzlePieces[tileCtr];
					tilePos[puzzlePieces[tileCtr]][0] = localXX;
					tilePos[puzzlePieces[tileCtr]][1] = localYY;
					tileOrientation[puzzlePieces[tileCtr]] = 0;
					localXX += 2;
					if (localXX == (BoardDimX/2 + 9)) {
						localXX = BoardDimX/2 - 6;
						localYY++;
					} else if (localXX == (BoardDimX/2 + 8)) {
						localXX = BoardDimX/2 - 5;
						localYY++;
					}
				}
			}
			boardXOffset = myRound(-Root3*PolyParams[UnityScaleIndex][0]*(BoardDimX+1)/4.0) + BARWIDTH + (totalWidth-2*BARWIDTH)/2;
			boardYOffset = myRound(-3*PolyParams[UnityScaleIndex][0]*(BoardDimY+1)/4.0) + gameHeight/2 - 15;
			limitOffsets();
			redrawBoard(true,true,true,true);
			if (puzzle) {
				fillArea(leftBarGC,STARTLEFT,STARTTOP,STARTRIGHT-STARTLEFT,STARTBOTTOM-STARTTOP,Color.white);
			} else {
				drawButton(leftBarGC,STARTLEFT+2,STARTTOP+2,STARTRIGHT-STARTLEFT-5,STARTBOTTOM-STARTTOP-4,Color.lightGray);
				centreText(leftBarGC,STARTLEFT,STARTTOP,STARTRIGHT-STARTLEFT,STARTBOTTOM-STARTTOP,Color.black,"Connect");
			}
			for (int i=0;i<4;i++) {
				drawButton(leftBarGC,buttLefts[i],buttTops[i],buttRights[i]-buttLefts[i],buttBottoms[i]-buttTops[i],myColours[i]);
			}
			if (leftBarGC != null) {
				drawZoom(leftBarGC);
			}
			firstPass = true;
			refreshBoard = true;
			refreshBars = true;
			repaint();
			userMessage(leftBarGC,1,1,(BARWIDTH-2),100,Color.blue,puzzleObject);
			theChat = new chatApplet();
			theChat.setRoot(theRoot);
			theChat.setHideInputField(true);
			theChat.setHideUserCheckboxes(true);
//			theChat.setHideHintCheckbox(true);
			add(theChat);
			theChat.doReshape(0,0,520,200);
			theChat.setConn(null);
			theChat.setUser(0,0,"Tantrix");					/* save index 0 for the owner */
			theChat.setUser(999,"Hint");					/* chat userid 999 is for hints */
			theChat.postMessage(0,"chat","Welcome to "+formName()+" Tantrix!");
			initialized = true;
			reshape(0,0,windowWidth,windowHeight);
			for (int i=0;i<4;i++) {
				elapsedTimes[i] = 0;
			}
			lastTimeUpdate = new Date().getTime();
			if (theRoot != null) {
				dropTileSound = theRoot.getAudioClip(theRoot.getCodeBase(), "bfms/droptile.au");
			}
		}
		int oldState = -1;
		for (;;) {
			if (exitFlag) {
				break;
			}
			timeNow = new Date().getTime();
			if (timeNow >= (lastTimeUpdate + 1000)) {	/* try to update time display every second */
				if (puzzle && (puzzleCentreX != -1) && !havePuzzleSolution) {
					elapsedTimes[0] += (timeNow - lastTimeUpdate);
				}
				lastTimeUpdate = timeNow;
				refreshTimes = true;
			}
			mainLoopDelay = DEFAULTLOOPDELAY;
			if (gameState == PUZZLE) {
				doPUZZLE();
			} else {
//				System.out.println(playerIDs[0]+"  Invalid gameState! "+gameState);
				systemError(37);
				gameState = UNCONNECTED;
			}
			refreshBars = true;
			refreshBoard = true;
			repaint();
			doDelay(mainLoopDelay);
		}
	}

	private double mySin(double inDegrees) {

		return(Math.sin(inDegrees*Math.PI/180.0));
	}

	private double myCos(double inDegrees) {

		return(Math.cos(inDegrees*Math.PI/180.0));
	}

	private int myRound(double inVal) {

		return((int)(100000.5+inVal)-100000);
	}

	private synchronized void drawSpot(Graphics g, int X, int Y, Color inCol) {

		if (dontPaint || (g == null)) {
			return;
		}
		g.setColor(inCol);
		g.setPaintMode();
		g.fillOval(X-2,Y-2,4,4);
	}

	private synchronized void drawBigSpot(Graphics g, int X, int Y, Color inCol) {

		if (dontPaint || (g == null)) {
			return;
		}
		g.setColor(inCol);
		g.setPaintMode();
		g.fillOval(X-5,Y-5,10,10);
	}

	private synchronized void drawCircle(Graphics g, int X, int Y, Color inCol) {

		if (dontPaint || (g == null)) {
			return;
		}
		g.setColor(inCol);
		g.setPaintMode();
		g.drawOval(X-5,Y-5,10,10);
	}

	private synchronized void drawRightTriangle(Graphics g, int X, int Y, Color inCol) {

		if (dontPaint || (g == null)) {
			return;
		}
		g.setColor(inCol);
		g.setPaintMode();
		g.translate(X,Y);
		g.fillPolygon(rightTriangle);
		g.translate(-X,-Y);
	}

	private synchronized void drawLeftTriangle(Graphics g, int X, int Y, Color inCol) {

		if (dontPaint || (g == null)) {
			return;
		}
		g.setColor(inCol);
		g.setPaintMode();
		g.translate(X,Y);
		g.fillPolygon(leftTriangle);
		g.translate(-X,-Y);
	}

	private synchronized void fillCircle(Graphics g, int X, int Y, Color inCol) {

		if (dontPaint || (g == null)) {
			return;
		}
		g.setColor(inCol);
		g.setPaintMode();
		g.fillOval(X-5,Y-5,10,10);
	}

	private synchronized void clearBoardTile(Graphics g, int X, int Y) {

		if (dontPaint || (g == null)) {
			return;
		}
		g.translate(X,Y);
		g.setColor(Color.white);
		g.fillPolygon(tilePoly[boardScaleIndex]);
		g.drawPolygon(tilePoly[boardScaleIndex]);	
		for (int i=0;i<6;i++) {
			g.drawPolygon(smallArcPoly[boardScaleIndex][i]);
			g.fillPolygon(smallArcPoly[boardScaleIndex][i]);
			g.drawPolygon(bigArcPoly[boardScaleIndex][i]);
			g.fillPolygon(bigArcPoly[boardScaleIndex][i]);
		}
		for (int i=0;i<3;i++) {
			g.drawPolygon(straightPoly[boardScaleIndex][i]);
			g.fillPolygon(straightPoly[boardScaleIndex][i]);
		}
		g.translate(-X,-Y);
	}

	private synchronized void drawTile(Graphics g, int Num, int X, int Y, int Orient, boolean doDark, int useScale, boolean drawBorders, boolean doRed, boolean doYellow, boolean doGreen, boolean doBlue) {

		int tempOrient;

		if (dontPaint || (g == null)) {
			return;
		}
		g.translate(X,Y);

		if (doDark) {
			holdColourBack = Color.gray;
		} else {
			holdColourBack = Color.black;
		}
		g.setColor(holdColourBack);
		g.fillPolygon(tilePoly[useScale]);

		for (int i=0;i<9;i+=3) {
			holdColourMain = holdColourBack;
			if ((tiles[Num][i] == Red) && doRed) {
				holdColourMain = myColours[Red];
			} else if ((tiles[Num][i] == Yellow) && doYellow) {
				holdColourMain = myColours[Yellow];
			} else if ((tiles[Num][i] == Green) && doGreen) {
				holdColourMain = myColours[Green];
			} else if ((tiles[Num][i] == Blue) && doBlue) {
				holdColourMain = myColours[Blue];
			};
			tempOrient = Orient + tiles[Num][i+2];
			while (tempOrient < 0) {
				tempOrient += 6;
			}
			while (tempOrient > 5) {
				tempOrient -= 6;
			}
			if (holdColourMain != holdColourBack) {
				if (tiles[Num][i+1] == ShortArc) {
					g.setColor(holdColourMain);
					g.fillPolygon(smallArcPoly[useScale][tempOrient]);
					if (false || drawBorders) {
						g.setColor(Color.black);
						g.drawPolygon(smallArcPoly[useScale][tempOrient]);
					}
				} else if (tiles[Num][i+1] == LongArc) {
					g.setColor(holdColourMain);
					g.fillPolygon(bigArcPoly[useScale][tempOrient]);
					if (false || drawBorders) {
						g.setColor(Color.black);
						g.drawPolygon(bigArcPoly[useScale][tempOrient]);
					}
				} else if (tiles[Num][i+1] == Straight) {
					if (tempOrient > 2) {
						tempOrient -= 3;
					}
					g.setColor(holdColourMain);
					g.fillPolygon(straightPoly[useScale][tempOrient]);
					if (false || drawBorders) {
						g.setColor(Color.black);
						g.drawPolygon(straightPoly[useScale][tempOrient]);
					}
				}
			}
		}
		if (drawBorders) {
			g.setColor(Color.black);
			g.drawPolygon(tilePoly[useScale]);
		}

		g.translate(-X,-Y);
	}

	private void clearBoard() {

		for (int i=0;i<BoardDimX;i++) {
			for (int j=0;j<BoardDimY;j++) {
				board[i][j] = -1;
				boardOrient[i][j] = 0;
			}
		}
		redrawBoard(true,true,true,true);
	}

	private synchronized void redrawBoard(boolean doRed, boolean doYellow, boolean doGreen, boolean doBlue) {

		if (theBoardGC == null) {
			return;
		}
		theBoardGC.setColor(Color.white);
		theBoardGC.setPaintMode();
		theBoardGC.fillRect(0,0,boardExtentX,boardExtentY);
		for (int i=0;i<BoardDimX;i++) {
			for (int j=0;j<BoardDimY;j++) {
				double xPos = 5+i*PolyParams[boardScaleIndex][1];
				double yPos = 5+j*PolyParams[boardScaleIndex][0]*3.0/2.0;
				if (board[i][j] != -1) {
					drawTile(theBoardGC,board[i][j],myRound(xPos),myRound(yPos),boardOrient[i][j],true,boardScaleIndex,true,doRed,doYellow,doGreen,doBlue);
				} else {
					if ( ((i>0)&&(j>0)) && ( (odd(i) && odd(j)) || (even(i) && even(j)) )  ){
						drawSpot(theBoardGC,myRound(xPos),myRound(yPos),lightBlue);
					}
				}
			}
		}
		if (numberForced != 0) {
			for (int i=0;i<56;i++) {
				if (validBoardPos(forcedTilesX[i],forcedTilesY[i])) {
					if ((board[forcedTilesX[i]][forcedTilesY[i]] == -1) && showForced[i]) {
						double lXPos = 5+forcedTilesX[i]*PolyParams[boardScaleIndex][1];
						double lYPos = 5+forcedTilesY[i]*PolyParams[boardScaleIndex][0]*3.0/2.0;
						drawBigSpot(allFixedGC,myRound(lXPos+boardXOffset),myRound(lYPos+boardYOffset),Color.black);
						drawBigSpot(theBoardGC,myRound(lXPos),myRound(lYPos),Color.black);
					}
				}
			}	
		}
		refreshBoard = true;
	}

	public void update(Graphics g) {

		paint(g);
	}

	public synchronized void paint(Graphics g) {

		if ((dontPaint) || (allFixed == null) || (offScreen == null) || (theBoard == null) || (leftBar == null) || (rightBar == null)) {
			return;
		}
		if (refreshBoard) {
			allFixedGC.drawImage(theBoard,boardXOffset,boardYOffset,this);
			refreshBoard = false;
			refreshBars = true;
		}
		if (puzzle) {
			userMessage(leftBarGC,1,1,(BARWIDTH-2),100,Color.blue,puzzleObject);
		}
		if (refreshBars) {
			allFixedGC.drawImage(leftBar,0,0,this);
			refreshBars = false;
		}
		offScreenGC.drawImage(allFixed,0,0,this);
		offScreenGC.setColor(Color.black);
		offScreenGC.drawLine(BARWIDTH,0,BARWIDTH,gameHeight-1);
		offScreenGC.drawLine(0,0,totalWidth,0);
		offScreenGC.drawLine(0,1,totalWidth,1);
		offScreenGC.drawLine(0,gameHeight-1,totalWidth,gameHeight-1);
		if (touchedPiece != -1) {
			if ((origX+endX-startX) < BARWIDTH) {
				drawTile(offScreenGC, touchedPiece, myRound(origX+endX-startX), myRound(origY+endY-startY), touchedOrient, true, UnityScaleIndex, true,true,true,true,true);
			} else {
				drawTile(offScreenGC, touchedPiece, myRound(origX+endX-startX), myRound(origY+endY-startY), touchedOrient, true, boardScaleIndex, true,true,true,true,true);
			}
		}
		g.drawImage(offScreen,0,gameVOffset,this);
	}

	private void eraseBoardPoly(int xCoord, int yCoord) {

		if ((allFixedGC == null) || (theBoardGC == null)) {
			return;
		}
		double xPos = 5+xCoord*PolyParams[boardScaleIndex][1];
		double yPos = 5+yCoord*PolyParams[boardScaleIndex][0]*3.0/2.0;
		clearBoardTile(allFixedGC,myRound(xPos+boardXOffset),myRound(yPos+boardYOffset));
		clearBoardTile(theBoardGC,myRound(xPos),myRound(yPos));
	}

	private boolean validBoardPos(int inX, int inY) {

		return(!((inX < 1) || (inX >= BoardDimX) || (inY < 1) || (inY >= BoardDimY)));
	}

	private Point getBoardCoords(int inX, int inY) {

		int closestX = myRound((inX-boardXOffset-5.0)/(PolyParams[boardScaleIndex][1]));
		int closestY = myRound((inY-boardYOffset-5)*2.0/(3.0*PolyParams[boardScaleIndex][0]));
		if ((even(closestX)&&odd(closestY)) || (odd(closestX)&&even(closestY))) {
			double bestDistance = 9999999.0;
			int correctX = 1, correctY = 1;
			for (int i=-1;i<2;i++) {
				for (int j=-1;j<2;j++) {
					if (odd(i+j)) {
						double xPos = ((closestX+i)*PolyParams[boardScaleIndex][1]) - (inX-boardXOffset-5);
						double yPos = ((closestY+j)*PolyParams[boardScaleIndex][0]*3.0/2.0) - (inY-boardYOffset-5);
						if ((xPos*xPos + yPos*yPos) < bestDistance) {
							bestDistance = xPos*xPos + yPos*yPos;
							correctX = closestX+i;
							correctY = closestY+j;
						}
					}
				}
			}
			closestX = correctX;
			closestY = correctY;
		}
		if (!validBoardPos(closestX, closestY)) {
			closestX = -1;
			closestY = -1;
		}
		return(new Point(closestX, closestY));
	}

	public boolean handleEvent(Event e) {

		int eventY = e.y - gameVOffset;
		if (e.id == Event.MOUSE_DOWN) {
			mouseDownFlag = true;
			if (e.x < BARWIDTH) {
				if ((e.x>buttLefts[0])&&(e.x<buttRights[0])&&(eventY>buttTops[0])&&(eventY<buttBottoms[0])) {
					drawingSelectiveColours = true;
					redrawBoard(true,false,false,false);
				} else if ((e.x>buttLefts[1])&&(e.x<buttRights[1])&&(eventY>buttTops[1])&&(eventY<buttBottoms[1])) {
					drawingSelectiveColours = true;
					redrawBoard(false,true,false,false);
				} else if ((e.x>buttLefts[2])&&(e.x<buttRights[2])&&(eventY>buttTops[2])&&(eventY<buttBottoms[2])) {
					drawingSelectiveColours = true;
					redrawBoard(false,false,true,false);
				} else if ((e.x>buttLefts[3])&&(e.x<buttRights[3])&&(eventY>buttTops[3])&&(eventY<buttBottoms[3])) {
					drawingSelectiveColours = true;
					redrawBoard(false,false,false,true);
				} else if ((e.x>SmallZLeft)&&(e.x<SmallZRight)&&(eventY>SmallZTop)&&(eventY<SmallZBottom)) {
					if (boardScaleIndex > 0) {
						boardScaleIndex -= 1;
						boardXOffset = myRound(totalWidth/2.0 - (((totalWidth/2.0 - boardXOffset) * ScaleFactors[boardScaleIndex])/ScaleFactors[boardScaleIndex+1]));
						boardYOffset = myRound(gameHeight/2.0 - (((gameHeight/2.0 - boardYOffset) * ScaleFactors[boardScaleIndex])/ScaleFactors[boardScaleIndex+1]));
						if (gameHeight != computeGameHeight(windowHeight,computeChatHeight(windowHeight))) {
							reshape(0,0,windowWidth,windowHeight);
						} else if (totalWidth != computeTotalWidth(windowWidth)) {
							reshape(0,0,windowWidth,windowHeight);
						}
						redrawBoard(true,true,true,true);
						setMinOffsets();
						limitOffsets();
						repaint();
					}
				} else if ((e.x>BigZLeft)&&(e.x<BigZRight)&&(eventY>BigZTop)&&(eventY<BigZBottom)) {
					if (boardScaleIndex < TopBoardScaleIndex) {
						boardScaleIndex += 1;
						boardXOffset = myRound(totalWidth/2.0 - (((totalWidth/2.0 - boardXOffset) * ScaleFactors[boardScaleIndex])/ScaleFactors[boardScaleIndex-1]));
						boardYOffset = myRound(gameHeight/2.0 - (((gameHeight/2.0 - boardYOffset) * ScaleFactors[boardScaleIndex])/ScaleFactors[boardScaleIndex-1]));
						if (gameHeight != computeGameHeight(windowHeight,computeChatHeight(windowHeight))) {
							reshape(0,0,windowWidth,windowHeight);
						} else if (totalWidth != computeTotalWidth(windowWidth)) {
							reshape(0,0,windowWidth,windowHeight);
						}
						redrawBoard(true,true,true,true);
						setMinOffsets();
						limitOffsets();
						repaint();
					}
				}
			} else if ((e.x > BARWIDTH) && (e.x < (totalWidth-1)) && (eventY > 0) && (eventY < gameHeight)) {
				startX = e.x;
				startY = eventY;
				grabbedPiece = -1;
				touchedPiece = -1;
				boolean notFound = true;
				Point boardPoint = getBoardCoords(e.x,eventY);
				int closestX = boardPoint.x;
				int closestY = boardPoint.y;
				if ((closestX != -1) && (closestY != -1)) {
					if (board[closestX][closestY] != -1) {
						touchedPiece = board[closestX][closestY];
						touchedOrient = boardOrient[closestX][closestY];
						origX = 5+closestX*PolyParams[boardScaleIndex][1]+boardXOffset;
						origY = 5+closestY*PolyParams[boardScaleIndex][0]*3.0/2.0+boardYOffset;
						bOrigX = closestX;
						bOrigY = closestY;
						refreshMoving = true;
						endX = e.x;
						endY = eventY;
						eraseBoardPoly(closestX, closestY);
						drawSpot(theBoardGC,myRound(origX-boardXOffset),myRound(origY-boardYOffset),lightBlue);
						drawSpot(allFixedGC,myRound(origX),myRound(origY),lightBlue);
						notFound = false;
					}
				}
				if (notFound) {
					movingBoard = true;
					origX = boardXOffset;
					origY = boardYOffset;
				}
			}
		} else if (e.id == Event.MOUSE_DRAG) {
			refreshMoving = false;
			if ((touchedPiece != -1) && !translateMotion) {
				endX = startX;
				endY = startY;
				if (((e.x-startX)*(e.x-startX)+(eventY-startY)*(eventY-startY)) > MoveThreshold) {
					grabbedPiece = touchedPiece;
					if (startX > BARWIDTH) {
						board[bOrigX][bOrigY] = -1;
						boardOrient[bOrigX][bOrigY] = 0;
					}
					translateMotion = true;
				}
			}
			if (grabbedPiece != -1) {
				if (translateMotion) {
					endX = e.x;
					endY = eventY;
				}
				refreshMoving = true;
				repaint();
			}
			if (movingBoard) {
				boardXOffset = myRound(origX + e.x - startX);
				boardYOffset = myRound(origY + eventY - startY);
				limitOffsets();
				refreshBoard = true;
				repaint();
			}
		} else if (e.id == Event.MOUSE_UP) {
			mouseDownFlag = false;
			if (touchedPiece != -1) {
				playTileDropSound = true;
				validBoardPosition = true;
				boolean didForceCheck = false;
				boolean didIt = false;
				if (translateMotion) {
					if ((e.x > BARWIDTH) && (e.x < totalWidth) && (eventY > 0) && (eventY < gameHeight)) {
						Point boardPoint = getBoardCoords(e.x, eventY);
						int closestX = boardPoint.x;
						int closestY = boardPoint.y;
						puzzleCentreX = closestX;
						puzzleCentreY = closestY;
						if ((closestX != -1) && (closestY != -1)) {
							if (board[closestX][closestY] == -1) {
								board[closestX][closestY] = touchedPiece;
								boardOrient[closestX][closestY] = touchedOrient;
								if (doAutoRotate) {
									int spin = 0;
									validBoardPosition = validSides(closestX,closestY);
									while ((spin < 6) && !validBoardPosition) {
										spin++;
										boardOrient[closestX][closestY] = myMod(touchedOrient + spin,6);
										validBoardPosition = validSides(closestX,closestY);
									}
								}
								double xPos = 5+closestX*PolyParams[boardScaleIndex][1];
								double yPos = 5+closestY*PolyParams[boardScaleIndex][0]*3.0/2.0;
								drawTile(allFixedGC,grabbedPiece,myRound(xPos+boardXOffset),myRound(yPos+boardYOffset),boardOrient[closestX][closestY],true,boardScaleIndex,true,true,true,true,true);
								drawTile(theBoardGC,grabbedPiece,myRound(xPos),myRound(yPos),boardOrient[closestX][closestY],true,boardScaleIndex,true,true,true,true,true);
								tilePos[touchedPiece][0] = closestX;
								tilePos[touchedPiece][1] = closestY;
								tileOrientation[touchedPiece] = boardOrient[closestX][closestY];
								invalid_edges = !validSides(closestX,closestY);
								validBoardPosition = validSides(closestX,closestY);
								if (!validBoardPosition) {
									sendHint = true;
								}
								didForceCheck = true;
								didIt = true;
							}
						}
					}
				} else {
					if (e.x > origX) {
						touchedOrient += 1;
					} else {
						touchedOrient -= 1;
					}
				}
				if (!didIt) {
					drawTile(theBoardGC,touchedPiece,myRound(origX-boardXOffset),myRound(origY-boardYOffset),touchedOrient,true,boardScaleIndex,true,true,true,true,true);
					drawTile(allFixedGC,touchedPiece,myRound(origX),myRound(origY),touchedOrient,true,boardScaleIndex,true,true,true,true,true);
					board[bOrigX][bOrigY] = touchedPiece;
					puzzleCentreX = bOrigX;
					puzzleCentreY = bOrigY;
					boardOrient[bOrigX][bOrigY] = touchedOrient;
					invalid_edges = !validSides(bOrigX,bOrigY);
					validBoardPosition = validSides(bOrigX,bOrigY);
					if (!validBoardPosition) {
						sendHint = true;
					}
					tilePos[touchedPiece][0] = bOrigX;
					tilePos[touchedPiece][1] = bOrigY;
					tileOrientation[touchedPiece] = touchedOrient;
				}
				grabbedPiece = -1;
				touchedPiece = -1;
				lastComputeScores = 0;
				refreshBars = true;
				repaint();
			} else if (drawingSelectiveColours) {
				redrawBoard(true,true,true,true);
				drawingSelectiveColours = false;
			}
			refreshMoving = false;
			translateMotion = false;
			movingBoard = false;
		}
		return(super.handleEvent(e));
	}
}