#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/termio.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stropts.h>
#include <signal.h>
#include <unistd.h>

#define MAXCLIENTS 200
#define MAXSESSIONS 100
#define MAXWAITING 10
#define MAXCLIENTTIME 3600	/* maximum idle time while playing is 1 hour */
#define MAXWAITINGTIME 300	/* maximum idle time while waiting is 5 min. */
#define BUFFSIZE 128
#define BUFFSIZE2 126
#define SecondsInMinute 60.0
#define SecondsInHour 3600.0
#define SecondsInDay 86400.0
#define SecondsInYear 31536000.0

static int portNum;
static int sessionCtr;
static char password[BUFFSIZE];

					/* socket descriptors */
static int serversd, clients[MAXCLIENTS], waiting[MAXWAITING];
static time_t clientTimes[MAXCLIENTS];
static time_t waitingTimes[MAXWAITING];
static time_t tempTime;
static int refusing;
static int sessions[MAXCLIENTS];
static struct sockaddr_in client;        /* socket addresses */
static fd_set rfds,efds;        /* file descriptor sets */
static int numWaiting = 0;
static int IP1,IP2,IP3,IP4;
static char configFile[BUFFSIZE];
static char sessionURLs[MAXSESSIONS][BUFFSIZE];
static char neighbourURLs[MAXSESSIONS][4][BUFFSIZE];

/*-----------------------------------------------------------------*/

double myDifftime(time1, time2)

  time_t time1;
  time_t time2;
{
  struct tm *tempT;
  struct tm gmtime1, gmtime2;

  tempT = gmtime(&time1);
  gmtime1.tm_year = tempT->tm_year;
  gmtime1.tm_yday = tempT->tm_yday;
  gmtime1.tm_hour = tempT->tm_hour;
  gmtime1.tm_min = tempT->tm_min;
  gmtime1.tm_sec = tempT->tm_sec;
  tempT = gmtime(&time2);
  gmtime2.tm_year = tempT->tm_year;
  gmtime2.tm_yday = tempT->tm_yday;
  gmtime2.tm_hour = tempT->tm_hour;
  gmtime2.tm_min = tempT->tm_min;
  gmtime2.tm_sec = tempT->tm_sec;
  return(SecondsInYear*(gmtime1.tm_year-gmtime2.tm_year) + SecondsInDay*(gmtime1.tm_yday-gmtime2.tm_yday) + SecondsInHour*(gmtime1.tm_hour-gmtime2.tm_hour) + SecondsInMinute*(gmtime1.tm_min-gmtime2.tm_min) + (gmtime1.tm_sec-gmtime2.tm_sec));
}

/*-----------------------------------------------------------------*/

void    error(inStr, err)
char *inStr;
int err; {       /* reports fatal errors */

  fprintf(stderr, "%s %d.\n", inStr, err);
  exit(1);
}

/*-----------------------------------------------------------------*/

void    error2(inStr)
char *inStr; {       /* reports fatal errors */

  fprintf(stderr, "%s.\n", inStr);
  exit(1);
}

/*-----------------------------------------------------------------*/

void mybcopy(theSrc, theDst, length)
char *theSrc;
struct in_addr *theDst;
int length; {

	char *src, *dst;
	int loopCounter;

	src = theSrc;
	dst = (char *)theDst;

	for (loopCounter=0;loopCounter<length;loopCounter++)
		dst[loopCounter] = src[loopCounter];
}

/*-----------------------------------------------------------------*/

static void client_socket_init(portNum)
int portNum; {

  struct hostent *hp;
  int loopCtr;
  char mname[64];

  if (gethostname(mname,64) <0)
    error("Failed gethostname",errno);
  signal(SIGPIPE,SIG_IGN);
  hp = gethostbyname(mname);
  if (!hp)
    error("Failed gethostbyname",errno);
  if (hp->h_addrtype != AF_INET)
    error2("Address type not AF_INET");
  serversd = socket(AF_INET,SOCK_STREAM,0);
  if (serversd == -1)
    error("Failed socket",errno);
  for (loopCtr=0;loopCtr<8;loopCtr++) {
    client.sin_zero[loopCtr] = 0;
  }
/*
  mybcopy(hp->h_addr,&client.sin_addr,hp->h_length);
*/
  client.sin_addr.s_addr = (u_long)(IP1*16777216) + (u_long)(IP2*65536) + (u_long)(IP3*256) + (u_long)(IP4);
  client.sin_family = AF_INET;
  client.sin_port = portNum;
  if (bind(serversd,(struct sockaddr *)&client,sizeof(client)) == -1)
    {error("Failed bind",errno);
    };
  if (listen(serversd,4) == -1)
    error("Failed listen",errno);
  fprintf(stderr,"Server on %s, address %d.%d.%d.%d, using port %d.\n", mname, IP1, IP2, IP3, IP4, portNum);
}

/*--------------------------------------------------------------------*/

void doEcho(source, toSource, toOthers, ignoreF)
int source;
char *toSource;
char *toOthers;
int ignoreF; {

  int sLCtr, writeResult;
  int len1, len2;
  int affectedSession;

  len1 = strlen(toSource);
  toSource[len1+1] = 13;
  toSource[len1+2] = 10;
  len1 += 3;
  len2 = strlen(toOthers);
  toOthers[len2+1] = 13;
  toOthers[len2+2] = 10;
  len2 += 3;
  if (clients[source] != -1) {
    writeResult = write(clients[source], &toSource[0], len1);
    if (writeResult < 0) {
      fprintf(stderr, "Closing stream for %d.\n",source+1);
      close(clients[source]);
      clients[source] = -1;
    }
  }
  affectedSession = sessions[source];
  if ((clients[source] != -1)  || (ignoreF == 1)){
    for (sLCtr=0;sLCtr<MAXCLIENTS;sLCtr++) {
      if (clients[sLCtr] != -1) {
        if (sessions[sLCtr] == affectedSession) {
          if (sLCtr != source) {
            writeResult = write(clients[sLCtr], &toOthers[0], len2);
            if (writeResult < 0) {
              fprintf(stderr, "Closing stream for %d.\n",sLCtr+1);
              close(clients[sLCtr]);
              clients[sLCtr] = -1;
            }
          }
        }
      }
    }
  }
}

/*--------------------------------------------------------------------*/

void sendSingleW(inStr, theNum)
char *inStr;
int theNum; {

  inStr[strlen(inStr)+1] = 13;
  inStr[strlen(inStr)+2] = 10;
  if (write(waiting[theNum], inStr, strlen(inStr)+3) < 0) {
    fprintf(stderr, "Closing stream for waiting %d.\n",theNum+1);
    close(waiting[theNum]);
    waiting[theNum] = -1;
  }
}

/*--------------------------------------------------------------------*/

void sendSingleC(inStr, theNum)
char *inStr;
int theNum; {

  inStr[strlen(inStr)+1] = 13;
  inStr[strlen(inStr)+2] = 10;
  if (write(clients[theNum], inStr, strlen(inStr)+3) < 0) {
    fprintf(stderr, "Closing stream for client %d.\n",theNum+1);
    close(clients[theNum]);
    clients[theNum] = -1;
  }
}

/*--------------------------------------------------------------------*/

void saveConfig() {

  int i, clientCounter, numInSession;
  FILE *tempfp;

  tempfp = fopen(configFile,"w");
  if (tempfp != NULL) {
    fprintf(tempfp,"%d.%d.%d.%d\n",IP1,IP2,IP3,IP4);
    fprintf(tempfp,"%d\n",portNum);
    fprintf(tempfp,"%s\n",password);
    clientCounter = 0;
    for (i=0;i<=sessionCtr;i++) {
      numInSession = 0;
      while (sessions[clientCounter] == i) {
        numInSession += 1;
        clientCounter += 1;
      }
      fprintf(tempfp,"%s %d\n",sessionURLs[i],numInSession);
      if (neighbourURLs[i][0][0] != 0) {
        fprintf(tempfp,"up %s\n",neighbourURLs[i][0]);
      }
      if (neighbourURLs[i][1][0] != 0) {
        fprintf(tempfp,"left %s\n",neighbourURLs[i][1]);
      }
      if (neighbourURLs[i][2][0] != 0) {
        fprintf(tempfp,"down %s\n",neighbourURLs[i][2]);
      }
      if (neighbourURLs[i][3][0] != 0) {
        fprintf(tempfp,"right %s\n",neighbourURLs[i][3]);
      }
    }
    fclose(tempfp);
  }
}


/*--------------------------------------------------------------------*/

void main(argc, argv)
int argc;
char **argv; {

  int sent;
  int fl, amountRead, doneReading, filesize, loopCtr, readResult;
  int sLen1, sLen2;
  int tempInt;
  int theOne, foundOne, sessionNum;
  int currentSocketNum, nextSocketNum, writeResult;
  int currSess, sockCtr, numActive, numPoss;
  char dB[BUFFSIZE];
  char xB[BUFFSIZE];
  char tempString[BUFFSIZE];
  char oldPass[BUFFSIZE];
  char newPass[BUFFSIZE];
  FILE *infp;

  if (argc != 2) {
    fprintf(stderr, "<echoServer command> <configFile>\n");
    exit(1);
  }
  password[0] = 0;
  for (loopCtr=0;loopCtr<MAXSESSIONS;loopCtr++) {
    sessionURLs[loopCtr][0] = 0;
    neighbourURLs[loopCtr][0][0] = 0;
    neighbourURLs[loopCtr][1][0] = 0;
    neighbourURLs[loopCtr][2][0] = 0;
    neighbourURLs[loopCtr][3][0] = 0;
  };
  strcpy(configFile,argv[1]);
  infp = fopen(argv[1],"r");
  if (!infp)
    error2("Couldn't open config file");
  if (fscanf(infp,"%d.%d.%d.%d",&IP1,&IP2,&IP3,&IP4) != 4) {
    fclose(infp);
    error2("Couldn't find IP address in config file");
  };
  if (fscanf(infp,"%d",&portNum) != 1) {
    fclose(infp);
    error2("Couldn't find port number in config file");
  };
  client_socket_init(portNum);
  if (fscanf(infp,"%s",password) != 1) {
    fclose(infp);
    error2("Couldn't find password in config file");
  };
  for (loopCtr=0;loopCtr<MAXCLIENTS;loopCtr++) {
    clients[loopCtr] = -1;
    sessions[loopCtr] = -1;
  };
  sessionCtr = -1;
  currentSocketNum = 0;
  nextSocketNum = 0;
  while (fscanf(infp,"%s ",&tempString) == 1) {
    if (strcmp(tempString,"up") == 0) {
      if (sessionCtr == -1) {
        fclose(infp);
        error2("Neighbour specified before session URL");
      };
      if (fscanf(infp,"%s",&neighbourURLs[sessionCtr][0]) != 1) {
        fclose(infp);
        error2("Up neighbour URL couldn't be read");
      };
    } else if (strcmp(tempString,"left") == 0) {
      if (sessionCtr == -1) {
        fclose(infp);
        error2("Neighbour specified before session URL");
      };
      if (fscanf(infp,"%s",&neighbourURLs[sessionCtr][1]) != 1) {
        fclose(infp);
        error2("Left neighbour URL couldn't be read");
      };
    } else if (strcmp(tempString,"down") == 0) {
      if (sessionCtr == -1) {
        fclose(infp);
        error2("Neighbour specified before session URL");
      };
      if (fscanf(infp,"%s",&neighbourURLs[sessionCtr][2]) != 1) {
        fclose(infp);
        error2("Down neighbour URL couldn't be read");
      };
    } else if (strcmp(tempString,"right") == 0) {
      if (sessionCtr == -1) {
        fclose(infp);
        error2("Neighbour specified before session URL");
      };
      if (fscanf(infp,"%s",&neighbourURLs[sessionCtr][3]) != 1) {
        fclose(infp);
        error2("Right neighbour URL couldn't be read");
      };
    } else {
      if (sessionCtr >= 0) {
        fprintf(stderr, "Session %d created for users %d through %d.\n", sessionCtr,currentSocketNum+1,nextSocketNum);
        fprintf(stderr, "Session URL is '%s'.\n", sessionURLs[sessionCtr]);
        if (strlen(neighbourURLs[sessionCtr][0]) > 0)
          fprintf(stderr, "Up URL is '%s'.\n", neighbourURLs[sessionCtr][0]);
        if (strlen(neighbourURLs[sessionCtr][1]) > 0)
          fprintf(stderr, "Left URL is '%s'.\n", neighbourURLs[sessionCtr][1]);
        if (strlen(neighbourURLs[sessionCtr][2]) > 0)
          fprintf(stderr, "Down URL is '%s'.\n", neighbourURLs[sessionCtr][2]);
        if (strlen(neighbourURLs[sessionCtr][3]) > 0)
          fprintf(stderr, "Right URL is '%s'.\n", neighbourURLs[sessionCtr][3]);
      };
      sessionCtr = sessionCtr + 1;
      if (sessionCtr >= MAXSESSIONS) {
        fclose(infp);
        error("Exceeded maximum number of sessions; max value is ",MAXSESSIONS);
      };
      strcpy(sessionURLs[sessionCtr],tempString);
      if (fscanf(infp,"%d",&tempInt) != 1) {
        fclose(infp);
        error2("Error reading number of users for this session");
      };
      currentSocketNum = nextSocketNum;
      nextSocketNum = currentSocketNum + tempInt;
      if (nextSocketNum > MAXCLIENTS) {
        fclose(infp);
        error("Exceeded maximum number of users; max value is ",MAXCLIENTS);
      };
      for (loopCtr=currentSocketNum;loopCtr<nextSocketNum;loopCtr++) {
        clients[loopCtr] = -1;
        sessions[loopCtr] = sessionCtr;
      };
    };
  }
  if (sessionCtr >= 0) {
    fprintf(stderr, "Session %d created for users %d through %d.\n", sessionCtr,currentSocketNum+1,nextSocketNum);
    fprintf(stderr, "Session URL is '%s'.\n", sessionURLs[sessionCtr]);
    if (strlen(neighbourURLs[sessionCtr][0]) > 0)
      fprintf(stderr, "Up URL is '%s'.\n", neighbourURLs[sessionCtr][0]);
    if (strlen(neighbourURLs[sessionCtr][1]) > 0)
      fprintf(stderr, "Left URL is '%s'.\n", neighbourURLs[sessionCtr][1]);
    if (strlen(neighbourURLs[sessionCtr][2]) > 0)
      fprintf(stderr, "Down URL is '%s'.\n", neighbourURLs[sessionCtr][2]);
    if (strlen(neighbourURLs[sessionCtr][3]) > 0)
      fprintf(stderr, "Right URL is '%s'.\n", neighbourURLs[sessionCtr][3]);
  };
  for (loopCtr=0;loopCtr<MAXWAITING;loopCtr++) {
    waiting[loopCtr] = -1;
  };
  fclose(infp);
  for(;;) {
    FD_ZERO(&rfds);
    FD_ZERO(&efds);
    FD_SET(serversd,&rfds);
    FD_SET(serversd,&efds);
    for (loopCtr=0;loopCtr<MAXCLIENTS;loopCtr++) {
      if (clients[loopCtr] != -1) {
        FD_SET(clients[loopCtr],&rfds);
        FD_SET(clients[loopCtr],&efds);
      }
    }
    for (loopCtr=0;loopCtr<MAXWAITING;loopCtr++) {
      if (waiting[loopCtr] != -1) {
        FD_SET(waiting[loopCtr],&rfds);
        FD_SET(waiting[loopCtr],&efds);
      }
    }
    while (select(255,&rfds,(fd_set *)0,&efds,(struct timeval *)0) == -1) {
      if (errno != EINTR) {
        error("Failed select",errno);
      }
    }
    if (FD_ISSET(serversd,&efds)) {
      error("Server socket exception", errno);
    }
    tempTime = time(NULL);
    for (loopCtr=0;loopCtr<MAXCLIENTS;loopCtr++) {
      if (clients[loopCtr] != -1) {
        if (FD_ISSET(clients[loopCtr],&efds)) {
          sprintf(xB,"221");
          sprintf(dB,"223 %d",loopCtr+1);
          doEcho(loopCtr,xB,dB,1);
          close(clients[loopCtr]);
          clients[loopCtr] = -1;
        } else if (myDifftime(tempTime, clientTimes[loopCtr]) > MAXCLIENTTIME) {
          sprintf(xB,"221");
          sprintf(dB,"223 %d",loopCtr+1);
          doEcho(loopCtr,xB,dB,1);
          close(clients[loopCtr]);
          clients[loopCtr] = -1;
        }
      }
    }
    for (loopCtr=0;loopCtr<MAXWAITING;loopCtr++) {
      if (waiting[loopCtr] != -1) {
        if (FD_ISSET(waiting[loopCtr],&efds)) {
          close(waiting[loopCtr]);
          waiting[loopCtr] = -1;
        } else if (myDifftime(tempTime, waitingTimes[loopCtr]) > MAXWAITINGTIME) {
          close(waiting[loopCtr]);
          waiting[loopCtr] = -1;
        }
      }
    }
    if (FD_ISSET(serversd,&rfds)) {      /* accept new connection */
      fl = sizeof(client);
      theOne = -1;
      foundOne = 0;
      while (foundOne == 0) {
        theOne = theOne + 1;
        if (theOne == MAXWAITING) {
          foundOne = 1;
          continue;
        };
        if (waiting[theOne] == -1) {
          foundOne = 1;
        };
      };
      if (theOne != MAXWAITING) {
        waiting[theOne] = accept(serversd,(struct sockaddr *)&client,&fl);
        if (waiting[theOne] == -1) {
          fprintf(stderr,"Connection attempted, accept failed.\n");
        } else if (fcntl(waiting[theOne],F_SETFL,FSYNC)<0) {
          waiting[theOne] = -1;
          fprintf(stderr,"Connection attempted, fcntl failed.\n");
        } else {
          fprintf(stderr, "Call %d queued to join a session.\n", theOne+1);
          waitingTimes[theOne] = time(NULL);
        }
      } else {
        refusing = accept(serversd,(struct sockaddr *)&client,&fl);
        strcpy(tempString,"Sorry");
        tempString[6] = 13;
        tempString[7] = 10;
        writeResult = write(refusing, tempString, 8);
        close(refusing);
        fprintf(stderr, "No space for more connections.\n");
      }
    }
    for (loopCtr=0;loopCtr<MAXWAITING;loopCtr++) {
      if (waiting[loopCtr] != -1) {
        if (FD_ISSET(waiting[loopCtr],&rfds) != 0) {
          amountRead = 0;
          doneReading = 0;
          while (doneReading == 0) {
            readResult = read(waiting[loopCtr], &dB[amountRead], 1);
            if (dB[amountRead] == 10) {
              dB[amountRead] = 0;
              doneReading = 1;
            }
            amountRead++;
            if ((readResult == -1) || (amountRead >= (BUFFSIZE-2))) {
              if (waiting[loopCtr] != -1) {
                close (waiting[loopCtr]);
                waiting[loopCtr] = -1;
              }
              amountRead = 0;
              doneReading = 1;
            }
          }
          if (amountRead != 0) {
            waitingTimes[loopCtr] = time(NULL);
            sent = 0;
            if (strncmp(dB,"200",3) == 0) {
              if (sscanf(&dB[3],"%d",&sessionNum) == 1) {
                theOne = -1;
                foundOne = 0;
                while (foundOne == 0) {
                  theOne = theOne + 1;
                  if (theOne == MAXCLIENTS) {
                    foundOne = 1;
                    continue;
                  };
                  if ((sessions[theOne] == sessionNum) && (clients[theOne] == -1)) {
                    foundOne = 1;
                  };
                };
                if (theOne != MAXCLIENTS) {
                  clients[theOne] = waiting[loopCtr];
                  waiting[loopCtr] = -1;
                  sprintf(xB,"201 %d %d",sessionNum,theOne+1);
                  sprintf(dB,"203 %d",theOne+1);
                  doEcho(theOne,xB,dB,0);
                  fprintf(stderr, "%d from queue is now client %d in session %d.\n", loopCtr+1,theOne+1,sessionNum);
                  clientTimes[theOne] = time(NULL);
                  FD_CLR(clients[theOne],&rfds);
                  FD_CLR(clients[theOne],&efds);
                  sent = 1;
                } else {
                  sprintf(xB,"201 %d 000",sessionNum);
                  sendSingleW(xB,loopCtr);
                  sent = 1;
                }
              }
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"220",3) == 0) {
              fprintf(stderr, "Closing stream for waiting %d.\n",loopCtr+1);
              close(waiting[loopCtr]);
              waiting[loopCtr] = -1;
            } else if (strncmp(dB,"300",3) == 0) {
              if (sscanf(&dB[3],"%s %s",&oldPass,&newPass) == 2) {
                if (strcmp(oldPass,password) == 0) {
                  if ((strlen(newPass) > 5) && (strlen(newPass) < 16)) {
                    strcpy(password,newPass);
                    saveConfig();
                    sprintf(xB,"301 %s",password);
                    sendSingleW(xB, loopCtr);
                    sent = 1;
                  };
                };
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"302",3) == 0) {
              sprintf(xB,"303 %d",sessionCtr+1);
              sendSingleW(xB, loopCtr);
            } else if (strncmp(dB,"304",3) == 0) {
              sockCtr = 0;
              currSess = sessions[sockCtr];
              numPoss = 0;
              numActive = 0;
              while (sessions[sockCtr] != -1) {
                if (sessions[sockCtr] != currSess) {
                  sprintf(xB,"305 %d %d %d",currSess,numActive,numPoss);
                  sendSingleW(xB, loopCtr);
                  currSess = sessions[sockCtr];
                  numPoss = 0;
                  numActive = 0;
                };
                numPoss = numPoss + 1;
                if (clients[sockCtr] != -1) {
                  numActive = numActive + 1;
                };
                sockCtr = sockCtr + 1;
              }
              sprintf(xB,"305 %d %d %d",currSess,numActive,numPoss);
              sendSingleW(xB, loopCtr);
            } else if (strncmp(dB,"306",3) == 0) {
              if (sscanf(&dB[3],"%d",&sessionNum) == 1) {
                sent = 1;
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"310",3) == 0) {
              if (sscanf(&dB[3],"%d",&sessionNum) == 1) {
                sprintf(xB,"311 %s",sessionURLs[sessionNum]);
                sendSingleW(xB, loopCtr);
                sent = 1;
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"312",3) == 0) {
              if (sscanf(&dB[3],"%d",&sessionNum) == 1) {
                sprintf(xB,"313 %s",neighbourURLs[sessionNum][0]);
                sendSingleW(xB, loopCtr);
                sent = 1;
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"314",3) == 0) {
              if (sscanf(&dB[3],"%d",&sessionNum) == 1) {
                sprintf(xB,"315 %s",neighbourURLs[sessionNum][1]);
                sendSingleW(xB, loopCtr);
                sent = 1;
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"316",3) == 0) {
              if (sscanf(&dB[3],"%d",&sessionNum) == 1) {
                sprintf(xB,"317 %s",neighbourURLs[sessionNum][2]);
                sendSingleW(xB, loopCtr);
                sent = 1;
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"318",3) == 0) {
              if (sscanf(&dB[3],"%d",&sessionNum) == 1) {
                sprintf(xB,"319 %s",neighbourURLs[sessionNum][3]);
                sendSingleW(xB, loopCtr);
                sent = 1;
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"320",3) == 0) {
              if (sscanf(&dB[3],"%s %d %s",&newPass,&sessionNum,&tempString) == 3) {
                if (strcmp(newPass,password) == 0) {
                  if ((sessionNum >= 0) && (sessionNum <= sessionCtr)) {
                    strcpy(sessionURLs[sessionNum],tempString);
                    saveConfig();
                    sprintf(xB,"321 %d %s",sessionNum,sessionURLs[sessionNum]);
                    sendSingleW(xB, loopCtr);
                    sent = 1;
                  };
                };
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"322",3) == 0) {
              if (sscanf(&dB[3],"%s %d %s",&newPass,&sessionNum,&tempString) == 3) {
                if (strcmp(newPass,password) == 0) {
                  if ((sessionNum >= 0) && (sessionNum <= sessionCtr)) {
                    strcpy(neighbourURLs[sessionNum][0],tempString);
                    saveConfig();
                    sprintf(xB,"323 %d %s",sessionNum,neighbourURLs[sessionNum][0]);
                    sendSingleW(xB, loopCtr);
                    sent = 1;
                  };
                };
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"324",3) == 0) {
              if (sscanf(&dB[3],"%s %d %s",&newPass,&sessionNum,&tempString) == 3) {
                if (strcmp(newPass,password) == 0) {
                  if ((sessionNum >= 0) && (sessionNum <= sessionCtr)) {
                    strcpy(neighbourURLs[sessionNum][1],tempString);
                    saveConfig();
                    sprintf(xB,"325 %d %s",sessionNum,neighbourURLs[sessionNum][1]);
                    sendSingleW(xB, loopCtr);
                    sent = 1;
                  };
                };
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"326",3) == 0) {
              if (sscanf(&dB[3],"%s %d %s",&newPass,&sessionNum,&tempString) == 3) {
                if (strcmp(newPass,password) == 0) {
                  if ((sessionNum >= 0) && (sessionNum <= sessionCtr)) {
                    strcpy(neighbourURLs[sessionNum][2],tempString);
                    saveConfig();
                    sprintf(xB,"327 %d %s",sessionNum,neighbourURLs[sessionNum][2]);
                    sendSingleW(xB, loopCtr);
                    sent = 1;
                  };
                };
              };
              if (sent == 0) {
                sprintf(xB,"999 %s",dB);
                sendSingleW(xB,loopCtr);
              }
            } else if (strncmp(dB,"328",3) == 0) {
              if (sscanf(&dB[3],"%s %d %s",&newPass,&sessionNum,&tempString) == 3) {
                if (strcmp(newPass,password) == 0) {
                  if ((sessionNum >= 0) && (sessionNum <= sessionCtr)) {
                    strcpy(neighbourURLs[sessionNum][3],tempString);
                    saveConfig();
                    sprintf(xB,"328 %d %s",sessionNum,neighbourURLs[sessionNum][3]);
                    sendSingleW(xB, loopCtr);
                  };
                };
              };
            } else {
              sprintf(xB,"999 %s",dB);
              sendSingleW(xB, loopCtr);
            }
          }
        }
      }
    }
    for (loopCtr=0;loopCtr<MAXCLIENTS;loopCtr++) {
      if (clients[loopCtr] != -1) {
        if (FD_ISSET(clients[loopCtr],&rfds) != 0) {
          amountRead = 0;
          doneReading = 0;
          sprintf(dB,"220");
          while (doneReading == 0) {
            readResult = read(clients[loopCtr], &dB[amountRead], 1);
            if (dB[amountRead] == 10) {
              dB[amountRead] = 0;
              doneReading = 1;
            }
            amountRead++;
            if ((readResult == -1) || (amountRead >= (BUFFSIZE-2))) {
              sprintf(xB,"221");
              sprintf(dB,"223 %d",loopCtr+1);
              doEcho(loopCtr,xB,dB,1);
              if (clients[loopCtr] != -1) {
                close(clients[loopCtr]);
                clients[loopCtr] = -1;
              }
              amountRead = 0;
              doneReading = 1;
            }
          }
          if (amountRead != 0) {
            clientTimes[loopCtr] = time(NULL);
            if (strncmp(dB,"210",3) == 0) {
              strcpy(tempString,&dB[4]);
              sprintf(xB,"211 %s", tempString);
              sprintf(dB,"213 %d %s",loopCtr+1,tempString);
              doEcho(loopCtr,xB,dB,0);
            } else if (strncmp(dB,"220",3) == 0) {
              sprintf(xB,"221");
              sprintf(dB,"223 %d",loopCtr+1);
              doEcho(loopCtr,xB,dB,1);
              if (clients[loopCtr] != -1) {
                fprintf(stderr, "Closing stream for %d.\n",loopCtr+1);
                close(clients[loopCtr]);
                clients[loopCtr] = -1;
              }
            } else {
              sprintf(xB,"999 %s",dB);
              sendSingleC(xB, loopCtr);
            }
          }
        }
      }
    }
  }
}
